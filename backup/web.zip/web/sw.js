/* Ping's MHXX Dex 离线缓存 —— 网页版 */
const VERSION = 'mhxx-v8';

// 页面骨架 + 数据全量预缓存（数据共约 4MB，一次下载后完全离线）
const CORE = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/app.css',
  './js/core.js',
  './js/pages.js',
  './js/pages2.js',
  './js/build.js',
  './js/boot.js',
  // 原版界面（反编译 1:1 复刻）
  './classic.html',
  './css/classic.css',
  './js/classic.js',
  './js/classic_data.js',
  './data/classic_spec.json',
  // 网页版（左目录 + 右内容）
  './app.html',
  './css/web.css',
  './js/web.js',
  // 全新界面版（21 个主目录 + 全局搜索 + 套装模拟/配装）
  './dex.html',
  './css/dex.css',
  './js/dex_data.js',
  './js/dex.js',
  './data/dex_extra.json',
  './img/icon/items.png',
  './img/icon/app-192.png',
  './img/icon/app-512.png',

  './data/meta.json',
  './data/labels.json',
  './data/item_icons.json',
  './data/weapons.json',
  './data/weapon_upg.json',
  './data/armor.json',
  './data/skills.json',
  './data/jewels.json',
  './data/items.json',
  './data/item_src.json',
  './data/recipes.json',
  './data/combo.json',
  './data/quests.json',
  './data/quest_rewards.json',
  './data/monsters.json',
  './data/mon_drops.json',
  './data/maps.json',
  './data/medals.json',
  './data/hhsongs.json',
  './data/bowgun.json',
  './data/kinsects.json',
  './data/peli_weapons.json',
  './data/peli_armor.json',
  './data/peliteam.json',
  './data/hfh.json',
  './data/veggie.json',
  './data/arena.json',
  // 反编译对照后补齐：武器旋律 / 装填弹药 / 道具用处反查
  './data/wpn_songs.json',
  './data/wpn_gun.json',
  './data/item_use.json',
  './data/extra_links.json'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(VERSION)
      // 逐个加，单个文件缺失不至于让整个安装失败
      .then(c => Promise.all(CORE.map(u => c.add(u).catch(() => null))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  // 调试页不进缓存
  if (/\/__/.test(url.pathname)) return;

  // 图片量太大（上千张），不做预缓存：用到才存，之后离线可用
  if (/\/img\//.test(url.pathname)) {
    e.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(VERSION).then(c => c.put(req, copy));
        }
        return res;
      }).catch(() => hit))
    );
    return;
  }

  // 其余：缓存优先，缺失则网络并回填
  const FALLBACK = /dex\.html$/.test(url.pathname) ? './dex.html' : './index.html';
  e.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(VERSION).then(c => c.put(req, copy));
      }
      return res;
    }).catch(() => caches.match(FALLBACK)))
  );
});
