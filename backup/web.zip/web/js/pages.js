/* 页面：首页 / 武器 / 防具 / 装饰品 / 道具 / 调和 / 技能 */
(function () {
  const A = window.A;
  const TYPES = ['大剑', '太刀', '片手剑', '双剑', '大锤', '狩猎笛', '长枪', '铳枪', '斩击斧', '充能斧', '操虫棍', '轻弩', '重弩', '弓'];
  const PARTS = ['头', '胸', '腕', '腰', '脚'];
  A.TYPES = TYPES; A.PARTS = PARTS;

  /* ================= 首页 ================= */
  const HOME_GROUPS = [
    ['图鉴', [
      ['weapons', '武器', 'all', 'guns'],
      ['armor', '防具', 'armor', ''],
      ['jewels', '装饰品', 'deco', ''],
      ['items', '道具', 'item', ''],
      ['skills', '技能', 'skill', ''],
      ['combo', '调和', 'mix', ''],
      ['medals', '勋章', 'medal', ''],
    ]],
    ['狩猎资料', [
      ['quests', '任务', 'quest', ''],
      ['monsters', '怪物', 'mon', ''],
      ['maps', '地图', 'map', ''],
      ['hh', '笛旋律', 'note', ''],
      ['bowgun', '弩弹药', 'ammo', ''],
      ['kinsect', '猎虫', 'bug', ''],
    ]],
    ['随从与交易', [
      ['peli-w', '随从武器', 'peli', ''],
      ['peli-a', '随从防具', 'peli', ''],
      ['pt', '猛喵队', 'cat', ''],
      ['hfh', '游荡猎人', 'trade', ''],
      ['veggie', '山菜爷爷', 'trade', ''],
      ['arena', '斗技大会', 'arena', ''],
    ]],
    ['配装', [
      ['sim', '套装模拟器', 'build', ''],
      ['finder', '套装配装器', 'search', ''],
      ['charms', '我的护石', 'charm', ''],
    ]],
  ];

  function glyph(kind) {
    const p = {
      guns: 'M14 4l6 6-9 9H5v-6z', armor: 'M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z',
      deco: 'M12 3l3 6 6 1-4.5 4.5L18 21l-6-3-6 3 1.5-6.5L3 10l6-1z',
      item: 'M6 8h12l-1 12H7zM9 8V6a3 3 0 016 0v2', skill: 'M4 18V9m5 9V5m5 13v-6m5 6V7',
      mix: 'M6 4h12M6 8h12M9 12l6 8M15 12l-6 8', medal: 'M12 3l2.5 5.5L20 9l-4 4 .8 6-4.8-2.6L7.2 19 8 13 4 9l5.5-.5z',
      quest: 'M7 4h10v16l-5-3-5 3z', mon: 'M4 10c0-3 3-5 8-5s8 2 8 5-3 5-8 5-8-2-8-5zM8 7l-2-3m12 3l2-3',
      map: 'M9 4l6 2 6-2v14l-6 2-6-2-6 2V6z', note: 'M9 18V6l8-2v12M9 18a2 2 0 11-4 0 2 2 0 014 0zm8-2a2 2 0 11-4 0 2 2 0 014 0z',
      ammo: 'M8 21V9l4-6 4 6v12z', bug: 'M12 7a3 3 0 100 6 3 3 0 000-6zM12 3v4m0 6v8M5 8l4 2m10-2l-4 2M5 16l4-2m10 2l-4-2',
      peli: 'M5 12c0-4 3-6 7-6s7 2 7 6-3 8-7 8-7-4-7-8zm3-3l-1-3m9 3l1-3',
      cat: 'M5 9l2-5 3 3h4l3-3 2 5v6a5 5 0 01-5 5h-4a5 5 0 01-5-5z', trade: 'M4 7h16l-2 10H6zM9 3v4m6-4v4',
      arena: 'M12 3l2.2 4.5 5 .7-3.6 3.5.9 4.9L12 14.3 7.5 16.6l.9-4.9L4.8 8.2l5-.7z',
      build: 'M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z', search: 'M11 4a7 7 0 104.9 12l4.1 4.1',
      charm: 'M12 3l4 4-4 13-4-13z', all: 'M4 6h16M4 12h16M4 18h10'
    }[kind] || 'M4 6h16M4 12h16M4 18h16';
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="${p}"/></svg>`;
  }
  A.glyph = glyph;

  A.route('home', {
    title: 'MHXX 资料库', sub: 'Monster Hunter XX · 全功能',
    load: ['meta', 'item_icons', 'labels'],
    mount(view) {
      const m = A.data.meta || {};
      let h = `<div class="hero">
        <div class="hero-t">怪物猎人 XX 资料库</div>
        <div class="hero-s">武器 ${A.fmt(m.weapons)} · 防具 ${A.fmt(m.armor)} · 技能 ${m.skills} · 任务 ${A.fmt(m.quests)} · 怪物 ${m.monsters}</div>
      </div>`;
      h += `<a class="web-entry" href="app.html">
        <span class="ce-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="7" height="16" rx="1.4"/><rect x="12" y="4" width="9" height="7" rx="1.4"/><rect x="12" y="13" width="9" height="7" rx="1.4"/></svg></span>
        <span class="ce-txt"><b>网页版 · 左目录右内容</b><small>按原 exe 功能结构重新编排，大图与素材全部取自原程序</small></span>
        <span class="ce-arrow">›</span>
      </a>`;
      h += `<a class="classic-entry" href="classic.html">
        <span class="ce-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="3.5" width="19" height="13" rx="1.5"/><path d="M8 20.5h8M12 16.5v4M2.5 7.5h19"/></svg></span>
        <span class="ce-txt"><b>原版界面 · 完全模拟</b><small>按反编译结果还原窗口、菜单、表格与联动；支持多窗口与缩放</small></span>
        <span class="ce-arrow">›</span>
      </a>`;
      HOME_GROUPS.forEach(([g, items]) => {
        h += `<div class="group-t">${g}</div><div class="tiles">` + items.map(([id, name, ic]) =>
          `<button class="tile" data-go="${id}">${glyph(ic)}<span>${name}</span></button>`).join('') + '</div>';
      });
      h += `<div class="foot">数据来自 Ping's MHXX Dex（CC BY-NC-ND 4.0）· 仅个人游戏查询用途</div>`;
      view.innerHTML = h;
      view.addEventListener('click', e => {
        const b = e.target.closest('[data-go]');
        if (b) A.go(b.dataset.go);
      });
    }
  });

  /* ================= 资料（导航） ================= */
  A.route('data', {
    title: '资料', sub: '全部数据表', nav: 'data',
    load: ['meta'],
    mount(view) {
      let h = '';
      HOME_GROUPS.filter(g => g[0] !== '配装').forEach(([g, items]) => {
        h += `<div class="group-t">${g}</div><div class="tiles">` + items.map(([id, name, ic]) =>
          `<button class="tile" data-go="${id}">${glyph(ic)}<span>${name}</span></button>`).join('') + '</div>';
      });
      h += `<div class="group-t">其他</div><div class="tiles">
        <button class="tile" data-go="about">${glyph('item')}<span>关于</span></button></div>`;
      view.innerHTML = h;
      view.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) A.go(b.dataset.go); });
    }
  });

  /* ================= 武器 ================= */
  /* 布局对齐原程序 mi=251 / 列方法 mi=225：
     左侧强化树 + 右侧主表 + 底部「生产素材/强化素材/装填弹药|旋律」三分区 + 独立筛选区 */
  A.route('weapons', {
    title: '武器', sub: '10,911 把', load: ['weapons', 'labels', 'skills', 'recipes', 'weapon_upg', 'wpn_songs', 'hhsongs', 'items', 'item_icons'],
    mount(view, params) {
      const W = A.data.weapons, L = A.data.labels;
      let viewMode = params.view || 'list';
      let typeId = params.type || '0', keyword = '', filterOpen = false;
      const F = { sharp: '0', last: false, elems: new Set(), noElem: false, notes: new Set(), specKey: '0', specVal: '0', treeAll: 0 };
      const head = document.createElement('div');
      const fbox = document.createElement('div');
      const body = document.createElement('div');
      view.appendChild(head); view.appendChild(fbox); view.appendChild(body);

      head.appendChild(A.chips([['0', '全部']].concat(TYPES.map((t, i) => [String(i + 1), t])),
        typeId, v => { typeId = v; F.specKey = '0'; F.specVal = '0'; paintFilter(); paint(); }));

      const fbtn = document.createElement('button');
      fbtn.className = 'btn ghost sm';
      fbtn.textContent = '筛选';
      fbtn.addEventListener('click', () => { filterOpen = !filterOpen; fbtn.classList.toggle('on', filterOpen); paintFilter(); });
      head.appendChild(A.row(
        A.seg([['list', '列表'], ['tree', '武器树'], ['gallery', '图鉴']], viewMode, v => { viewMode = v; paintFilter(); paint(); }),
        fbtn
      ));
      A.setSearch('搜索武器名…', v => { keyword = v.trim(); paint(); });

      /* 原程序 _GroupBox_Filter：锋利度 +0/+1/+2、终形态、属性、笛音色、两组特殊筛选 */
      function specOptions(t) {
        const G = {
          8: [['12', '炮击类型', 'gl']],
          9: [['13', '装着瓶', 'axePhial']],
          10: [['13', '装着瓶', 'axePhial']],
          11: [['15', '猎虫类型', 'kinsectType']],
          12: [['18', '装填速度', 'reload'], ['19', '摇晃', 'steadiness'], ['20', '后坐力', 'recoil']],
          13: [['18', '装填速度', 'reload'], ['19', '摇晃', 'steadiness'], ['20', '后坐力', 'recoil']],
          14: [['16', '曲射', 'bowShot'], ['17', '箭矢类型', 'shotType']]
        };
        return G[t] || [];
      }
      function specValues(k, labelKey) {
        const t = +typeId, set = new Set();
        W.forEach(w => {
          if (t && w[1] !== t) return;
          const v = w[+k];
          (Array.isArray(v) ? v : [v]).forEach(x => { if (x > 0) set.add(x); });
        });
        const nm = (L[labelKey] || {});
        return Array.from(set).sort((a, b) => a - b).map(x => [String(x), nm[x] || (labelKey === 'gl' ? '炮击 Lv.' + x : String(x))]);
      }

      function paintFilter() {
        fbox.innerHTML = '';
        if (!filterOpen) return;
        const opts = specOptions(+typeId);
        const vals = F.specKey === '0' ? [] : specValues(F.specKey, (opts.find(o => o[0] === F.specKey) || [0, 0, ''])[2]);
        const elems = [['0', '无属性']].concat(Object.keys(L.elem || {}).map(k => [k, L.elem[k]]));
        const e = document.createElement('div');
        e.className = 'card fpanel';
        e.innerHTML = `
          <div class="frow"><span>锋利度</span>${A.seg([['0', '+0'], ['1', '+1'], ['2', '+2']], F.sharp, () => { }).outerHTML}
            <span class="fhint">匠加成显示斩味</span></div>
          <div class="frow"><span>属性</span><div class="chips wrapc" data-g="elem">
            ${elems.map(([k, t]) => `<button class="chip${(k === '0' ? F.noElem : F.elems.has(k)) ? ' on' : ''}" data-v="${k}">${t}</button>`).join('')}
          </div></div>
          ${+typeId === 6 ? `<div class="frow"><span>笛音色</span><div class="chips wrapc" data-g="note">
            ${[1, 2, 3, 4, 5, 6, 7, 8].map(k => `<button class="chip nchip${F.notes.has(String(k)) ? ' on' : ''}" data-v="${k}"><i class="note n${k}"></i></button>`).join('')}
          </div></div>` : ''}
          ${opts.length ? `<div class="frow"><span>特性</span>
            <select class="sel" data-g="specKey">${[['0', '不限']].concat(opts.map(o => [o[0], o[1]])).map(([k, t]) => `<option value="${k}"${F.specKey === k ? ' selected' : ''}>${t}</option>`).join('')}</select>
            <select class="sel" data-g="specVal"${F.specKey === '0' ? ' disabled' : ''}>${[['0', '全部']].concat(vals).map(([k, t]) => `<option value="${k}"${F.specVal === k ? ' selected' : ''}>${A.esc(t)}</option>`).join('')}</select>
          </div>` : ''}
          <div class="frow"><span>范围</span>
            <label class="ck"><input type="checkbox" data-g="last"${F.last ? ' checked' : ''}> 仅终形态（无法继续强化）</label>
          </div>
          ${viewMode === 'tree' ? `<div class="frow"><span>强化树</span>
            <button class="btn ghost sm" data-g="expand">展开全部</button>
            <button class="btn ghost sm" data-g="collapse">折叠全部</button></div>` : ''}
          <div class="dim2 pad pt0">筛选对齐原程序「筛选」组：锋利度 +0/+1/+2、属性、笛音色、武器专属特性与终形态。</div>`;
        fbox.appendChild(e);

        e.addEventListener('click', ev => {
          const seg = ev.target.closest('.seg button');
          if (seg) { F.sharp = seg.dataset.v; paintFilter(); return; }
          const chip = ev.target.closest('.chip');
          if (chip) {
            const g = chip.closest('[data-g]').dataset.g, v = chip.dataset.v;
            if (g === 'elem') { if (v === '0') F.noElem = !F.noElem; else F.elems.has(v) ? F.elems.delete(v) : F.elems.add(v); }
            if (g === 'note') { F.notes.has(v) ? F.notes.delete(v) : F.notes.add(v); }
            paintFilter(); paint(); return;
          }
          if (ev.target.closest('[data-g="expand"]')) { F.treeAll = 1; paint(); return; }
          if (ev.target.closest('[data-g="collapse"]')) { F.treeAll = 0; paint(); return; }
        });
        e.addEventListener('change', ev => {
          const g = ev.target.dataset.g;
          if (g === 'last') { F.last = ev.target.checked; paint(); }
          if (g === 'specKey') { F.specKey = ev.target.value; F.specVal = '0'; paintFilter(); paint(); }
          if (g === 'specVal') { F.specVal = ev.target.value; paint(); }
        });
      }

      function filtered() {
        const t = +typeId;
        return W.filter(w => {
          if (t && w[1] !== t) return false;
          if (keyword && w[2].indexOf(keyword) < 0) return false;
          if (F.last && w[11] > 0) return false;
          if (F.elems.size || F.noElem) {
            const ids = w[5].map(x => x[0]);
            let ok = F.noElem && !ids.length;
            ids.forEach(id => { if (F.elems.has(String(id))) ok = true; });
            if (!ok) return false;
          }
          if (F.notes.size) {
            let ok = false;
            (w[14] || []).forEach(n => { if (n > 0 && F.notes.has(String(n))) ok = true; });
            if (!ok) return false;
          }
          if (F.specKey !== '0' && F.specVal !== '0') {
            const v = w[+F.specKey];
            if ((Array.isArray(v) ? v : [v]).indexOf(+F.specVal) < 0) return false;
          }
          return true;
        });
      }

      function listView(box) {
        const fl = filtered();
        const rows = fl.map(w => [
          { html: `<span class="cellname">${A.esc(A.stripLv(w[2]))}<span class="dim lv">Lv.${A.lvNum(w[2])}</span></span>`, v: w[2] },
          { t: w[3], a: 'c', v: w[3] },
          { t: w[4], a: 'r', v: w[4] },
          { html: A.elemHtml(w[5]), v: w[5].length ? 1 : 0 },
          { t: (w[6] > 0 ? '+' : '') + w[6] + '%', a: 'r', v: w[6] },
          { t: w[7] || '—', a: 'r', v: w[7] },
          { html: A.slotHtml(w[8]), a: 'c', v: w[8] }
        ]);
        const t = A.table({
          cols: [{ t: '武器', k: 0, p: 33 }, { t: '稀', a: 'c', k: 1, p: 8 }, { t: '攻击', a: 'r', k: 2, p: 11 },
          { t: '属性', k: 3, p: 17 }, { t: '会心', a: 'r', k: 4, p: 11 }, { t: '防御', a: 'r', k: 5, p: 9 },
          { t: '孔', a: 'c', k: 6, p: 11 }],
          rows,
          onRow: r => weaponSheet(r.__w)
        });
        rows.forEach((r, i) => { r.__w = fl[i]; });
        box.appendChild(t.el);
      }

      function treeView(box) {
        const all = filtered();
        // 数据里没有父级字段（Child 是强化分支数），按「同类型 + Lv 递增」就近推导
        const byType = {};
        all.forEach(w => { (byType[w[1]] = byType[w[1]] || []).push(w); });
        const kids = new Map(), roots = [];
        Object.keys(byType).forEach(t => {
          const arr = byType[t];
          arr.forEach((w, i) => {
            const L = A.lvNum(w[2]);
            let p = null;
            if (L > 1) {
              for (let j = i - 1; j >= Math.max(0, i - 16); j--) {
                if (A.lvNum(arr[j][2]) === L - 1) { p = arr[j]; break; }
              }
            }
            if (p) { if (!kids.has(p[0])) kids.set(p[0], []); kids.get(p[0]).push(w); }
            else roots.push(w);
          });
        });

        const wrap = document.createElement('div');
        wrap.className = 'tree';
        function lineHtml(w, depth) {
          const ch = kids.get(w[0]) || [];
          const mark = ch.length ? `<button class="tgl" data-tg="${w[0]}">▸</button>` : '<span class="tgl ph"></span>';
          const pad = 8 + Math.min(depth, 8) * 14;
          return `<div class="tnode" style="padding-left:${pad}px" data-w="${w[0]}">
            ${mark}
            <span class="tw">${A.esc(A.stripLv(w[2]))}<em>Lv.${A.lvNum(w[2])}</em></span>
            <span class="tr">${w[4]}${w[5].length ? ' ' + w[5].map(e => `<i class="dot e${e[0]}"></i>`).join('') : ''}</span>
          </div>`;
        }
        // 「展开全部」：递归铺开到 5 层
        function branch(w, depth, budget) {
          let s = lineHtml(w, depth);
          const ch = kids.get(w[0]) || [];
          if (ch.length && depth < 5 && budget.n < 900) {
            s += `<div class="tchildren" data-p="${w[0]}">` + ch.map(c => {
              const inner = kids.get(c[0]);
              if (!F.treeAll || depth >= 4 || budget.n >= 900) return lineHtml(c, depth + 1) +
                (inner ? `<div class="tchildren" data-p="${c[0]}" hidden></div>` : '');
              budget.n++;
              return branch(c, depth + 1, budget);
            }).join('') + `</div>`;
            s = s.replace('>▸<', '>▾<');
          } else if (ch.length) {
            s += `<div class="tchildren" data-p="${w[0]}" hidden></div>`;
          }
          return s;
        }
        let html = '';
        const budget = { n: 0 };
        roots.slice(0, 200).forEach(w => { html += F.treeAll ? branch(w, 0, budget) : lineHtml(w, 0) + (kids.get(w[0]) ? `<div class="tchildren" data-p="${w[0]}" hidden></div>` : ''); });
        wrap.innerHTML = html || '<div class="empty">没有结果</div>';
        if (roots.length > 200) wrap.insertAdjacentHTML('beforeend', '<div class="dim pad center">仅显示前 200 条根节点，请用武器种类或搜索缩小范围</div>');

        wrap.addEventListener('click', e => {
          const tg = e.target.closest('.tgl');
          const holder = tg ? tg.closest('.tnode').nextElementSibling : null;
          if (tg && holder && holder.classList.contains('tchildren')) {
            const open = holder.hidden;
            if (open && !holder.dataset.done) {
              const depth = (+tg.closest('.tnode').style.paddingLeft.replace('px', '') - 8) / 14 + 1;
              const ch = kids.get(+tg.dataset.tg) || [];
              holder.innerHTML = ch.map(c => lineHtml(c, depth) + (kids.get(c[0]) ? `<div class="tchildren" data-p="${c[0]}" hidden></div>` : '')).join('');
              holder.dataset.done = '1';
            }
            holder.hidden = !open;
            tg.textContent = open ? '▾' : '▸';
            return;
          }
          const n = e.target.closest('[data-w]');
          if (n) weaponSheet(A.byId('weapons').get(+n.dataset.w));
        });
        box.appendChild(wrap);
      }

      function galleryView(box) {
        const all = filtered().slice(0, 300);
        const g = document.createElement('div');
        g.className = 'gallery';
        g.innerHTML = all.map(w => `<button data-w="${w[0]}">
          <img loading="lazy" src="${A.wpnImg(w[10])}" alt="">
          <span>${A.esc(A.stripLv(w[2]))}</span><em>Lv.${A.lvNum(w[2])}</em></button>`).join('');
        g.addEventListener('click', e => {
          const b = e.target.closest('[data-w]');
          if (b) weaponSheet(A.byId('weapons').get(+b.dataset.w));
        });
        box.appendChild(g);
        if (filtered().length > 300) box.insertAdjacentHTML('beforeend', `<div class="dim pad center">仅显示前 300 件，请用筛选缩小范围</div>`);
      }

      function paint() {
        const box = document.createElement('div');
        if (viewMode === 'list') listView(box);
        else if (viewMode === 'tree') treeView(box);
        else galleryView(box);
        body.innerHTML = '';
        body.appendChild(box);
        A.setTitle('武器', `${filtered().length.toLocaleString()} / ${W.length.toLocaleString()}`);
      }
      A.paint = paint;
      paintFilter();
      paint();
      if (params.id) weaponSheet(A.byId('weapons').get(+params.id));
    }
  });

  function weaponSheet(w) {
    if (!w) return;
    const L = A.data.labels, T = A.data.weapons;
    const upg = A.data.weapon_upg[String(w[0])] || [];
    const rec = A.data.recipes['w' + w[0]] || [];
    const kids = T.filter(x => x[11] === w[0] && x[0] !== w[0] && A.lvNum(x[2]) === A.lvNum(w[2]) + 1);
    const typeName = TYPES[w[1] - 1];
    // 匠加成显示级别：从筛选面板读，默认 +0
    let sharpPlus = 0;
    try { sharpPlus = +(document.querySelector('.fpanel .seg button.on') || {}).dataset?.v || 0; } catch (e) { }
    let h = `<div class="detail-head"><div class="pic w"><img src="${A.wpnImg(w[10])}" alt=""></div>
      <div class="grow"><h2>${A.esc(w[2])}</h2>
      <div class="meta"><span>${typeName}</span><span>稀有度 ${w[3]}</span>${w[11] > 0 ? `<span class="dim">可强化</span>` : ''}</div>
      <div class="meta"><span>生产 ${A.fmt(w[21])} z</span>${w[22] ? `<span>强化 ${A.fmt(w[22])} z</span>` : ''}</div></div></div>`;
    h += `<div class="stat-grid">${A.stat('攻击', w[4])}${A.stat('会心', (w[6] > 0 ? '+' : '') + w[6] + '%')}${A.stat('防御', w[7] || '—')}</div>`;
    h += A.card(`<div class="pad"><div class="kvline"><span>属性</span><div>${A.elemHtml(w[5])}</div></div>
      <div class="kvline"><span>孔位</span><div>${A.slotHtml(w[8])}</div></div></div>
      <div class="pad pt0">${A.sharpBar(w[9], 12, sharpPlus, w[23])}${sharpPlus ? `<div class="dim2">匠 +${sharpPlus}${w[23] ? '' : '（该武器无匠加成标记 SharpP1=0）'}</div>` : ''}</div>`);

    // 类型专属（原程序主表列）
    const spec = [];
    if (w[1] === 6) spec.push(['笛音符', (w[14] || []).filter(n => n > 0).map(n => `<i class="note n${n}"></i>`).join('') || '—']);
    if (w[13] > 0) spec.push(['装着瓶', L.axePhial[w[13]] || w[13]]);
    if (w[12] > 0) spec.push(['炮击类型', 'Lv.' + w[12]]);
    if (w[15] > 0) spec.push(['猎虫类型', L.kinsectType[w[15]] || w[15]]);
    if (w[16] > 0) spec.push(['曲射', L.bowShot[w[16]] || w[16]]);
    if (w[17] && w[17].some(x => x > 0)) spec.push(['蓄力攻击', w[17].filter(x => x > 0).map(x => L.shotType[x] || x).join(' / ')]);
    if (w[18] > 0) spec.push(['装填速度', L.reload[w[18]] || w[18]]);
    if (w[19] >= 0 && (w[1] === 12 || w[1] === 13)) spec.push(['摇晃', L.steadiness[w[19]] || w[19]]);
    if (w[20] > 0) spec.push(['后坐力', L.recoil[w[20]] || w[20]]);
    if (spec.length) h += A.card(A.sec('武器特性') + A.kv(spec));

    /* 原程序底部三分区：生产素材 / 强化素材 / 装填弹药 或 旋律 */
    if (rec.length) h += A.matTable(rec, '生产素材');
    if (upg.length) h += A.matTable(upg, '强化素材');
    if (upg.length || rec.length || w[1] === 12 || w[1] === 13 || w[1] === 6) {
      h += `<div id="wpn-extra" class="dim pad">载入中…</div>`;
    }
    if (kids.length) h += A.card(A.sec('可强化为') + kids.map(k =>
      `<div class="subrow" data-w="${k[0]}"><span class="nm2">${A.esc(k[2])}</span><span class="dim">攻 ${k[4]}</span></div>`).join(''));

    A.sheet(w[2], h);
    A.$('#sheet-live').addEventListener('click', e => {
      const it = e.target.closest('[data-item]');
      if (it) { A.itemSheet(it.dataset.item); return; }
      const k = e.target.closest('[data-w]');
      if (k) { weaponSheet(A.byId('weapons').get(+k.dataset.w)); return; }
    });

    // 装填弹药 / 旋律：按武器类型按需加载（对应 _DGV_Gun / _DGV_WpntoHHSong）
    const extra = A.$('#wpn-extra');
    if (!extra) return;
    const jobs = [];
    if (w[1] === 12 || w[1] === 13) jobs.push(A.load(['wpn_gun', 'items', 'item_icons']));
    if (w[1] === 6) jobs.push(A.load(['wpn_songs', 'hhsongs', 'labels']));
    Promise.all(jobs).then(() => {
      const box = A.$('#wpn-extra');
      if (!box) return;
      let out = '';
      if (w[1] === 12 || w[1] === 13) {
        const rows = A.data.wpn_gun[String(w[0])] || [];
        const M = A.byId('items');
        const gap = A.data.labels.rapidGap || {};
        out += A.card(A.sec('装填弹药') + (rows.length ? `<table class="grid ammo"><thead><tr><th>弹药</th><th class="num">装填</th><th class="num">追加</th><th class="num">携带</th><th class="num">特射</th><th class="num">间隔</th></tr></thead><tbody>` +
          rows.map(r => `<tr data-item="${r[0]}"><td class="withico">${A.itemIcon(r[0], 20)}<span>${A.esc((M.get(r[0]) || [0, '?'])[1])}</span></td>
            <td class="num">${r[1] || '—'}</td><td class="num">${r[2] || '—'}</td><td class="num">${r[3] || '—'}</td>
            <td class="num">${r[4] > 0 ? r[4] : '—'}</td><td class="dim">${r[5] > 0 ? (gap[r[5]] || r[5]) : '—'}</td></tr>`).join('') + `</tbody></table>`
          : '<div class="empty">无装填数据</div>'));
      }
      if (w[1] === 6) {
        const songs = A.data.wpn_songs[String(w[0])] || [];
        const S = A.byId('hhsongs');
        out += A.card(A.sec('旋律') + (songs.length ? `<table class="grid"><tbody>` + songs.map(([sid, rank]) => {
          const so = S.get(sid);
          return `<tr><td class="num dim">#${sid}</td><td>${A.esc(so ? so[3] : '旋律 ' + sid)}</td><td class="dim">${A.esc(so ? so[6] : '')}</td></tr>`;
        }).join('') + `</tbody></table>` : '<div class="empty">无旋律数据</div>'));
      }
      box.outerHTML = out || '';
    }).catch(() => { if (A.$('#wpn-extra')) A.$('#wpn-extra').outerHTML = ''; });
  }
  A.weaponSheet = weaponSheet;

  /* ================= 防具 ================= */
  A.route('armor', {
    title: '防具', sub: '', load: ['armor', 'labels', 'skills', 'recipes', 'items', 'item_icons'],
    mount(view, params) {
      const AR = A.data.armor;
      let part = params.part || '0', borg = '0', morf = '0', keyword = '',
        sort = params.sort || 'def', viewMode = params.view || 'list';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);

      head.appendChild(A.chips([['0', '全部'], ['1', '头'], ['2', '胸'], ['3', '腕'], ['4', '腰'], ['5', '脚']], part,
        v => { part = v; paint(); }));
      head.appendChild(A.row(
        A.select([['0', '性别不限'], ['1', '男性'], ['2', '女性']], morf, v => { morf = v; paint(); }),
        A.select([['0', '剑士/枪手'], ['1', '剑士'], ['2', '枪手']], borg, v => { borg = v; paint(); }),
        A.seg([['list', '列表'], ['gallery', '图鉴']], viewMode, v => { viewMode = v; paint(); })
      ));
      /* 原程序 _Group_SkillTree：两个技能树下拉（可叠加，需同时满足） */
      let sklA = '0', sklB = '0';
      const treeOpts = [['0', '技能树不限']].concat(
        ((A.data.skills && A.data.skills.trees) || []).slice().sort((x, y) => String(x[1]).localeCompare(String(y[1]), 'zh'))
          .map(t => [String(t[0]), t[1]]));
      head.appendChild(A.row(
        A.select(treeOpts, sklA, v => { sklA = v; paint(); }),
        A.select(treeOpts, sklB, v => { sklB = v; paint(); })
      ));
      A.setSearch('搜索防具名…', v => { keyword = v.trim(); paint(); });

      function filtered() {
        const p = +part, b = +borg, m = +morf;
        return AR.filter(a => (!p || a[1] === p) && (!b || a[8] === 0 || a[8] === b) && (!m || a[9] === 0 || a[9] === m)
          && (!keyword || a[2].indexOf(keyword) >= 0)
          && (!(+sklA) || (a[12] || []).some(x => x[0] === +sklA && x[1] > 0))
          && (!(+sklB) || (a[12] || []).some(x => x[0] === +sklB && x[1] > 0)));
      }

      function paint() {
        const list = filtered();
        A.setTitle('防具', `${list.length.toLocaleString()} / ${AR.length.toLocaleString()}`);
        body.innerHTML = '';
        if (viewMode === 'gallery') {
          const g = document.createElement('div');
          g.className = 'gallery a';
          g.innerHTML = list.slice(0, 240).map(a =>
            `<button data-a="${a[0]}"><img loading="lazy" src="${A.amrImg(a[10])}" alt=""><span>${A.esc(a[2])}</span></button>`).join('');
          g.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (b) armorSheet(A.byId('armor').get(+b.dataset.a)); });
          body.appendChild(g);
          if (list.length > 240) body.insertAdjacentHTML('beforeend', '<div class="dim pad center">仅显示前 240 件</div>');
          return;
        }
        const rows = list.map(a => [
          { html: `<span class="cellname">${A.esc(a[2])}</span>`, v: a[2] },
          { t: a[3], a: 'c', v: a[3] },
          { html: A.slotHtml(a[4]), a: 'c', v: a[4] },
          { t: a[5], a: 'r', v: a[5] },
          { t: a[6], a: 'r', v: a[6] },
          { html: A.res5(a[7]), v: a[7].reduce((x, y) => x + y, 0) },
          { t: A.fmt(a[11]), a: 'r', v: a[11] }
        ]);
        const t = A.table({
          cols: [{ t: '防具', k: 0, p: 30 }, { t: '稀', a: 'c', k: 1, p: 7 }, { t: '孔', a: 'c', k: 2, p: 10 },
          { t: '防', a: 'r', k: 3, p: 8 }, { t: '最大', a: 'r', k: 4, p: 9 },
          { t: '耐性', k: 5, p: 22 }, { t: '生产价', a: 'r', k: 6, p: 14 }],
          rows, sortK: { def: 3, max: 4, slot: 2, rare: 1, id: 0 }[sort],
          onRow: r => armorSheet(r.__a)
        });
        rows.forEach((r, i) => { r.__a = list[i]; });
        body.appendChild(t.el);
      }
      paint();
      if (params.id) armorSheet(A.byId('armor').get(+params.id));
    }
  });

  function armorSheet(a) {
    if (!a) return;
    const rec = A.data.recipes['a' + a[0]] || [];
    const RES = ['火', '水', '雷', '冰', '龙'];
    let h = `<div class="detail-head"><div class="pics">
      <div class="pic a"><img src="${A.amrImg(a[10])}" alt=""></div>
      <div class="pic a"><img src="img/a/${A.esc(a[10])}_F.webp" alt="" onerror="this.parentNode.style.display='none'"></div></div>
      <div class="grow"><h2>${A.esc(a[2])}</h2>
      <div class="meta"><span>${PARTS[a[1] - 1]}</span><span>稀有度 ${a[3]}</span><span>${a[8] === 1 ? '剑士' : a[8] === 2 ? '枪手' : '共通'}</span><span>${a[9] === 1 ? '男性' : a[9] === 2 ? '女性' : ''}</span></div>
      <div class="meta"><span>孔位 ${A.slotHtml(a[4])}</span></div></div></div>`;
    h += `<div class="stat-grid">${A.stat('防御', a[5])}${A.stat('最大防御', a[6])}${A.stat('生产价', A.fmt(a[11]))}</div>`;
    h += A.card(A.sec('耐性') + `<div class="res-row">${a[7].map((v, i) =>
      `<div class="res"><span class="e${i + 1}">${RES[i]}</span><b class="${v > 0 ? 'res-p' : v < 0 ? 'res-n' : 'dim'}">${v > 0 ? '+' : ''}${v}</b></div>`).join('')}</div>`);
    if (a[12].length) {
      h += A.card(A.sec('技能') + `<table class="grid"><tbody>${a[12].map(([tid, pt]) => {
        const lv = A.skillLevel(tid, pt);
        const t = A.data.skills.trees.find(x => x[0] === tid);
        return `<tr data-skl="${tid}"><td>${A.esc(t ? t[1] : tid)}</td><td class="num ${pt >= 0 ? 'res-p' : 'res-n'}">${pt > 0 ? '+' : ''}${pt}</td></tr>`;
      }).join('')}</tbody></table>`);
    }
    if (rec.length) h += A.matTable(rec, '生产素材');
    A.sheet(a[2], h);
    A.$('#sheet-live').addEventListener('click', e => {
      const it = e.target.closest('[data-item]'); if (it) return A.itemSheet(it.dataset.item);
      const s = e.target.closest('[data-skl]'); if (s) return skillSheet(+s.dataset.skl);
    });
  }
  A.armorSheet = armorSheet;

  /* ================= 装饰品 ================= */
  A.route('jewels', {
    title: '装饰品', sub: '', load: ['jewels', 'skills', 'recipes', 'items', 'item_icons'],
    mount(view) {
      const J = A.data.jewels;
      let slot = '0', keyword = '';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      head.appendChild(A.chips([['0', '全部'], ['1', '①孔'], ['2', '②孔'], ['3', '③孔']], slot, v => { slot = v; paint(); }));
      A.setSearch('搜索装饰品 / 技能…', v => { keyword = v.trim(); paint(); });
      function paint() {
        const list = J.filter(j => (!+slot || j[2] === +slot) && (!keyword || j[1].indexOf(keyword) >= 0 ||
          j[4].some(([tid]) => { const t = A.data.skills.trees.find(x => x[0] === tid); return t && t[1].indexOf(keyword) >= 0; })));
        A.setTitle('装饰品', `${list.length} / ${J.length}`);
        body.innerHTML = '';
        const rows = list.map(j => [
          { html: `<span class="nm">${A.esc(j[1])}</span>`, v: j[1] },
          { html: A.slotHtml(j[2]), a: 'c', v: j[2] },
          { html: j[4].map(([tid, pt]) => { const t = A.data.skills.trees.find(x => x[0] === tid); return `<span class="tag on">${A.esc(t ? t[1] : tid)} ${pt > 0 ? '+' : ''}${pt}</span>`; }).join(' '), v: j[4][0] ? j[4][0][1] : 0 }
        ]);
        const t = A.table({
          cols: [{ t: '装饰品', k: 0, w: 130 }, { t: '孔', a: 'c', k: 1, w: 52 }, { t: '技能', k: 2, w: 140 }],
          rows, onRow: r => jewelSheet(r.__j)
        });
        rows.forEach((r, i) => { r.__j = list[i]; });
        body.appendChild(t.el);
      }
      paint();
    }
  });

  function jewelSheet(j) {
    if (!j) return;
    const rec = A.data.recipes['j' + j[0]] || [];
    let h = `<div class="detail-head"><div class="pic sq">${A.itemIcon(j[3], 64)}</div>
      <div class="grow"><h2>${A.esc(j[1])}</h2><div class="meta"><span>孔位 ${A.slotHtml(j[2])}</span></div></div></div>`;
    h += A.card(A.sec('技能') + `<table class="grid"><tbody>${j[4].map(([tid, pt]) => {
      const t = A.data.skills.trees.find(x => x[0] === tid);
      return `<tr data-skl="${tid}"><td>${A.esc(t ? t[1] : tid)}</td><td class="num res-p">+${pt}</td></tr>`;
    }).join('')}</tbody></table>`);
    if (rec.length) h += A.matTable(rec, '生产素材');
    A.sheet(j[1], h);
    A.$('#sheet-live').addEventListener('click', e => {
      const it = e.target.closest('[data-item]'); if (it) return A.itemSheet(it.dataset.item);
      const s = e.target.closest('[data-skl]'); if (s) return skillSheet(+s.dataset.skl);
    });
  }
  A.jewelSheet = jewelSheet;

  /* ================= 道具 ================= */
  A.route('items', {
    title: '道具', sub: '', load: ['items', 'item_icons', 'item_src', 'labels'],
    mount(view, params) {
      const I = A.data.items;
      let rare = '0', keyword = '', only = 'all';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      const rareChips = [['0', '全部']].concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(r => [String(r), 'R' + r]));
      head.appendChild(A.chips(rareChips, rare, v => { rare = v; paint(); }));
      head.appendChild(A.row(A.select([['all', '全部道具'], ['use', '可调和'], ['src', '有采集/掉落']], only, v => { only = v; paint(); })));
      A.setSearch('搜索道具…', v => { keyword = v.trim(); paint(); });
      function paint() {
        let list = I.filter(it => (!+rare || it[2] === +rare) && (!keyword || it[1].indexOf(keyword) >= 0));
        if (only !== 'all') list = list.filter(it => {
          const s = A.data.item_src[String(it[0])];
          if (!s) return false;
          if (only === 'use') return s.c && s.c.length;
          return (s.m && s.m.length) || (s.l && s.l.length);
        });
        A.setTitle('道具', `${list.length.toLocaleString()} / ${I.length.toLocaleString()}`);
        body.innerHTML = '';
        const rows = list.map(it => [
          { html: `<span class="nm">${A.esc(it[1])}</span>`, v: it[1] },
          { t: it[2], a: 'c', v: it[2] },
          { t: it[3], a: 'r', v: it[3] },
          { t: A.fmt(it[4]), a: 'r', v: it[4] },
          { t: A.fmt(it[5]), a: 'r', v: it[5] }
        ]);
        const t = A.table({
          cols: [{ t: '道具', k: 0, w: 160 }, { t: '稀', a: 'c', k: 1, w: 34 }, { t: '上限', a: 'r', k: 2, w: 44 },
          { t: '卖价', a: 'r', k: 3, w: 60 }, { t: '买价', a: 'r', k: 4, w: 60 }],
          rows, onRow: r => A.itemSheet(r.__i[0])
        });
        rows.forEach((r, i) => { r.__i = list[i]; });
        // 名字前加图标
        rows.forEach((r, i) => { r[0] = { html: `<span class="nm ico-row">${A.itemIcon(list[i][0], 26)}<span>${A.esc(list[i][1])}</span></span>`, v: list[i][1] }; });
        t.setRows(rows);
        body.appendChild(t.el);
      }
      paint();
      if (params.id) A.itemSheet(params.id);
    }
  });

  /* ================= 调和 ================= */
  A.route('combo', {
    title: '调和', sub: '', load: ['combo', 'items', 'item_icons'],
    mount(view) {
      const C = A.data.combo;
      let keyword = '';
      const body = document.createElement('div');
      view.appendChild(body);
      A.setSearch('搜索结果或素材…', v => { keyword = v.trim(); paint(); });
      const M = A.byId('items');
      const nm = id => A.esc((M.get(id) || [0, '?'])[1]);
      function paint() {
        const list = C.filter(c => !keyword || nm(c[1]).indexOf(keyword) >= 0 || nm(c[2]).indexOf(keyword) >= 0 || nm(c[3]).indexOf(keyword) >= 0);
        A.setTitle('调和', `${list.length} / ${C.length}`);
        body.innerHTML = '';
        const rows = list.map(c => [
          { html: `<span class="nm ico-row">${A.itemIcon(c[1], 26)}<span>${nm(c[1])}</span></span>`, v: nm(c[1]) },
          { html: `${A.itemIcon(c[2], 22)}${nm(c[2])}`, v: nm(c[2]) },
          { html: `${A.itemIcon(c[3], 22)}${nm(c[3])}`, v: nm(c[3]) },
          { t: c[4] + '%', a: 'r', v: c[4] },
          { t: c[5], a: 'r', v: c[5] }
        ]);
        const t = A.table({
          cols: [{ t: '结果', k: 0, w: 108 }, { t: '道具A', k: 1, w: 94 }, { t: '道具B', k: 2, w: 94 },
          { t: '成功率', a: 'r', k: 3, w: 48 }, { t: '数量', a: 'r', k: 4, w: 34 }],
          rows, onRow: r => A.itemSheet(r.__c[1])
        });
        rows.forEach((r, i) => { r.__c = list[i]; });
        body.appendChild(t.el);
      }
      paint();
    }
  });

  /* ================= 技能 ================= */
  A.route('skills', {
    title: '技能', sub: '', load: ['skills', 'armor', 'jewels', 'labels'],
    mount(view, params) {
      const S = A.data.skills;
      let keyword = '', cat = '0';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      head.appendChild(A.chips([['0', '全部'], ['1', '攻击系'], ['2', '防御系'], ['3', '辅助系'], ['4', '其他']], cat, v => { cat = v; paint(); }));
      A.setSearch('搜索技能…', v => { keyword = v.trim(); paint(); });
      function paint() {
        const list = S.trees.filter(t => !keyword || t[1].indexOf(keyword) >= 0 || t[3].some(n => n.indexOf(keyword) >= 0));
        A.setTitle('技能', `${list.length} 个技能系统`);
        body.innerHTML = '';
        const rows = list.map(t => [
          { html: `<span class="nm">${A.esc(t[1])}</span>`, v: t[1] },
          { t: t[2].filter(x => x > 0).join('/'), a: 'c', v: t[2].filter(x => x > 0).length },
          { html: `<span class="dim">${t[3].map(n => A.esc(n)).join(' → ')}</span>`, v: t[3].length }
        ]);
        const tb = A.table({
          cols: [{ t: '技能系统', k: 0, w: 96 }, { t: '点数', a: 'c', k: 1, w: 62 }, { t: '等级效果', k: 2, w: 180 }],
          rows, onRow: r => skillSheet(r.__t[0])
        });
        rows.forEach((r, i) => { r.__t = list[i]; });
        body.appendChild(tb.el);
      }
      paint();
      if (params.id) skillSheet(+params.id);
    }
  });

  function skillSheet(tid) {
    const S = A.data.skills;
    const t = S.trees.find(x => x[0] === tid);
    if (!t) return;
    const levels = t[2].filter(x => x > 0);
    const names = t[3];
    let h = `<div class="detail-head"><div class="grow"><h2>${A.esc(t[1])}</h2>
      <div class="meta"><span>最高 Lv.${names.length}</span><span>发动所需 ${levels[0]} 点</span></div></div></div>`;
    h += A.card(A.sec('等级') + `<table class="grid"><tbody>${names.map((n, i) =>
      `<tr><td class="num dim">Lv.${i + 1}</td><td>${A.esc(n)}</td><td class="num dim">${levels[i]} 点</td></tr>`).join('')}</tbody></table>`);
    const desc = S.desc[String(tid)];
    if (desc) h += A.card(A.sec('说明') + `<div class="pad text">${A.esc(desc)}</div>`);
    // 提供该技能的防具
    const AR = A.data.armor.filter(a => a[12].some(([x]) => x === tid));
    if (AR.length) {
      h += A.card(A.sec(`防具（${AR.length}）`) + `<table class="grid"><tbody>${AR.slice(0, 40).map(a =>
        `<tr data-armor="${a[0]}"><td>${A.esc(a[2])}</td><td class="num res-p">+${a[12].find(([x]) => x === tid)[1]}</td><td class="num dim">防 ${a[5]}</td></tr>`).join('')}</tbody></table>`
        + (AR.length > 40 ? `<div class="dim pad">共 ${AR.length} 件</div>` : ''));
    }
    const J = A.data.jewels.filter(j => j[4].some(([x]) => x === tid));
    if (J.length) {
      h += A.card(A.sec(`装饰品（${J.length}）`) + `<table class="grid"><tbody>${J.map(j =>
        `<tr data-jew="${j[0]}"><td>${A.esc(j[1])}</td><td class="num res-p">+${j[4].find(([x]) => x === tid)[1]}</td><td class="num dim">${j[2]}孔</td></tr>`).join('')}</tbody></table>`);
    }
    A.sheet(t[1], h);
    A.$('#sheet-live').addEventListener('click', e => {
      const a = e.target.closest('[data-armor]'); if (a) return armorSheet(A.byId('armor').get(+a.dataset.armor));
      const j = e.target.closest('[data-jew]'); if (j) return jewelSheet(A.data.jewels.find(x => x[0] === +j.dataset.jew));
    });
  }
  A.skillSheet = skillSheet;
})();
