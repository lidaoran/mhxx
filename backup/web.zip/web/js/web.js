/* web.js — 网页版渲染层
   左侧目录 + 右侧内容；表格列取自 exe 反编译的 DataGridView 列定义，
   图片全部使用原程序内嵌素材（img/w、img/a、img/m、img/k、img/icon/items.png、img/i）。 */
(function () {
  'use strict';
  var CD = window.ClassicData;
  var S = null, D = null;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var view = $('#view'), navEl = $('#nav'), crumb = $('#crumb');
  var esc = CD.esc;

  var TYPES = ['大剑', '太刀', '片手剑', '双剑', '大锤', '狩猎笛', '长枪', '铳枪',
    '斩击斧', '充能斧', '操虫棍', '轻弩', '重弩', '弓'];
  var PARTS = ['', '头', '胴', '腕', '腰', '脚'];
  var L = function (k) { return (D && D.labels && D.labels[k]) || {}; };

  /* ---------------- 小工具 ---------------- */
  function pad(n, w) { n = String(n); while (n.length < w) n = '0' + n; return n; }
  function num(v) { return v == null || v === '' || v === 0 ? '<span class="dim">-</span>' : String(v); }
  function itemIcon(id, px) { return CD.itemIcon(id, px || 16); }
  function qIcon(t) { return t >= 1 && t <= 7 ? 'img/i/Qst_Type_' + t + '.png' : ''; }
  function locIcon(id) { return id >= 1 && id <= 27 ? 'img/i/Loc_' + pad(id, 2) + '.png' : ''; }
  function noteIcon(n) { return n >= 1 && n <= 8 ? 'img/i/HHNote_' + n + '.png' : ''; }
  function awdIcon(id) { return id >= 1 && id <= 132 ? 'img/i/Awd_' + pad(id, 3) + '.png' : ''; }
  var STAT_ICON = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10, 11: 11, 13: 13 };

  function elemTag(name) {
    if (!name) return '<span class="tag">无属性</span>';
    return '<span class="tag g">' + esc(name) + '</span>';
  }
  function slotDots(n) {
    if (!n) return '<span class="dim">—</span>';
    var s = '';
    for (var i = 0; i < n; i++) s += '◯';
    return s;
  }
  function resNum(v) {
    v = v || 0;
    return v > 0 ? '<span style="color:#b7791f">+' + v + '</span>'
      : v < 0 ? '<span style="color:#c0392b">' + v + '</span>'
        : '<span class="dim">0</span>';
  }

  /* ---------------- 左侧目录 ---------------- */
  var NAV = [
    ['图鉴', [
      ['wpn', '武器', 'M14 4l6 6-9 9H5v-6z'],
      ['amr', '防具', 'M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z'],
      ['jew', '装饰品', 'M12 3l3 6 6 1-4.5 4.5L18 21l-6-3-6 3 1.5-6.5L3 10l6-1z'],
      ['itm', '道具', 'M6 8h12l-1 12H7zM9 8V6a3 3 0 016 0v2'],
      ['skl', '技能', 'M4 18V9m5 9V5m5 13v-6m5 6V7'],
      ['cbo', '调和', 'M6 4h12M6 8h12M9 12l6 8M15 12l-6 8']
    ]],
    ['狩猎资料', [
      ['qst', '任务', 'M7 4h10v16l-5-3-5 3z'],
      ['mon', '怪物', 'M4 10c0-3 3-5 8-5s8 2 8 5-3 5-8 5-8-2-8-5zM8 7L6 4m12 3l-2-3'],
      ['loc', '地图', 'M9 4l6 2 6-2v14l-6 2-6-2-6 2V6z'],
      ['song', '笛旋律', 'M9 18V6l8-2v12M9 18a2 2 0 11-4 0 2 2 0 014 0zm8-2a2 2 0 11-4 0 2 2 0 014 0z'],
      ['ammo', '弩弹药', 'M8 21V9l4-6 4 6v12z'],
      ['kinsect', '猎虫', 'M12 7a3 3 0 100 6 3 3 0 000-6zM12 3v4m0 6v8M5 8l4 2m10-2l-4 2M5 16l4-2m10 2l-4-2']
    ]],
    ['随从与交易', [
      ['peliwpn', '随从武器', 'M5 12c0-4 3-6 7-6s7 2 7 6-3 8-7 8-7-4-7-8zm3-3l-1-3m9 3l1-3'],
      ['peliamr', '随从防具', 'M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6zM9 11h6'],
      ['peliteam', '猛喵队', 'M5 9l2-5 3 3h4l3-3 2 5v6a5 5 0 01-5 5h-4a5 5 0 01-5-5z'],
      ['hfh', '游荡猎人', 'M4 7h16l-2 10H6zM9 3v4m6-4v4'],
      ['vet', '山菜爷爷', 'M12 3c3 3 5 6 5 9a5 5 0 01-10 0c0-3 2-6 5-9zM12 8v9'],
      ['ara', '斗技大会', 'M12 3l2.2 4.5 5 .7-3.6 3.5.9 4.9L12 14.3 7.5 16.6l.9-4.9L4.8 8.2l5-.7z']
    ]],
    ['配装与收藏', [
      ['asb', '套装模拟器', 'M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z'],
      ['asf', '套装配装器', 'M11 4a7 7 0 104.9 12l4.1 4.1'],
      ['awd', '勋章', 'M12 3l2.5 5.5L20 9l-4 4 .8 6-4.8-2.6L7.2 19 8 13 4 9l5.5-.5z'],
      ['about', '关于', 'M12 8h.01M11 12h1v5h1M12 3a9 9 0 100 18 9 9 0 000-18z']
    ]]
  ];
  var CNT = {};
  function navItem(k, name, path) {
    var n = CNT[k];
    return '<a class="nv" data-go="' + k + '" href="#/' + k + '">' +
      '<i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
      'stroke-linecap="round" stroke-linejoin="round"><path d="' + path + '"/></svg></i>' +
      '<span>' + name + '</span>' + (n ? '<b>' + n + '</b>' : '') + '</a>';
  }
  function buildNav() {
    var h = '';
    NAV.forEach(function (g) {
      h += '<div class="nav-g" data-g>' + g[0] + '</div>';
      g[1].forEach(function (it) { h += navItem(it[0], it[1], it[2]); });
    });
    navEl.innerHTML = h;
  }

  /* ---------------- 通用表格 ---------------- */
  function colsOf(t) {
    return (S.tables[t] || []).filter(function (c) { return c.v; }).map(function (c) {
      var o = { c: c.c, h: c.h || '', w: c.w, num: c.a === 64, img: c.i === 1 };
      if (!o.h) o.h = HEAD_FIX[c.c] || '';
      return o;
    });
  }
  var HEAD_FIX = {
    Res_Fire: '火', Res_Water: '水', Res_Ice: '冰', Res_Thunder: '雷', Res_Dragon: '龙',
    MonPart_Num: '#', Cut: '斩', Impact: '打', Shot: '射',
    Fir: '火', Wtr: '水', Thd: '雷', Drg: '龙', Diz: '气绝',
    Duration: '持续', DurationEnraged: '愤怒', DurationFatigued: '疲劳',
    TolInitial: '初始', TolIncrease: '增量', TolMax: '最大', Damage: '伤害',
    IsEffect_Text: '效果', MonPart_Name: '部位', MonPartCond_Name: '条件',
    DGVImgCol_Wpn: '图', DGVImgCol_Amr: '图', DGVImgCol_Itm: '', DGVImgCol_ItmP: '',
    DGVImgCol_ItmU: '', DGVImgCol_ItmGun: '', DGVImgCol_Mon: '图', DGVImgCol_WpnHHNote1: '♪',
    DGVImgCol_WpnHHNote2: '♪', DGVImgCol_WpnHHNote3: '♪', DGVImgCol_WpnHHNote4: '♪',
    DGVImgCol_HHSongNote1: '♪', DGVImgCol_HHSongNote2: '♪', DGVImgCol_HHSongNote3: '♪',
    DGVImgCol_HHSongNote4: '♪', DGVImgCol_WpnNote1: '♪', DGVImgCol_WpnNote2: '♪',
    DGVImgCol_WpnNote3: '♪', DGVImgCol_AmrBG: '背', DGVImgCol_Ail: '', DGVImgCol_Trap: ''
  };

  var NAME_HEADS = { '怪物': 1, '武器': 1, '防具': 1, '道具': 1, '装饰品': 1, '随从武器': 1, '随从防具': 1 };

  function cellHTML(col, r) {
    if (col.render) return col.render(r);
    if (col.img) {
      var ic = r._icons ? (r._icons[col.c] || '') : (r._icon || '');
      // 原版有些列既放图标又当名称列（如「怪物」），这里补上文本
      if (col.h && NAME_HEADS[col.h]) {
        var f = col.c.replace('DGVImgCol_', '');
        var nm = r[f + '_Name'];
        if (nm) ic += ' ' + esc(nm);
      }
      return ic;
    }
    var v = r[col.c];
    if (v == null || v === '') return '<span class="dim">-</span>';
    if (v === 0 && col.num && !col.keep0) return '<span class="dim">-</span>';
    return esc(v);
  }

  /* ---------------- 页面配置 ---------------- */
  var RARE_OPTS = [['', '全部稀有度']].concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(function (n) { return [String(n), '稀有 ' + n]; }));
  var PELI_PART = { 11: '头', 12: '胴', 13: '腕', 14: '腰', 15: '脚' };

  var PAGES = {
    wpn: {
      t: '武器', sub: '全部武器 · 列与筛选对应原版武器窗体', table: '_DGV_WpnList', wide: true,
      filters: [
        { k: 'type', l: '类型', t: 'select', d: '0', o: function () { return [['0', '全部类型']].concat(TYPES.map(function (n, i) { return [String(i + 1), n]; })); } },
        { k: 'elem', l: '属性', t: 'chips', d: '', o: [['', '全部'], ['0', '无'], ['1', '火'], ['2', '水'], ['3', '雷'], ['4', '冰'], ['5', '龙'], ['6', '毒'], ['7', '麻痹'], ['8', '睡眠'], ['9', '爆破']] },
        { k: 'rare', l: '稀有度', t: 'select', d: '', o: RARE_OPTS },
        { k: 'final', l: '仅终形态', t: 'check' },
        { k: 'q', t: 'search', ph: '搜索武器名…' }
      ],
      row: function (r, f) {
        var w = r._raw;
        if (f.type && f.type !== '0' && w[1] !== +f.type) return false;
        if (f.elem === '0') { if ((w[5] || []).length) return false; }
        else if (f.elem) { if (!(w[5] || []).some(function (e) { return e[0] === +f.elem; })) return false; }
        if (f.rare && r.Rare !== +f.rare) return false;
        if (f.final && w[11] !== 0) return false;
        if (f.q && String(r.Wpn_Name).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        var t = +(ST.f.type || 0);
        var nar = window.innerWidth < 720;
        var base = [
          { c: 'Wpn_ID', h: '#', w: nar ? 34 : 40, num: true },
          { c: 'Wpn_Name', h: '武器', nm: 1, w: nar ? 132 : 172 },
          { c: 'Rare', h: '稀有', w: nar ? 36 : 44, num: true },
          { c: 'Atk', h: '威力', w: nar ? 44 : 50, num: true },
          { c: 'SpAtk_Name', h: '属性', w: nar ? 54 : 78, render: function (r) { return r.SpAtk_Name ? '<span class="gold">' + esc(r.SpAtk_Name) + '</span>' : '<span class="dim">无</span>'; } },
          { c: 'Affinity', h: '会心', w: 48, num: true, sm: 0, render: function (r) { return r.Affinity ? (r.Affinity > 0 ? '+' : '') + r.Affinity + '%' : '<span class="dim">0%</span>'; } },
          { c: 'Def', h: '防御', w: 44, num: true, sm: 0 },
          { c: 'Slot', h: '孔', w: 36, sm: 0, render: function (r) { return slotDots(r.Slot); } },
          { c: '_sharp', h: '斩味', w: nar ? 88 : 104, render: function (r) { return r._sharp || '<span class="dim">-</span>'; } }
        ];
        var extra = [];
        if (t === 6) {
          extra.push({ c: '_note', h: '音符', w: 74, render: function (r) { return notes(r._raw[14]); } });
        }
        if (t === 8) extra.push({ c: 'GLShotType_Name', h: '炮击', w: 70 });
        if (t === 9 || t === 10) extra.push({ c: 'AxePhial_Name', h: '瓶', w: 78 });
        if (t === 11) extra.push({ c: 'ISKinsectType_Name', h: '猎虫', w: 62 });
        if (t === 12 || t === 13) {
          extra.push({ c: 'GunReloadSpd_Name', h: '装填', w: 62 });
          extra.push({ c: 'GunRecoil_Name', h: '后坐力', w: 66 });
          extra.push({ c: 'GunSteadiness_Name', h: '摇晃', w: 66 });
        }
        if (t === 14) {
          extra.push({ c: 'BowShot_Name', h: '弓射击', w: 74 });
          extra.push({ c: '_arc', h: '蓄力段', w: 96, render: function (r) { return arcs(r._raw[17]); } });
        }
        return base.concat(extra, [
          { c: 'ProPx', h: '生产价', w: 68, num: true, sm: 0 }
        ]);
      },
      detail: wpnDetail
    },

    amr: {
      t: '防具', sub: '全部防具 · 含技能点与生产素材', table: '_DGV_AmrList',
      filters: [
        { k: 'part', l: '部位', t: 'chips', d: '', o: [['', '全部'], ['1', '头'], ['2', '胴'], ['3', '腕'], ['4', '腰'], ['5', '脚']] },
        { k: 'rare', l: '稀有度', t: 'select', d: '', o: RARE_OPTS },
        { k: 'sex', l: '性别', t: 'select', d: '', o: [['', '全部'], ['0', '共通'], ['1', '男'], ['2', '女']] },
        { k: 'q', t: 'search', ph: '搜索防具名 / 系列…' }
      ],
      row: function (r, f) {
        if (f.part && r.Part !== +f.part) return false;
        if (f.rare && r.Rare !== +f.rare) return false;
        if (f.sex === '0' && r.MorF !== 0) return false;
        if (f.sex === '1' && r.MorF !== 1) return false;
        if (f.sex === '2' && r.MorF !== 2) return false;
        if (f.q && String(r.Amr_Name).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'Amr_ID', h: '#', w: 44, num: true },
          { c: 'Amr_Name', h: '防具', nm: 1, w: 150 },
          { c: 'Part', h: '部位', w: 46, render: function (r) { return PARTS[r.Part] || ''; } },
          { c: 'Rare', h: '稀有', w: 40, num: true },
          { c: 'Slot', h: '孔', w: 42, render: function (r) { return slotDots(r.Slot); } },
          { c: 'Def', h: '防御', w: 50, num: true },
          { c: 'MaxDef', h: '满防御', w: 58, num: true, sm: 0 },
          { c: 'Res_Fire', h: '火', w: 34, num: true, keep0: 1, sm: 0, render: function (r) { return resNum(r.Res_Fire); } },
          { c: 'Res_Water', h: '水', w: 34, num: true, keep0: 1, sm: 0, render: function (r) { return resNum(r.Res_Water); } },
          { c: 'Res_Thunder', h: '雷', w: 34, num: true, keep0: 1, sm: 0, render: function (r) { return resNum(r.Res_Thunder); } },
          { c: 'Res_Ice', h: '冰', w: 34, num: true, keep0: 1, sm: 0, render: function (r) { return resNum(r.Res_Ice); } },
          { c: 'Res_Dragon', h: '龙', w: 34, num: true, keep0: 1, sm: 0, render: function (r) { return resNum(r.Res_Dragon); } },
          { c: 'Price', h: '生产价', w: 64, num: true, sm: 0 }
        ];
      },
      detail: amrDetail
    },

    jew: {
      t: '装饰品', sub: '装饰珠 · 技能点与所需素材', table: '_DGV_JewList',
      filters: [
        { k: 'slot', l: '孔位', t: 'chips', d: '', o: [['', '全部'], ['1', '1 孔'], ['2', '2 孔'], ['3', '3 孔']] },
        { k: 'q', t: 'search', ph: '搜索装饰珠 / 技能…' }
      ],
      row: function (r, f) {
        if (f.slot && r.Slot !== +f.slot) return false;
        if (f.q) {
          var s = (r.Jew_Name + ' ' + r.SklTree1_Name + ' ' + r.SklTree2_Name).toLowerCase();
          if (s.indexOf(f.q) < 0) return false;
        }
        return true;
      },
      detail: jewDetail
    },

    itm: {
      t: '道具', sub: '全部道具 · 用途与获取来源', table: '_DGV_ItmList',
      filters: [
        { k: 'rare', l: '稀有度', t: 'select', d: '', o: RARE_OPTS },
        { k: 'q', t: 'search', ph: '搜索道具名…' }
      ],
      row: function (r, f) {
        if (f.rare && r.Rare !== +f.rare) return false;
        if (f.q && String(r.Itm_Name).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_ItmList', h: '', w: 30, img: 1 },
          { c: 'Itm_ID', h: '#', w: 50, num: true },
          { c: 'Itm_Name', h: '道具', nm: 1, w: 200 },
          { c: 'Rare', h: '稀有', w: 52, num: true },
          { c: 'Max', h: '持有上限', w: 78, num: true, sm: 0 },
          { c: 'Sell', h: '卖价', w: 70, num: true, sm: 0 },
          { c: 'Buy', h: '买价', w: 70, num: true, sm: 0 },
          { c: 'Hex', h: 'HEX', w: 66, sm: 0 }
        ];
      },
      detail: itmDetail
    },

    cbo: {
      t: '调和', sub: '调和配方 · 成功率与产出数量', table: '_DGV_CboList',
      filters: [{ k: 'q', t: 'search', ph: '搜索结果 / 材料…' }],
      row: function (r, f) {
        if (!f.q) return true;
        return (r.ItmC_Name + ' ' + r.ItmA_Name + ' ' + r.ItmB_Name).toLowerCase().indexOf(f.q) >= 0;
      },
      detail: cboDetail
    },

    skl: {
      t: '技能', sub: '技能系统 · 等级效果与可出装备', table: '_DGV_SklList',
      filters: [{ k: 'q', t: 'search', ph: '搜索技能系统 / 技能名…' }],
      row: function (r, f) {
        if (!f.q) return true;
        var s = r.SklTree_Name + ' ';
        for (var i = 0; i < 7; i++) s += (r['Skl' + i] || '') + ' ';
        return s.toLowerCase().indexOf(f.q) >= 0;
      },
      cols: function () { return sklCols(); },
      detail: sklDetail
    },

    qst: {
      t: '任务', sub: '全部任务 · 报酬分组 A~D', table: '_DGV_QstList',
      filters: [
        { k: 'lv', l: '等级', t: 'select', d: '', o: function () { return [['', '全部等级']].concat(Object.keys(L('qstLv')).map(function (k) { return [k, L('qstLv')[k]]; })); } },
        { k: 'type', l: '类型', t: 'select', d: '', o: function () { return [['', '全部类型']].concat(Object.keys(L('qstType')).map(function (k) { return [k, L('qstType')[k]]; })); } },
        { k: 'loc', l: '地图', t: 'select', d: '', o: function () { return [['', '全部地图']].concat((D.maps.locs || []).map(function (x) { return [String(x[0]), x[1]]; })); } },
        { k: 'q', t: 'search', ph: '搜索任务名 / 目标…' }
      ],
      row: function (r, f) {
        var q = r._raw;
        if (f.lv && q[2] !== +f.lv) return false;
        if (f.type && q[3] !== +f.type) return false;
        if (f.loc && q[4] !== +f.loc) return false;
        if (f.q && (q[1] + ' ' + (q[6] || '')).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'Qst_ID', h: '#', w: 48, num: true },
          { c: 'Qst_Lv', h: '等级', w: 64, render: function (r) { return esc(L('qstLv')[r.Qst_Lv] || r.Qst_Lv); } },
          { c: 'Qst_Name', h: '任务', nm: 1, w: 236 },
          { c: 'Qst_Key', h: '关键', w: 48, sm: 0 },
          { c: 'Qst_Type', h: '类型', w: 86, render: function (r) { return qType(r._raw[3]); } },
          { c: 'Loc_Name', h: '地图', w: 104, sm: 0, render: function (r) { return locName(r._raw[4], r.Loc_Name); } },
          { c: 'Qst_Goal', h: '目标', w: 226, sm: 0 },
          { c: 'Fee', h: '受理费', w: 68, num: true, sm: 0 },
          { c: 'Time', h: '时间', w: 50, num: true, sm: 0 },
          { c: 'Reward', h: '报酬金', w: 70, num: true, sm: 0 },
          { c: 'HRP', h: 'HRP', w: 56, num: true, sm: 0 }
        ];
      },
      detail: qstDetail
    },

    mon: {
      t: '怪物', sub: '肉质 · 异常耐性 · 陷阱 · 掉落', table: '_DGV_MonList',
      filters: [{ k: 'q', t: 'search', ph: '搜索怪物名…' }],
      row: function (r, f) { return !f.q || String(r.Mon_Name).toLowerCase().indexOf(f.q) >= 0; },
      cols: function () {
        return [
          { c: 'DGVImgCol_Mon', h: '', w: 34, img: 1 },
          { c: 'Mon_ID', h: '#', w: 44, num: true },
          { c: 'Mon_Name', h: '怪物', nm: 1, w: 170 }
        ];
      },
      detail: monDetail
    },

    loc: {
      t: '地图', sub: '采集点 · 按难度分组', table: null,
      filters: [
        { k: 'loc', l: '地图', t: 'select', d: '1', o: function () { return (D.maps.locs || []).map(function (x) { return [String(x[0]), x[1]]; }); } },
        { k: 'rank', l: '难度', t: 'chips', d: '1', o: [['1', '下位'], ['2', '上位'], ['3', 'G级']] }
      ],
      special: locView
    },

    song: {
      t: '笛旋律', sub: '旋律效果 · 可演奏武器', table: '_DGV_HHSongList',
      filters: [
        { k: 'cat', l: '分类', t: 'select', d: '', o: function () { return [['', '全部分类']].concat(Object.keys(L('songCat')).map(function (k) { return [k, L('songCat')[k]]; })); } },
        { k: 'q', t: 'search', ph: '搜索旋律效果…' }
      ],
      row: function (r, f) {
        if (f.cat && r.Category1_Name !== L('songCat')[f.cat]) return false;
        if (f.q && String(r['旋律效果']).indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'HHSong_ID', h: '#', w: 46, num: true },
          { c: '_n', h: '音符', w: 96, render: function (r) { return notes(r._raw[2]); } },
          { c: '旋律效果', h: '旋律效果', nm: 1, w: 210 },
          { c: '持续时间', h: '时长', w: 66, num: true, sm: 0 },
          { c: '吹笛名人', h: '吹笛名人', w: 88, num: true, sm: 0 },
          { c: '重奏效果', h: '重奏效果', nm: 1, w: 210, sm: 0 },
          { c: 'Category1_Name', h: '分类', w: 76, sm: 0 }
        ];
      },
      detail: songDetail
    },

    ammo: {
      t: '弩弹药', sub: '轻弩 / 重弩 弹药装填与速射', table: '_DGV_BGAmmoList', wide: true,
      filters: [
        { k: 'type', l: '武器', t: 'chips', d: '12', o: [['12', '轻弩'], ['13', '重弩'], ['0', '全部']] },
        { k: 'q', t: 'search', ph: '搜索弩名…' }
      ],
      row: function (r, f) {
        if (f.type && f.type !== '0' && r.Wpn_Type_ID !== +f.type) return false;
        if (f.q && String(r['武器']).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () { return ammoCols(); },
      detail: ammoDetail
    },

    kinsect: {
      t: '猎虫', sub: '猎虫 · 虫技能 / 精华 / 强化素材', table: '_DGV_ISKinsectList',
      filters: [
        { k: 'type', l: '类型', t: 'chips', d: '', o: [['', '全部'], ['1', '切断'], ['2', '打击']] }
      ],
      row: function (r, f) {
        if (f.type && r._raw[2] - 30 !== +f.type) return false;
        return true;
      },
      defaultRow: function (rows) {
        for (var i = 0; i < rows.length; i++) {
          var k = rows[i]._raw;
          if ((k[5] || []).length && (k[6] || []).length) return i;
        }
        for (var j = 0; j < rows.length; j++) {
          if ((rows[j]._raw[5] || []).length) return j;
        }
        return 0;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_Kin', h: '', w: 40, render: function (r) { return kinImg(r._raw[4], 28); } },
          { c: 'ISKinsect_ID', h: '#', w: 50, num: true },
          { c: '猎虫', h: '猎虫', nm: 1, w: 190 },
          { c: '类型', h: '类型', w: 70 },
          { c: '稀有度', h: '稀有', w: 56, num: true }
        ];
      },
      detail: kinDetail
    },

    peliwpn: {
      t: '随从武器', sub: '随从（艾露）武器', table: '_DGV_PeliWpnList',
      filters: [
        { k: 'type', l: '类型', t: 'chips', d: '', o: [['', '全部'], ['1', '平衡'], ['2', '近战特化'], ['3', '回力标特化']] },
        { k: 'q', t: 'search', ph: '搜索随从武器…' }
      ],
      row: function (r, f) {
        if (f.type && r._raw[2] !== +f.type) return false;
        if (f.q && String(r['随从武器']).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_PW', h: '', w: 42, render: function (r) { return peliWImg(r._raw[4], 28); } },
          { c: 'PeliWpn_ID', h: '#', w: 48, num: true },
          { c: '随从武器', h: '随从武器', nm: 1, w: 180 },
          { c: '类型', h: '类型', w: 88 },
          { c: '稀有度', h: '稀有', w: 52, num: true },
          { c: '近身', h: '近身', w: 58, num: true },
          { c: '远程', h: '远程', w: 58, num: true },
          { c: '属性', h: '属性', w: 74 },
          { c: '防御', h: '防御', w: 56, num: true },
          { c: '生产价', h: '生产价', w: 70, num: true }
        ];
      },
      detail: peliWDetail
    },

    peliamr: {
      t: '随从防具', sub: '随从（艾露）防具', table: '_DGV_PeliAmrList',
      filters: [
        { k: 'part', l: '部位', t: 'chips', d: '', o: [['', '全部'], ['11', '头'], ['12', '胴'], ['13', '腕'], ['14', '腰'], ['15', '脚']] },
        { k: 'q', t: 'search', ph: '搜索随从防具…' }
      ],
      row: function (r, f) {
        if (f.part && r.Part !== +f.part) return false;
        if (f.q && String(r['随从防具']).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_PA', h: '', w: 42, render: function (r) { return peliAImg(r._raw[6], 28); } },
          { c: 'PeliAmr_ID', h: '#', w: 48, num: true },
          { c: '随从防具', h: '随从防具', nm: 1, w: 180 },
          { c: 'Part', h: '部位', w: 60, render: function (r) { return PELI_PART[r.Part] || ''; } },
          { c: '稀有度', h: '稀有', w: 52, num: true },
          { c: '防御', h: '防御', w: 56, num: true },
          { c: 'Res_Fire', h: '火', w: 40, num: true },
          { c: 'Res_Water', h: '水', w: 40, num: true },
          { c: 'Res_Thunder', h: '雷', w: 40, num: true },
          { c: 'Res_Ice', h: '冰', w: 40, num: true },
          { c: 'Res_Dragon', h: '龙', w: 40, num: true }
        ];
      },
      detail: peliADetail
    },

    peliteam: {
      t: '猛喵队', sub: '猛喵队交易品 · 按地带与等级', table: '_DGV_PeliTeamList',
      filters: [
        { k: 'zone', l: '地带', t: 'select', d: '', o: function () { return [['', '全部地带']].concat(Object.keys(L('peliZone')).map(function (k) { return [k, L('peliZone')[k]]; })); } },
        { k: 'rank', l: '等级', t: 'select', d: '', o: function () { return [['', '全部等级']].concat(Object.keys(L('rank')).map(function (k) { return [k, L('rank')[k]]; })); } },
        { k: 'q', t: 'search', ph: '搜索道具…' }
      ],
      row: function (r, f) {
        if (f.zone && r['地带'] !== L('peliZone')[f.zone]) return false;
        if (f.rank && r['等级'] !== L('rank')[f.rank]) return false;
        if (f.q && String(r['道具']).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_Itm', h: '', w: 30, img: 1 },
          { c: '地带', h: '地带', w: 104 },
          { c: '等级', h: '等级', w: 120 },
          { c: '道具', h: '道具', nm: 1, w: 200 },
          { c: '数量', h: '数量', w: 60, num: true },
          { c: '概率', h: '概率', w: 60, num: true }
        ];
      },
      detail: peliTeamDetail
    },

    hfh: {
      t: '游荡猎人', sub: '交易委托 · 报酬与成功率', table: '_DGV_HfhList',
      filters: [
        { k: 'rank', l: '等级', t: 'chips', d: '', o: [['', '全部'], ['1', '下位'], ['2', '上位'], ['3', 'G级']] },
        { k: 'q', t: 'search', ph: '搜索委托 / 怪物…' }
      ],
      row: function (r, f) {
        if (f.rank && r._raw[2] !== +f.rank) return false;
        if (f.q && (r['任务'] + ' ' + r['怪物']).toLowerCase().indexOf(f.q) < 0) return false;
        return true;
      },
      cols: function () {
        return [
          { c: 'Hfh_ID', h: '#', w: 46, num: true },
          { c: '任务', h: '委托', nm: 1, w: 190 },
          { c: '等级', h: '等级', w: 62, render: function (r) { return esc(L('rank')[r['等级']] || r['等级']); } },
          { c: '地图', h: '地图', w: 96, render: function (r) { return locName(r._raw[3]); } },
          { c: '成功率', h: '成功率', w: 64, num: true },
          { c: '大成功率', h: '大成功', w: 70, num: true },
          { c: '受理费', h: '受理费', w: 66, num: true },
          { c: '追加契约金', h: '追加契约金', w: 88, num: true },
          { c: '怪物', h: '怪物', nm: 1, w: 170 }
        ];
      },
      detail: hfhDetail
    },

    vet: {
      t: '山菜爷爷', sub: '山菜爷爷交换 · 给出 / 入手', table: '_DGV_VetList',
      filters: [{ k: 'q', t: 'search', ph: '搜索道具…' }],
      row: function (r, f) {
        return !f.q || (r['道具 (给出)'] + ' ' + r['道具 (入手)']).toLowerCase().indexOf(f.q) >= 0;
      },
      cols: function () {
        return [
          { c: 'DGVImgCol_Itm', h: '', w: 30, img: 1 },
          { c: '道具 (给出)', h: '给出', nm: 1, w: 200 },
          { c: '道具 (入手)', h: '入手', nm: 1, w: 200 },
          { c: '概率', h: '概率', w: 60, num: true },
          { c: '地图', h: '地图', w: 110 }
        ];
      },
      detail: vetDetail
    },

    ara: {
      t: '斗技大会', sub: '斗技大会 · 装备与报酬', table: '_DGV_AraList',
      filters: [{ k: 'q', t: 'search', ph: '搜索任务 / 怪物…' }],
      row: function (r, f) {
        return !f.q || (r['任务'] + ' ' + r['怪物']).toLowerCase().indexOf(f.q) >= 0;
      },
      cols: function () {
        return [
          { c: 'Ara_ID', h: '#', w: 44, num: true },
          { c: '任务', h: '任务', nm: 1, w: 190 },
          { c: '报酬金', h: '报酬金', w: 76, num: true },
          { c: '人数', h: '人数', w: 50, num: true },
          { c: 'S', h: 'S', w: 40, num: true },
          { c: 'A', h: 'A', w: 40, num: true },
          { c: 'B', h: 'B', w: 40, num: true },
          { c: '怪物', h: '怪物', nm: 1, w: 200 }
        ];
      },
      detail: araDetail
    },

    awd: { t: '勋章', sub: '全部勋章 · 原版图标', special: awdView },
    asb: { t: '套装模拟器', sub: '按部位配装 · 孔位装饰珠 · 套装码', special: asbView },
    asf: { t: '套装配装器', sub: '按目标技能搜索 5 部位组合', special: asfView },
    about: { t: '关于', sub: '数据来源与版权', special: aboutView }
  };

  /* ---------------- 表格片段 ---------------- */
  function notes(arr) {
    if (!arr || !arr.length) return '<span class="dim">-</span>';
    var s = '';
    for (var i = 0; i < arr.length; i++) {
      var n = arr[i];
      if (n >= 1 && n <= 8) s += '<img src="' + noteIcon(n) + '" width="15" height="15" alt="' + n + '" title="音符 ' + n + '" style="vertical-align:-3px">';
    }
    return s || '<span class="dim">-</span>';
  }
  function arcs(arr) {
    if (!arr || !arr.length) return '<span class="dim">-</span>';
    var names = ['', '通', '扩', '放', '贯'];
    return arr.filter(function (x) { return x > 0; }).map(function (x) { return names[x] || x; }).join(' / ') || '<span class="dim">-</span>';
  }
  function qType(t) {
    var ic = qIcon(t), nm = L('qstType')[t] || '';
    return (ic ? '<img src="' + ic + '" width="14" height="14" style="vertical-align:-2px;margin-right:4px" alt="">' : '') + esc(nm);
  }
  function locName(id, fallback) {
    var ic = locIcon(id), nm = L('loc')[id] || fallback || '';
    return (ic ? '<img src="' + ic + '" width="14" height="14" style="vertical-align:-2px;margin-right:4px" alt="">' : '') + esc(nm);
  }
  function kinImg(f, px) { return f ? '<img src="img/k/' + f + '.webp" width="' + px + '" height="' + px + '" style="object-fit:contain" alt="">' : ''; }
  function peliWImg(f, px) { return f ? '<img src="img/pw/' + f + '.webp" width="' + px + '" height="' + px + '" style="object-fit:contain" alt="">' : ''; }
  function peliAImg(f, px) { return f ? '<img src="img/pa/' + f + '.webp" width="' + px + '" height="' + px + '" style="object-fit:contain" alt="">' : ''; }

  function sklCols() {
    var c = [
      { c: 'SklTree_Name', h: '技能系统', nm: 1, w: 150 },
      { c: 'Pt', h: '最大', w: 50, num: true }
    ];
    return c;
  }

  function ammoCols() {
    var c = [{ c: '武器', h: '武器', nm: 1, w: 180 }];
    var sh = L('shotType');
    for (var i = 1; i <= 17; i++) {
      c.push({
        c: 'A' + pad(i, 2), h: sh[i] || ('#' + i), w: 52, num: true,
        render: (function (n) {
          return function (r) {
            var a = r._raw[n] || [0, 0, 0];
            var t = a.filter(function (v) { return v > 0; }).join('/');
            return t || '<span class="dim">-</span>';
          };
        })(i)
      });
    }
    return c;
  }

  /* ---------------- 页面框架 ---------------- */
  var ST = { key: null, f: {}, sel: null, selIdx: -1, rows: [], sort: null, show: 260, tab: 0 };

  function filtersHTML(P) {
    var h = '<div class="fbar">';
    (P.filters || []).forEach(function (f) {
      if (f.t === 'select') {
        var opts = typeof f.o === 'function' ? f.o() : f.o;
        h += '<div class="fitem"><label>' + f.l + '</label><select data-f="' + f.k + '">' +
          opts.map(function (o) {
            return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(f.d == null ? '' : f.d) ? ' selected' : '') + '>' + esc(o[1]) + '</option>';
          }).join('') + '</select></div>';
      } else if (f.t === 'chips') {
        h += '<div class="fitem"><label>' + f.l + '</label><div class="chips" data-fg="' + f.k + '">' +
          f.o.map(function (o) {
            return '<button class="chip' + (String(o[0]) === String(f.d == null ? '' : f.d) ? ' on' : '') +
              '" data-fv="' + esc(o[0]) + '">' + esc(o[1]) + '</button>';
          }).join('') + '</div></div>';
      } else if (f.t === 'check') {
        h += '<div class="fitem"><label class="sw"><input type="checkbox" data-f="' + f.k + '"><span></span>' + f.l + '</label></div>';
      } else {
        h += '<div class="fitem"><input type="search" data-f="' + f.k + '" placeholder="' + esc(f.ph || '') + '"></div>';
      }
    });
    return h + '</div>';
  }

  function render(key) {
    var P = PAGES[key] || PAGES.about;
    ST.key = key; ST.sel = null; ST.selIdx = -1; ST.sort = null; ST.show = 260; ST.tab = 0;
    ST.f = {};
    (P.filters || []).forEach(function (f) {
      ST.f[f.k] = f.d != null ? f.d : '';
    });
    $$('.nv').forEach(function (a) { a.classList.toggle('on', a.dataset.go === key); });
    crumb.innerHTML = '<span>资料库</span><span class="sep">/</span><b>' + esc(P.t) + '</b>';
    document.title = P.t + " · Ping's MHXX Dex";

    if (P.special) {
      view.innerHTML = pageHead(P) + '<div id="special"></div>';
      P.special(P);
      return;
    }
    view.innerHTML = pageHead(P) + filtersHTML(P) +
      '<div class="split' + (P.wide ? ' wide' : '') + '">' +
      '<section class="card"><div class="tw" id="tw"></div></section>' +
      '<aside class="detail" id="det"></aside></div>';
    bindFilter();
    refresh();
  }

  function pageHead(P) {
    return '<div class="ph"><h1>' + esc(P.t) + '</h1>' +
      '<div class="sub">' + esc(P.sub || '') + '</div>' +
      '<div class="grow"></div><div class="stat" id="stat"></div></div>';
  }

  function bindFilter() {
    var P = PAGES[ST.key];
    $$('[data-f]', view).forEach(function (el) {
      var k = el.dataset.f;
      if (el.type === 'checkbox') {
        el.checked = !!ST.f[k];
        el.addEventListener('change', function () { ST.f[k] = el.checked; refresh(); });
      } else if (el.tagName === 'SELECT') {
        el.addEventListener('change', function () { ST.f[k] = el.value; refresh(); });
      } else {
        var t = null;
        el.addEventListener('input', function () {
          clearTimeout(t);
          t = setTimeout(function () { ST.f[k] = el.value.trim().toLowerCase(); refresh(); }, 180);
        });
      }
    });
    $$('[data-fg]', view).forEach(function (g) {
      var k = g.dataset.fg;
      g.addEventListener('click', function (e) {
        var b = e.target.closest('[data-fv]'); if (!b) return;
        ST.f[k] = b.dataset.fv;
        $$('[data-fv]', g).forEach(function (x) { x.classList.toggle('on', x === b); });
        refresh();
      });
    });
  }

  function computeRows() {
    var P = PAGES[ST.key];
    var all = CD.rowsFor(P.table, { form: ST.key, filters: ST.f, rank: ST.f.rank });
    var kind = CD.kindOfTable(P.table);
    for (var i = 0; i < all.length; i++) { all[i]._kind = all[i]._kind || kind; }
    var out = P.row ? all.filter(function (r) { return P.row(r, ST.f); }) : all;
    if (ST.sort) {
      var c = ST.sort.c, d = ST.sort.d;
      out = out.slice().sort(function (a, b) {
        var x = a[c], y = b[c];
        if (x == null) x = -Infinity; if (y == null) y = -Infinity;
        if (typeof x === 'number' && typeof y === 'number') return (x - y) * d;
        return String(x).localeCompare(String(y), 'zh') * d;
      });
    }
    return out;
  }

  function effectiveCols(P) {
    var cols = P.cols ? P.cols() : colsOf(P.table);
    // 窄屏隐藏次要列，保证主信息一屏可读
    if (window.innerWidth < 720) {
      cols = cols.filter(function (c) { return c.sm !== 0; });
      if (!cols.length) cols = P.cols ? P.cols() : colsOf(P.table);
    }
    return cols;
  }

  function refresh() {
    var P = PAGES[ST.key];
    ST.rows = computeRows();
    ST.show = 260;
    var st = $('#stat');
    if (st) {
      var nCol = effectiveCols(P).length;
      st.innerHTML = '共 <b>' + ST.rows.length.toLocaleString() + '</b> 条' +
        (P.table ? ' · 表格 <b>' + nCol + '</b> 列' : '');
    }
    paintTable();
    // 默认选中一行，右侧直接有内容
    if (ST.rows.length) {
      var di = P.defaultRow ? P.defaultRow(ST.rows) : 0;
      selectRow(di || 0, true);
    } else paintDetail(null);
  }

  function paintTable() {
    var P = PAGES[ST.key];
    var tw = $('#tw'); if (!tw) return;
    if (!ST.rows.length) {
      tw.innerHTML = '<div class="empty"><b>没有符合条件的记录</b>试试放宽筛选或清空搜索</div>';
      return;
    }
    var cols = effectiveCols(P);
    var rows = ST.rows.slice(0, ST.show);
    var h = '<table class="dt"><colgroup>' + cols.map(function (c, i) {
      // 最后一列不设宽，吃掉剩余空间，避免横向溢出
      var last = i === cols.length - 1;
      return '<col' + (!last && c.w ? ' style="width:' + c.w + 'px"' : '') + '>';
    }).join('') + '</colgroup><thead><tr>';
    cols.forEach(function (c, i) {
      var sortable = !c.img && !c.render;
      h += '<th class="' + (c.num ? 'num ' : '') + (sortable ? 's' : '') + '" data-s="' + i + '">' +
        (esc(c.h) || '&nbsp;') + (ST.sort && ST.sort.c === c.c ? (ST.sort.d > 0 ? ' ▲' : ' ▼') : '') + '</th>';
    });
    h += '</tr></thead><tbody>';
    h += rowsHTML(cols, rows, 0);
    h += '</tbody></table>';
    tw.innerHTML = h;
    tw.scrollTop = 0;

    $$('th.s', tw).forEach(function (th) {
      th.addEventListener('click', function () {
        var c = cols[+th.dataset.s];
        if (!c || c.render || c.img) return;
        ST.sort = ST.sort && ST.sort.c === c.c ? { c: c.c, d: -ST.sort.d } : { c: c.c, d: 1 };
        paintTable();
      });
    });
    var tbody = $('tbody', tw);
    tbody.addEventListener('click', function (e) {
      var tr = e.target.closest('tr[data-i]'); if (!tr) return;
      selectRow(+tr.dataset.i);
    });
    tw.onscroll = function () {
      if (tw.scrollTop + tw.clientHeight < tw.scrollHeight - 260) return;
      if (ST.show >= ST.rows.length) return;
      var from = ST.show;
      ST.show = Math.min(ST.rows.length, ST.show + 300);
      tbody.insertAdjacentHTML('beforeend', rowsHTML(cols, ST.rows.slice(from, ST.show), from));
    };
  }

  function rowsHTML(cols, rows, base) {
    var h = '';
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      h += '<tr data-i="' + (base + i) + '"' + (ST.sel && ST.sel._id === r._id && ST.selIdx === base + i ? ' class="on"' : '') + '>';
      for (var j = 0; j < cols.length; j++) {
        var c = cols[j];
        h += '<td class="' + (c.num ? 'num ' : '') + (c.nm ? 'nm ' : '') + '">' + cellHTML(c, r) + '</td>';
      }
      h += '</tr>';
    }
    return h;
  }

  function selectRow(i, quiet) {
    var r = ST.rows[i];
    if (!r) return;
    ST.sel = r; ST.selIdx = i;
    $$('#tw tbody tr').forEach(function (tr) { tr.classList.toggle('on', +tr.dataset.i === i); });
    paintDetail(r);
  }

  function paintDetail(r) {
    var box = $('#det'); if (!box) return;
    var P = PAGES[ST.key];
    if (!r || !P.detail) { box.innerHTML = ''; return; }
    try {
      box.innerHTML = P.detail(r);
    } catch (e) {
      console.warn(e);
      box.innerHTML = '<div class="card"><div class="empty">该记录详情渲染失败</div></div>';
    }
  }

  /* ---------------- 详情零件 ---------------- */
  function hero(o) {
    return '<div class="hero">' +
      '<div class="hero-img' + (o.tall ? ' tall' : '') + '">' + (o.badge ? '<span class="badge">' + esc(o.badge) + '</span>' : '') + o.img + '</div>' +
      '<div class="hero-txt"><h2>' + esc(o.title) + '</h2>' +
      (o.sid ? '<div class="sid">' + esc(o.sid) + '</div>' : '') +
      (o.tags && o.tags.length ? '<div class="tags">' + o.tags.join('') + '</div>' : '') +
      (o.kv ? '<div class="kv">' + o.kv + '</div>' : '') +
      '</div></div>';
  }
  function kv(k, v) { return '<div><div class="k">' + esc(k) + '</div><div class="v">' + v + '</div></div>'; }

  function block(title, inner, right) {
    return '<section class="card"><div class="card-h">' + esc(title) +
      (right ? '<span class="r">' + right + '</span>' : '') + '</div>' +
      '<div class="card-b' + (inner && inner.indexOf('<table') === 0 ? ' flush' : '') + '">' + inner + '</div></section>';
  }

  function mini(table, sel, limit) {
    var cols = colsOf(table);
    var rows = CD.rowsFor(table, { sel: sel });
    limit = limit || 40;
    if (!rows.length) return '<div class="empty" style="padding:14px">暂无记录</div>';
    var h = '<table class="mini"><thead><tr>';
    cols.forEach(function (c) {
      h += '<th class="' + (c.num ? 'num' : '') + '"' + (c.img ? ' style="width:28px"' : '') + '>' +
        (esc(c.h) || '') + '</th>';
    });
    h += '</tr></thead><tbody>';
    rows.slice(0, limit).forEach(function (r) {
      h += '<tr>';
      cols.forEach(function (c) {
        var v = cellHTML(c, r);
        if (c.c === '概率' || c.h === '概率') v = '<span class="pct">' + v + '</span>';
        h += '<td class="' + (c.num ? 'num' : '') + '">' + v + '</td>';
      });
      h += '</tr>';
    });
    h += '</tbody></table>';
    if (rows.length > limit) h += '<div class="empty" style="padding:8px">仅显示前 ' + limit + ' 条，共 ' + rows.length + ' 条</div>';
    return '<div class="mscroll">' + h + '</div>';
  }

  function itemList(rows, qtyKey, nameKey) {
    if (!rows || !rows.length) return '<div class="empty" style="padding:14px">暂无记录</div>';
    return '<div class="rowlist">' + rows.slice(0, 40).map(function (r) {
      var nm = r[nameKey] || r['道具'] || r['武器'] || r['防具'] || '';
      var q = qtyKey ? (r[qtyKey] || '') : '';
      return '<div class="rl">' + (r._icon || '') + '<span>' + esc(nm) + '</span>' +
        (q ? '<span class="q">×' + esc(q) + '</span>' : '') + '</div>';
    }).join('') + '</div>';
  }

  /* ---------------- 各页详情 ---------------- */
  function wpnDetail(r) {
    var w = r._raw, sh = r._sharp;
    var typeName = TYPES[w[1] - 1] || '';
    var tags = ['<span class="tag b">' + typeName + '</span>'];
    if (r.SpAtk_Name) tags.push('<span class="tag g">' + esc(r.SpAtk_Name) + '</span>');
    if (w[11] === 0) tags.push('<span class="tag">终形态</span>');
    var kvh = kv('威力', r.Atk) + kv('会心率', (r.Affinity > 0 ? '+' : '') + r.Affinity + '%') +
      kv('孔位', r.Slot ? slotDots(r.Slot) : '—') + kv('稀有度', '★' + r.Rare);
    var h = hero({
      img: '<img src="img/w/' + w[10] + '.webp" alt="">', title: r.Wpn_Name,
      sid: '武器 #' + w[0] + ' · ' + (w[10] || ''), tags: tags, kv: kvh
    });
    // 斩味（含匠 +1）
    var sharp = '<section class="card"><div class="card-h">斩味<span class="n">匠 +1：' + (w[23] ? '生效' : '无') + '</span></div><div class="card-b">' +
      '<div style="background:#1b1b1b;padding:6px;border-radius:7px">' + (sh || '<span class="dim">无数据</span>') + '</div>' +
      '<div style="display:flex;gap:10px;margin-top:8px;font-size:11px;color:var(--dim)">' +
      '<span>赤 橙 黄 绿 蓝 白 紫</span><span style="margin-left:auto">长度 ' +
      (function () { var t = 0; for (var i = 0; i < 7; i++) t += parseInt(String(w[9]).substr(i * 2, 2), 10) || 0; return t; })() + '</span></div>' +
      '</div></section>';

    var b = '';
    if (w[1] === 6) {
      b += block('演奏旋律', mini('_DGV_WpntoHHSong', r, 20));
    } else if (w[1] === 12 || w[1] === 13) {
      b += block('可装填弹药', mini('_DGV_Gun', r, 24));
    } else if (w[1] === 8) {
      b += block('炮击类型', '<div class="rowlist"><div class="rl"><span>炮击</span><span class="q">' +
        esc(r.GLShotType_Name || '—') + '</span></div></div>');
    } else if (w[1] === 9 || w[1] === 10) {
      b += block('瓶 / 属性', '<div class="rowlist"><div class="rl"><span>装着瓶</span><span class="q">' +
        esc(r.AxePhial_Name || '—') + '</span></div></div>');
    } else if (w[1] === 14) {
      b += block('弓射击', '<div class="rowlist">' +
        '<div class="rl"><span>射击类型</span><span class="q">' + esc(r.BowShot_Name || '—') + '</span></div>' +
        '<div class="rl"><span>蓄力段</span><span class="q">' + arcs(w[17]) + '</span></div></div>');
    }

    var price = '<section class="card"><div class="card-h">费用</div><div class="card-b">' +
      '<div class="kv" style="margin-top:0">' + kv('生产价', r.ProPx ? r.ProPx.toLocaleString() + 'z' : '—') +
      kv('强化价', r.LvUpPx ? r.LvUpPx.toLocaleString() + 'z' : '—') + '</div></div></section>';

    b += block('生产素材', mini('_DGV_WpntoItmP', r, 30));
    b += block('强化素材', mini('_DGV_WpntoItmU', r, 30));
    return h + sharp + price + b;
  }

  function amrDetail(r) {
    var a = r._raw, sk = a[12] || [];
    var sex = a[9] === 2 ? '女' : a[9] === 1 ? '男' : '共通';
    var imgFile = a[10] + (ST.f.sex === '2' ? '_F' : '');
    var tags = ['<span class="tag b">' + (PARTS[a[1]] || '') + '</span>', '<span class="tag">' + sex + '</span>'];
    if (a[4]) tags.push('<span class="tag g">' + slotDots(a[4]) + '</span>');
    var h = hero({
      tall: true, img: '<img src="img/a/' + imgFile + '.webp" alt="">',
      title: r.Amr_Name, sid: '防具 #' + a[0] + ' · ' + a[10], tags: tags,
      kv: kv('防御', a[5]) + kv('满防御', a[6]) + kv('孔位', a[4] ? slotDots(a[4]) : '—') + kv('稀有度', '★' + a[3])
    });
    var res = '<section class="card"><div class="card-h">耐性</div><div class="card-b">' +
      '<div class="kv" style="margin-top:0">' +
      kv('火', (a[7][0] > 0 ? '+' : '') + a[7][0]) + kv('水', (a[7][1] > 0 ? '+' : '') + a[7][1]) +
      kv('雷', (a[7][2] > 0 ? '+' : '') + a[7][2]) + kv('冰', (a[7][3] > 0 ? '+' : '') + a[7][3]) +
      kv('龙', (a[7][4] > 0 ? '+' : '') + a[7][4]) + kv('生产价', a[11] ? a[11].toLocaleString() + 'z' : '—') +
      '</div></div></section>';
    var skh = sk.length ? '<div class="rowlist">' + sk.map(function (x) {
      var nm = CD.treeName(x[0]);
      return '<div class="rl"><span>' + esc(nm) + '</span><span class="q" style="color:' +
        (x[1] > 0 ? '#b7791f' : '#c0392b') + '">' + (x[1] > 0 ? '+' : '') + x[1] + '</span></div>';
    }).join('') + '</div>' : '<div class="empty" style="padding:12px">无技能点</div>';
    return h + '<section class="card"><div class="card-h">技能点</div><div class="card-b">' + skh + '</div></section>' +
      res + block('生产素材', mini('_DGV_AmrtoItm', r, 30));
  }

  function jewDetail(r) {
    var j = r._raw, sk = j[4] || [];
    var tags = ['<span class="tag b">' + (j[2] || 1) + ' 孔</span>'];
    var h = hero({
      img: itemIcon(j[3], 64),
      title: r.Jew_Name, sid: '装饰珠 #' + j[0], tags: tags,
      kv: kv('所需孔位', j[2]) + kv('售价', r.Price ? r.Price.toLocaleString() + 'z' : '—') +
      kv('技能数', sk.length) + kv('道具 ID', j[3])
    });
    var skh = sk.map(function (x) {
      return '<div class="rl"><span>' + esc(CD.treeName(x[0])) + '</span><span class="q" style="color:' +
        (x[1] > 0 ? '#b7791f' : '#c0392b') + '">' + (x[1] > 0 ? '+' : '') + x[1] + '</span></div>';
    }).join('');
    return h + '<section class="card"><div class="card-h">技能</div><div class="card-b"><div class="rowlist">' + skh + '</div></div></section>' +
      block('所需素材', mini('_DGV_JewtoItm', r, 20));
  }

  function itmDetail(r) {
    var i = r._raw;
    var h = hero({
      img: itemIcon(i[0], 72), title: i[1], sid: '道具 #' + i[0],
      tags: ['<span class="tag">稀有 ' + i[2] + '</span>', '<span class="tag">HEX ' + (i[6] || '') + '</span>'],
      kv: kv('持有上限', i[3]) + kv('卖价', i[4] ? i[4].toLocaleString() + 'z' : '—') +
      kv('买价', i[5] ? i[5].toLocaleString() + 'z' : '—') + kv('稀有度', '★' + i[2])
    });
    return h +
      block('用途 · 武器', mini('_DGV_ItmtoWpn', r, 12)) +
      block('用途 · 防具', mini('_DGV_ItmtoAmr', r, 12)) +
      block('用途 · 装饰珠', mini('_DGV_ItmtoJew', r, 12)) +
      block('来源 · 怪物', mini('_DGV_ItmtoMon', r, 16)) +
      block('来源 · 地图采集', mini('_DGV_ItmtoLoc', r, 16)) +
      block('来源 · 任务', mini('_DGV_ItmtoQst', r, 16));
  }

  function cboDetail(r) {
    var c = r._raw;
    var h = hero({
      img: itemIcon(c[1], 64), title: r.ItmC_Name, sid: '调和 #' + c[0],
      tags: ['<span class="tag b">成功率 ' + (c[4] || 0) + '%</span>', c[5] ? '<span class="tag">产出 ×' + c[5] + '</span>' : ''],
      kv: kv('材料 A', esc(CD.itemName(c[2]) || '—')) + kv('材料 B', esc(CD.itemName(c[3]) || '—'))
    });
    return h + block('调和材料', '<div class="rowlist">' +
      '<div class="rl">' + itemIcon(c[2], 20) + '<span>' + esc(CD.itemName(c[2])) + '</span></div>' +
      '<div class="rl">' + itemIcon(c[3], 20) + '<span>' + esc(CD.itemName(c[3])) + '</span></div>' +
      '</div>');
  }

  function sklDetail(r) {
    var t = r._raw, pos = t[2].filter(function (x) { return x > 0; });
    var h = hero({
      img: '', title: r.SklTree_Name, sid: '技能系统 #' + t[0],
      tags: ['<span class="tag b">最大 ' + (pos[pos.length - 1] || 0) + ' 点</span>'],
      kv: kv('等级数', pos.length) + kv('最终技能', esc(t[3][pos.length - 1] || t[1]))
    });
    var lv = '<div style="display:flex;flex-direction:column;gap:2px">';
    pos.forEach(function (p, i) {
      lv += '<div class="sklrow"><span style="width:44px;color:var(--dim)">' + p + ' 点</span>' +
        '<span class="bar"><i style="width:' + Math.min(100, (i + 1) / pos.length * 100) + '%"></i></span>' +
        '<span style="flex:1;text-align:right">' + esc(t[3][i] || '') + '</span>' +
        '<span class="lv">Lv.' + (i + 1) + '</span></div>';
    });
    lv += '</div>';
    return h + '<section class="card"><div class="card-h">等级效果</div><div class="card-b">' + lv + '</div></section>' +
      block('可出此技能的防具', mini('_DGV_SklTreetoAmr', r, 24)) +
      block('可出此技能的装饰珠', mini('_DGV_SklTreetoJew', r, 16));
  }

  function qstDetail(r) {
    var q = r._raw;
    var h = hero({
      img: qIcon(q[3]) ? '<img src="' + qIcon(q[3]) + '" style="width:72px;height:72px;object-fit:contain">' : '',
      title: q[1], sid: '任务 #' + q[0] + ' · ' + (L('qstLv')[q[2]] || ''),
      tags: ['<span class="tag b">' + esc(L('qstType')[q[3]] || '') + '</span>',
        q[4] ? '<span class="tag">' + esc(L('loc')[q[4]] || '') + '</span>' : ''],
      kv: kv('受理费', q[8] ? q[8] + 'z' : '—') + kv('时间', q[9] ? q[9] + ' 分' : '—') +
      kv('报酬金', q[10] ? q[10].toLocaleString() + 'z' : '—') + kv('HRP', q[11] || '—')
    });
    var goal = q[6] || q[12] ? '<div class="card-b" style="font-size:12.5px;line-height:1.7">' +
      (q[6] ? '<div>' + esc(q[6]) + '</div>' : '') + (q[12] ? '<div style="color:var(--dim)">' + esc(q[12]) + '</div>' : '') + '</div>' : '';
    return h + (goal ? '<section class="card"><div class="card-h">任务目标</div>' + goal + '</section>' : '') +
      tabsCard([
        ['A', mini('_DGV_QsttoItmA', r, 30)],
        ['B', mini('_DGV_QsttoItmB', r, 30)],
        ['C', mini('_DGV_QsttoItmC', r, 30)],
        ['D', mini('_DGV_QsttoItmD', r, 30)]
      ], '报酬分组');
  }

  function tabsCard(list, title) {
    var id = 'tb' + Math.random().toString(36).slice(2, 8);
    var h = '<section class="card"><div class="card-h">' + esc(title) + '</div><div class="tabs">';
    list.forEach(function (x, i) {
      h += '<button class="tab' + (i === 0 ? ' on' : '') + '" data-t="' + id + '" data-i="' + i + '">' + esc(x[0]) + '</button>';
    });
    h += '</div><div class="card-b flush" id="' + id + '">' + list[0][1] + '</div></section>';
    return h;
  }

  function monDetail(r) {
    var m = r._raw;
    var h = hero({
      img: '<img src="img/m/' + m[0] + '.webp" style="width:96px;height:96px;image-rendering:auto" alt="">',
      title: m[1], sid: '怪物 #' + m[0],
      tags: ['<span class="tag">肉质 ' + ((m[2] || []).length) + ' 部位</span>', '<span class="tag">掉落 12 组</span>']
    });
    var weak = mini('_DGV_Weak', r, 40);
    var ail = mini('_DGV_Ail', r, 20);
    var trap = mini('_DGV_Trap', r, 10);
    var drops = '<section class="card"><div class="card-h">掉落素材<span class="n">按等级分组</span></div>' +
      '<div class="tabs" id="dropTabs">';
    for (var i = 1; i <= 12; i++) {
      drops += '<button class="tab' + (i === 1 ? ' on' : '') + '" data-drop="' + i + '">' + (L('rank')[i] || ('组 ' + i)) + '</button>';
    }
    drops += '</div><div class="card-b flush" id="dropBox">' + mini('_DGV_Itm1', r, 30) + '</div></section>';
    return h + '<section class="card"><div class="card-h">肉质 / 弱点</div><div class="card-b flush">' + weak + '</div></section>' +
      '<section class="card"><div class="card-h">异常耐性</div><div class="card-b flush">' + ail + '</div></section>' +
      '<section class="card"><div class="card-h">陷阱效果</div><div class="card-b flush">' + trap + '</div></section>' + drops;
  }

  function songDetail(r) {
    var s = r._raw;
    var h = hero({
      img: '', title: r['旋律效果'] || ('旋律 #' + s[0]), sid: '旋律 #' + s[0],
      tags: ['<span class="tag b">' + esc(L('songCat')[s[9]] || '') + '</span>'],
      kv: kv('持续', s[4] || '—') + kv('吹笛名人', s[5] || '—')
    });
    var nx = '<div class="card-b" style="display:flex;gap:8px;align-items:center">' + notes(s[2]) + '</div>';
    return h + '<section class="card"><div class="card-h">音符组合</div>' + nx + '</section>' +
      (s[6] ? '<section class="card"><div class="card-h">重奏效果</div><div class="card-b" style="font-size:13px">' + esc(s[6]) + '</div></section>' : '') +
      block('可演奏此旋律的武器', mini('_DGV_HHSongtoWpn', r, 24));
  }

  function ammoDetail(r) {
    var w = CD.idx.weapons.get(r._id) || [];
    var rows = (D.bowgun.rows.filter(function (x) { return x[0] === r._id; })[0] || []);
    var h = hero({
      img: w[10] ? '<img src="img/w/' + w[10] + '.webp" alt="">' : '',
      title: r['武器'], sid: '武器 #' + r._id + ' · ' + (TYPES[(w[1] || 1) - 1] || ''),
      tags: ['<span class="tag b">' + (w[1] === 13 ? '重弩' : '轻弩') + '</span>'],
      kv: kv('威力', w[4] || '—') + kv('孔位', w[8] ? slotDots(w[8]) : '—')
    });
    var list = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:2px 10px">';
    var sh = L('shotType');
    for (var i = 1; i <= 17; i++) {
      var a = rows[i] || [0, 0, 0];
      if (!a.some(function (v) { return v > 0; })) continue;
      list += '<div class="rl" style="display:flex;gap:6px;border-bottom:1px dashed var(--line-2);padding:4px 0;font-size:12px">' +
        '<span style="flex:1">' + esc(sh[i] || '') + '</span>' +
        '<span style="color:var(--brand);font-variant-numeric:tabular-nums">' + a.join(' / ') + '</span></div>';
    }
    list += '</div>';
    return h + '<section class="card"><div class="card-h">装填数 · 1 / 2 / 3 级</div><div class="card-b">' + list + '</div></section>';
  }

  function kinDetail(r) {
    var k = r._raw;
    var h = hero({
      img: k[4] ? '<img src="img/k/' + k[4] + '.webp" alt="">' : '',
      title: k[1], sid: '猎虫 #' + k[0],
      tags: ['<span class="tag b">' + esc(L('kinsectType')[k[2] - 30] || '') + '</span>', '<span class="tag">★' + k[3] + '</span>']
    });
    return h + block('虫技能', mini('_DGV_ISKinsectBugSkill', r, 20)) +
      block('精华技能', mini('_DGV_ISKinsectExtractSkill', r, 20)) +
      block('强化素材', mini('_DGV_ISKinsecttoItm', r, 30));
  }

  function peliWDetail(r) {
    var p = r._raw;
    var h = hero({
      img: p[4] ? '<img src="img/pw/' + p[4] + '.webp" alt="">' : '',
      title: r['随从武器'], sid: '随从武器 #' + p[0],
      tags: ['<span class="tag b">' + esc(L('peliType')[p[2]] || '') + '</span>', '<span class="tag">★' + p[3] + '</span>'],
      kv: kv('近身', p[5]) + kv('远程', p[8]) + kv('防御', p[11]) + kv('生产价', p[12] ? p[12] + 'z' : '—')
    });
    return h + block('生产素材', mini('_DGV_PeliWpntoItm', r, 30));
  }

  function peliADetail(r) {
    var p = r._raw, rs = p[5] || [];
    var h = hero({
      tall: true, img: p[6] ? '<img src="img/pa/' + p[6] + '.webp" alt="">' : '',
      title: r['随从防具'], sid: '随从防具 #' + p[0],
      tags: ['<span class="tag b">' + (PELI_PART[p[1]] || '') + '</span>', '<span class="tag">★' + p[3] + '</span>'],
      kv: kv('防御', p[4]) + kv('火', (rs[0] > 0 ? '+' : '') + (rs[0] || 0)) +
      kv('水', (rs[1] > 0 ? '+' : '') + (rs[1] || 0)) + kv('雷', (rs[2] > 0 ? '+' : '') + (rs[2] || 0))
    });
    return h + block('生产素材', mini('_DGV_PeliAmrtoItm', r, 30));
  }

  function hfhDetail(r) {
    var h = hero({
      img: '', title: r['任务'] || ('委托 #' + r._raw[0]), sid: '委托 #' + r._raw[0],
      tags: ['<span class="tag b">' + esc(L('rank')[r._raw[2]] || '') + '</span>'],
      kv: kv('成功率', (r._raw[4] || 0) + '%') + kv('大成功率', (r._raw[5] || 0) + '%') +
      kv('受理费', r._raw[6]) + kv('追加契约金', r._raw[7])
    });
    return h + '<section class="card"><div class="card-h">目标怪物</div><div class="card-b" style="font-size:13px">' +
      esc(r['怪物'] || '—') + '</div></section>' +
      tabsCard([
        ['A', mini('_DGV_HfhtoItmA', r, 24)],
        ['B', mini('_DGV_HfhtoItmB', r, 24)],
        ['C', mini('_DGV_HfhtoItmC', r, 24)]
      ], '报酬分组');
  }

  function araDetail(r) {
    var a = r._raw;
    var h = hero({
      img: '', title: r['任务'], sid: '斗技大会 #' + a[0],
      tags: ['<span class="tag b">' + (a[3] || 1) + ' 人</span>'],
      kv: kv('报酬金', (a[2] || 0).toLocaleString() + 'z') + kv('S 评价', a[4] || '—')
    });
    return h + tabsCard([
      ['武器', mini('_DGV_AratoWpnA', r, 20)],
      ['防具', mini('_DGV_AratoAmrA', r, 20)],
      ['道具', mini('_DGV_AratoItm', r, 20)]
    ], '提供装备') +
      '<section class="card"><div class="card-h">出现怪物</div><div class="card-b" style="font-size:13px">' +
      esc(r['怪物'] || '—') + '</div></section>';
  }

  function peliTeamDetail(r) {
    var h = hero({
      img: itemIcon(r._id, 72), title: r['道具'] || ('道具 #' + r._id),
      sid: '猛喵队交易 · ' + (r['地带'] || ''),
      tags: ['<span class="tag b">' + esc(r['地带'] || '') + '</span>',
        '<span class="tag">' + esc(r['等级'] || '') + '</span>'],
      kv: kv('数量', r['数量'] || '—') + kv('概率', (r['概率'] || 0) + '%')
    });
    var same = [];
    Object.keys(D.peliteam.data || {}).forEach(function (z) {
      Object.keys(D.peliteam.data[z]).forEach(function (rk) {
        D.peliteam.data[z][rk].forEach(function (x) {
          if (x[0] === r._id && !(z === ST.f.zone && rk === String(r['等级']))) same.push(x);
        });
      });
    });
    var list = same.length ? '<div class="rowlist">' + same.slice(0, 12).map(function (x) {
      return '<div class="rl">' + itemIcon(x[0], 20) + '<span>' + esc(CD.itemName(x[0])) + '</span>' +
        '<span class="q">×' + x[1] + (x[2] ? ' · ' + x[2] + '%' : '') + '</span></div>';
    }).join('') + '</div>' : '<div class="empty" style="padding:12px">仅此一处出售</div>';
    return h + '<section class="card"><div class="card-h">其他地带的同种交易品</div><div class="card-b">' + list + '</div></section>' +
      '<section class="card"><div class="card-h">用途</div><div class="card-b">' +
      '<div class="rowlist"><div class="rl"><a href="#/itm">在道具页查看完整用途与来源 →</a></div></div></div></section>';
  }

  function vetDetail(r) {
    var v = r._raw;
    var h = hero({
      img: itemIcon(v[1], 72), title: CD.itemName(v[1]) || ('#' + v[1]),
      sid: '山菜爷爷交换 #' + v[0],
      tags: ['<span class="tag b">概率 ' + (v[2] || 0) + '%</span>',
        v[3] ? '<span class="tag">' + esc(L('loc')[v[3]] || '') + '</span>' : ''],
      kv: kv('给出', esc(CD.itemName(v[0]) || '—')) + kv('入手', esc(CD.itemName(v[1]) || '—'))
    });
    return h + '<section class="card"><div class="card-h">交换关系</div><div class="card-b">' +
      '<div class="rowlist">' +
      '<div class="rl">' + itemIcon(v[0], 20) + '<span>给出</span><span class="q">' + esc(CD.itemName(v[0])) + ' ×1</span></div>' +
      '<div class="rl">' + itemIcon(v[1], 20) + '<span>入手</span><span class="q">' + esc(CD.itemName(v[1])) + ' ×1</span></div>' +
      '</div></div></section>';
  }

  /* ---------------- 地图页 ---------------- */
  function locView(P) {
    var box = $('#special');
    var L2 = null;
    function paint() {
      var id = +ST.f.loc, rank = ST.f.rank || '1';
      var d = (D.maps.data[String(id)] || {})[rank] || [];
      var total = 0, h = '';
      if (!d.length) {
        h = '<div class="card"><div class="empty"><b>该地图没有此难度数据</b>换一个难度看看</div></div>';
      } else {
        d.forEach(function (ar) {
          total += (ar[1] || []).length;
        });
        h = '<div class="split wide"><section class="card"><div class="card-h">' +
          '<img src="' + locIcon(id) + '" width="18" height="18" alt="">' + esc(L('loc')[id] || '') +
          '<span class="n">' + (L('rank')[rank] || '') + ' · ' + d.length + ' 个区域 · ' + total + ' 个采集点</span></div>' +
          '<div class="card-b flush">' + locTable(d) + '</div></section>';
        var side = '<aside class="detail">';
        side += '<section class="card"><div class="card-h">区域分布</div><div class="card-b">';
        d.forEach(function (ar) {
          side += '<div class="rl" style="display:flex;gap:8px;padding:5px 0;border-bottom:1px dashed var(--line-2);font-size:12.5px">' +
            '<b style="width:44px">' + ar[0] + ' 区</b><span style="color:var(--dim)">' + (ar[1] || []).length + ' 种素材</span>' +
            '<span style="margin-left:auto">' + (ar[1] || []).slice(0, 3).map(function (x) {
              return itemIcon(x[0], 18);
            }).join('') + '</span></div>';
        });
        side += '</div></section>';
        side += '<section class="card"><div class="card-h">该地图可采集道具</div><div class="card-b">' +
          uniqueItems(d) + '</div></section></aside>';
        h += side + '</div>';
      }
      h = '<div class="fbar"><div class="fitem"><label>地图</label><select id="locSel">' +
        (D.maps.locs || []).map(function (x) {
          return '<option value="' + x[0] + '"' + (x[0] === id ? ' selected' : '') + '>' + esc(x[1]) + '</option>';
        }).join('') + '</select></div>' +
        '<div class="fitem"><label>难度</label><div class="chips" id="rankChips">' +
        [['1', '下位'], ['2', '上位'], ['3', 'G级']].map(function (x) {
          return '<button class="chip' + (x[0] === rank ? ' on' : '') + '" data-r="' + x[0] + '">' + x[1] + '</button>';
        }).join('') + '</div></div></div>' + h;
      box.innerHTML = h;
      $('#locSel').addEventListener('change', function () { ST.f.loc = this.value; paint(); });
      $$('#rankChips [data-r]').forEach(function (b) {
        b.addEventListener('click', function () { ST.f.rank = b.dataset.r; paint(); });
      });
    }
    paint();
  }
  function locTable(areas) {
    var h = '<table class="dt"><thead><tr><th style="width:64px">区域</th><th>道具</th><th style="width:90px">类型</th><th style="width:56px">数量</th></tr></thead><tbody>';
    areas.forEach(function (ar) {
      (ar[1] || []).forEach(function (it, i) {
        h += '<tr><td>' + (i === 0 ? ar[0] + ' 区' : '') + '</td><td class="nm">' +
          itemIcon(it[0], 18) + ' ' + esc(CD.itemName(it[0])) + '</td>' +
          '<td class="dim">' + esc(it[1] || '') + '</td><td class="num">' + (it[2] || 1) + '</td></tr>';
      });
    });
    return h + '</tbody></table>';
  }
  function uniqueItems(areas) {
    var seen = {}, out = [];
    areas.forEach(function (ar) {
      (ar[1] || []).forEach(function (it) { if (!seen[it[0]]) { seen[it[0]] = 1; out.push(it[0]); } });
    });
    return '<div class="rowlist">' + out.map(function (id) {
      return '<div class="rl">' + itemIcon(id, 20) + '<span>' + esc(CD.itemName(id)) + '</span></div>';
    }).join('') + '</div>';
  }

  /* ---------------- 勋章 ---------------- */
  function awdView() {
    var box = $('#special');
    var list = D.medals;
    var sel = 0;
    function paint() {
      var h = '<div class="split wide"><section class="card"><div class="card-h">全部勋章<span class="n">' +
        list.length + ' 枚 · 图标取自原程序</span></div><div class="medgrid">';
      list.forEach(function (m, i) {
        h += '<div class="med' + (i === sel ? ' on' : '') + '" data-i="' + i + '">' +
          '<img src="' + awdIcon(m[0]) + '" alt="" loading="lazy">' +
          '<span>' + esc(m[1]) + '</span></div>';
      });
      h += '</div></section><aside class="detail" id="awdDet"></aside></div>';
      box.innerHTML = h;
      paintDet();
      $$('.med', box).forEach(function (el) {
        el.addEventListener('click', function () {
          sel = +el.dataset.i;
          $$('.med', box).forEach(function (x) { x.classList.toggle('on', x === el); });
          paintDet();
        });
      });
    }
    function paintDet() {
      var m = list[sel];
      $('#awdDet').innerHTML =
        '<div class="hero"><div class="hero-img"><img src="' + awdIcon(m[0]) + '" style="width:96px;height:96px" alt=""></div>' +
        '<div class="hero-txt"><h2>' + esc(m[1]) + '</h2><div class="sid">勋章 #' + m[0] + '</div>' +
        '<div class="tags"><span class="tag b">' + sel + ' / ' + list.length + '</span></div></div></div>' +
        '<section class="card"><div class="card-h">获得说明</div><div class="card-b" style="font-size:13px;line-height:1.8">' +
        esc(m[2] || '—') + '</div></section>';
    }
    paint();
  }

  /* ---------------- 套装模拟器 ---------------- */
  var ASB_TAB = 0, ASB_PEND = null, ASB_KW = '', ASB_PARTF = '', ASB_DEMO = false;

  function asbView() {
    var box = $('#special');
    // 首次进入载入一套示例配装，便于直接看到技能/素材联动；可一键清空
    if (!ASB_DEMO) {
      ASB_DEMO = true;
      var empty = CD.asb.armor.every(function (x) { return !x; });
      if (empty) CD.asbDemo();
    }
    box.innerHTML = '<div class="split wide"><section class="card" id="asbLeft"></section>' +
      '<aside class="detail" id="asbRight"></aside></div>';
    paintAsbLeft();
    paintAsbRight();
  }

  function paintAsbLeft() {
    var box = $('#asbLeft'); if (!box) return;
    var h = '<div class="card-h">' + (ASB_TAB === 0 ? '防具' : '装饰珠') +
      '<span class="n">点一行即可选中</span><span class="r">' +
      '<button class="btn sm" data-ak="0" ' + (ASB_TAB === 0 ? 'style="border-color:var(--brand);color:var(--brand)"' : '') + '>防具</button>' +
      '<button class="btn sm" data-ak="1" ' + (ASB_TAB === 1 ? 'style="border-color:var(--brand);color:var(--brand)"' : '') + '>装饰珠</button>' +
      '</span></div>';
    h += '<div class="fbar" style="margin:10px 12px 0;border-radius:8px">';
    if (ASB_TAB === 0) {
      h += '<div class="chips" id="asbPart">' + [['', '全部'], ['1', '头'], ['2', '胴'], ['3', '腕'], ['4', '腰'], ['5', '脚']].map(function (x) {
        return '<button class="chip' + (x[0] === ASB_PARTF ? ' on' : '') + '" data-p="' + x[0] + '">' + x[1] + '</button>';
      }).join('') + '</div>';
    }
    h += '<input type="search" id="asbQ" placeholder="搜索名称 / 技能…" value="' + esc(ASB_KW) + '" style="height:30px;border:1px solid var(--line);border-radius:7px;background:var(--bg);padding:0 8px;font-size:13px">';
    h += '</div><div class="tw" style="max-height:calc(100vh - 300px)"><table class="dt" id="asbTbl"></table></div>';
    box.innerHTML = h;
    $$('#asbLeft [data-ak]').forEach(function (b) {
      b.addEventListener('click', function () { ASB_TAB = +b.dataset.ak; paintAsbLeft(); });
    });
    $$('#asbPart [data-p]').forEach(function (b) {
      b.addEventListener('click', function () { ASB_PARTF = b.dataset.p; paintAsbLeft(); });
    });
    var q = $('#asbQ');
    q.addEventListener('input', function () {
      clearTimeout(q._t);
      q._t = setTimeout(function () { ASB_KW = q.value.trim().toLowerCase(); paintAsbRows(); }, 180);
    });
    paintAsbRows();
  }

  function paintAsbRows() {
    var tbl = $('#asbTbl'); if (!tbl) return;
    var h = '', cols;
    if (ASB_TAB === 0) {
      var rows = D.armor.filter(function (a) {
        if (ASB_PARTF && a[1] !== +ASB_PARTF) return false;
        if (ASB_KW) {
          var s = a[2].toLowerCase() + ' ' + (a[12] || []).map(function (x) { return CD.treeName(x[0]); }).join(' ');
          if (s.indexOf(ASB_KW) < 0) return false;
        }
        return true;
      });
      cols = ['部位', '防具', '孔', '防御', '满防', '技能'];
      h = '<thead><tr>' + cols.map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr></thead><tbody>';
      rows.slice(0, 300).forEach(function (a, i) {
        var sk = (a[12] || []).slice(0, 2).map(function (x) {
          return CD.treeName(x[0]) + (x[1] > 0 ? '+' : '') + x[1];
        }).join(' · ');
        h += '<tr data-ai="' + a[0] + '"><td>' + (PARTS[a[1]] || '') + '</td>' +
          '<td class="nm">' + CD.amrIcon(a[10], 18) + ' ' + esc(a[2]) + '</td>' +
          '<td>' + slotDots(a[4]) + '</td><td class="num">' + a[5] + '</td><td class="num">' + a[6] + '</td>' +
          '<td class="dim" style="max-width:220px;overflow:hidden;text-overflow:ellipsis">' + esc(sk) + '</td></tr>';
      });
      h += '</tbody>';
      if (!rows.length) h = '<tbody><tr><td class="empty">没有匹配的防具</td></tr></tbody>';
    } else {
      var js = D.jewels.filter(function (j) {
        if (ASB_KW) {
          var s = j[1].toLowerCase() + ' ' + (j[4] || []).map(function (x) { return CD.treeName(x[0]); }).join(' ');
          if (s.indexOf(ASB_KW) < 0) return false;
        }
        return true;
      });
      h = '<thead><tr><th>孔</th><th>装饰珠</th><th>技能</th></tr></thead><tbody>';
      js.slice(0, 300).forEach(function (j) {
        var sk = (j[4] || []).map(function (x) {
          return CD.treeName(x[0]) + (x[1] > 0 ? '+' : '') + x[1];
        }).join(' · ');
        h += '<tr data-ji="' + j[0] + '"><td>' + slotDots(j[2]) + '</td>' +
          '<td class="nm">' + itemIcon(j[3], 18) + ' ' + esc(j[1]) + '</td>' +
          '<td class="dim">' + esc(sk) + '</td></tr>';
      });
      h += '</tbody>';
      if (!js.length) h = '<tbody><tr><td class="empty">没有匹配的装饰珠</td></tr></tbody>';
    }
    tbl.innerHTML = h;
    $$('tr[data-ai],tr[data-ji]', tbl).forEach(function (tr) {
      tr.addEventListener('click', function () {
        $$('tr', tbl).forEach(function (x) { x.classList.toggle('on', x === tr); });
        if (tr.dataset.ai) {
          var a = CD.idx.armor.get(+tr.dataset.ai);
          ASB_PEND = { t: 'a', d: a };
          CD.asbPickArmor({ _raw: a });
          // 点防具即装备到对应部位（网页版比原版少一步）
          var msg = CD.asbAddArmor(a[1] - 1);
          paintAsbRight(); toast(msg);
        } else {
          var j = CD.idx.jewels.get(+tr.dataset.ji);
          ASB_PEND = { t: 'j', d: j };
          CD.asbPickJewel({ _raw: j });
          toast('已选中 ' + j[1] + ' · 点右侧孔位镶嵌');
        }
      });
    });
  }

  var toastT = null;
  function toast(msg) {
    var el = $('#toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'toast';
      el.style.cssText = 'position:fixed;left:50%;bottom:26px;transform:translateX(-50%);z-index:80;' +
        'background:rgba(24,28,34,.92);color:#fff;padding:8px 16px;border-radius:20px;font-size:12.5px;' +
        'box-shadow:0 6px 24px rgba(0,0,0,.25);transition:.2s;opacity:0;pointer-events:none';
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.opacity = '1';
    el.style.transform = 'translateX(-50%) translateY(0)';
    clearTimeout(toastT);
    toastT = setTimeout(function () { el.style.opacity = '0'; }, 1900);
  }

  function paintAsbRight() {
    var box = $('#asbRight'); if (!box) return;
    var ASB = CD.asb, st = CD.asbStats();
    var h = '<section class="card"><div class="card-h">套装<span class="n">' +
      (st.skills.length) + ' 个技能</span><span class="r">' +
      '<button class="btn sm" data-ab="code">套装码</button>' +
      '<button class="btn sm" data-ab="clear">清空</button></span></div>' +
      '<div class="card-b"><div class="statbar">' +
      '<div class="s"><b>' + st.def + '</b>防御</div>' +
      '<div class="s"><b>' + st.mx + '</b>满防御</div>' +
      '<div class="s"><b>' + st.slots + '</b>孔位</div>' +
      '<div class="s"><b>' + st.used + '</b>已用</div>' +
      '</div></div></section>';

    h += '<section class="card"><div class="card-h">装备槽</div><div class="card-b"><div class="slots">';
    // 武器孔
    h += slotHTML('wpn', '武器', null, ASB.wpnJewels);
    for (var i = 0; i < 5; i++) h += slotHTML('amr', CD.ASB_PART[i], ASB.armor[i], ASB.jewels[i], i);
    h += slotHTML('charm', '护石', null, ASB.charmJewels);
    h += '</div></div></section>';

    var sk = st.skills.length ? '<div class="rowlist">' + st.skills.map(function (s) {
      return '<div class="rl"><span>' + esc(s) + '</span></div>';
    }).join('') + '</div>' : '<div class="empty" style="padding:12px">还没有技能</div>';
    h += '<section class="card"><div class="card-h">发动技能</div><div class="card-b">' + sk + '</div></section>';

    var mats = CD.rowsFor('_DGV_AsbtoItm', { form: 'asb' });
    h += '<section class="card"><div class="card-h">所需素材<span class="n">' + mats.length + ' 种</span></div>' +
      '<div class="card-b flush">' + (mats.length ? '<div class="rowlist" style="padding:4px 12px">' +
        mats.map(function (m) {
          return '<div class="rl">' + itemIcon(m._id, 20) + '<span>' + esc(CD.itemName(m._id)) + '</span>' +
            '<span class="q">×' + m['数量'] + '</span></div>';
        }).join('') + '</div>' : '<div class="empty">—</div>') + '</div></section>';
    box.innerHTML = h;

    $$('[data-ab]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        if (b.dataset.ab === 'clear') {
          CD.asb.armor = [null, null, null, null, null];
          CD.asb.jewels = [[null, null, null], [null, null, null], [null, null, null], [null, null, null], [null, null, null]];
          CD.asb.wpnJewels = [null, null, null];
          CD.asb.charmJewels = [null, null, null];
          paintAsbRight(); toast('已清空套装');
        } else {
          var code = CD.asbCode();
          if (code) { navigator.clipboard && navigator.clipboard.writeText(code); toast('套装码已复制：' + code.slice(0, 22) + '…'); }
        }
      });
    });
    $$('[data-rm]', box).forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        CD.asbRemoveArmor(+b.dataset.rm); paintAsbRight(); toast('已移除该部位');
      });
    });
    $$('[data-jp]', box).forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var g = b.dataset.g, s = +b.dataset.s, k = +b.dataset.jp;
        var msg;
        if (ASB_PEND && ASB_PEND.t === 'j') {
          msg = CD.asbSetJewel(g, s, k);
          paintAsbRight(); toast(msg);
        } else {
          msg = CD.asbSetJewel(g, s, k);
          paintAsbRight(); toast(msg || '已取下');
        }
      });
    });
    $$('[data-slot]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        if (ASB_PEND && ASB_PEND.t === 'a' && b.dataset.slot === 'amr') {
          var msg = CD.asbAddArmor(+b.dataset.i); paintAsbRight(); toast(msg);
        }
      });
    });
  }

  function slotHTML(group, label, armor, jewels, idx) {
    var img = '', nm = '—', sub = '';
    if (armor) {
      img = CD.amrIcon(armor[10], 36);
      nm = armor[2];
      sub = '防御 ' + armor[5] + ' · ' + (armor[4] ? '孔 ' + armor[4] : '无孔');
    } else {
      sub = group === 'amr' ? '未装备' : '（可选）';
    }
    var jp = '';
    var cap = group === 'amr' ? (armor ? armor[4] || 0 : 0) : 3;
    for (var i = 0; i < Math.max(cap, group === 'amr' ? 0 : 3); i++) {
      var j = jewels[i];
      jp += '<i class="' + (j ? 'f' : '') + '" data-g="' + group + '" data-s="' + (idx == null ? 0 : idx) +
        '" data-jp="' + i + '" title="' + (j ? esc(j[1]) : '空孔（点击镶嵌/取下）') + '">' +
        (j ? '●' : '') + '</i>';
    }
    return '<div class="slot' + (armor ? '' : '') + '" ' +
      (group === 'amr' ? 'data-slot="amr" data-i="' + idx + '"' : '') + '>' +
      '<span class="part">' + esc(label) + '</span>' +
      '<span class="pic">' + img + '</span>' +
      '<span class="info"><b>' + esc(nm) + '</b><span>' + esc(sub) + '</span></span>' +
      '<span class="jp">' + jp + '</span>' +
      (group === 'amr' && armor ? '<button class="x" data-rm="' + idx + '" title="移除">×</button>' : '') +
      '</div>';
  }

  /* ---------------- 套装配装器 ---------------- */
  var ASF_KW = '', ASF_TAB = 0, ASF_RES = [];

  function asfView() {
    var box = $('#special');
    box.innerHTML = '<div class="split wide"><section class="card" id="asfLeft"></section>' +
      '<aside class="detail" id="asfRight"></aside></div>';
    paintAsfLeft();
    paintAsfRight();
  }

  function paintAsfLeft() {
    var box = $('#asfLeft'); if (!box) return;
    var h = '<div class="card-h">技能列表<span class="n">点一行加入目标</span></div>' +
      '<div class="fbar" style="margin:10px 12px 0;border-radius:8px">' +
      '<input type="search" id="asfQ" placeholder="搜索技能…" value="' + esc(ASF_KW) + '" ' +
      'style="height:30px;border:1px solid var(--line);border-radius:7px;background:var(--bg);padding:0 8px;font-size:13px;flex:1">' +
      '</div><div class="tw" style="max-height:calc(100vh - 300px)"><table class="dt" id="asfTbl"></table></div>';
    box.innerHTML = h;
    var q = $('#asfQ');
    q.addEventListener('input', function () {
      clearTimeout(q._t);
      q._t = setTimeout(function () { ASF_KW = q.value.trim().toLowerCase(); paintAsfRows(); }, 160);
    });
    paintAsfRows();
  }

  function paintAsfRows() {
    var tbl = $('#asfTbl'); if (!tbl) return;
    var rows = CD.rowsFor('_DGV_SklList_From', {});
    if (ASF_KW) {
      rows = rows.filter(function (r) {
        return (r.Skl_Name + ' ' + r.SklTree_Name).toLowerCase().indexOf(ASF_KW) >= 0;
      });
    }
    var h = '<thead><tr><th style="width:52px">点数</th><th>技能</th><th style="width:130px">技能系统</th></tr></thead><tbody>';
    rows.slice(0, 400).forEach(function (r, i) {
      h += '<tr data-si="' + i + '"><td class="num">' + r.Pt + '</td>' +
        '<td class="nm">' + esc(r.Skl_Name) + '</td>' +
        '<td class="dim">' + esc(r.SklTree_Name) + '</td></tr>';
    });
    if (!rows.length) h = '<tbody><tr><td class="empty">没有匹配的技能</td></tr></tbody>';
    tbl.innerHTML = h + '</tbody>';
    $$('tr[data-si]', tbl).forEach(function (tr) {
      tr.addEventListener('click', function () {
        var r = rows[+tr.dataset.si];
        CD.asfAdd(r);
        paintAsfRight(); toast('已加入：' + r.Skl_Name + ' +' + r.Pt);
      });
    });
  }

  function paintAsfRight() {
    var box = $('#asfRight'); if (!box) return;
    var tgt = CD.rowsFor('_DGV_SklList_To', {});
    var h = '<section class="card"><div class="card-h">目标技能<span class="n">' + tgt.length + ' 项</span>' +
      '<span class="r"><button class="btn sm" data-af="clear">清空</button></span></div>' +
      '<div class="card-b">';
    if (!tgt.length) {
      h += '<div class="empty" style="padding:14px">点左侧技能加入目标，再搜索配装</div>';
    } else {
      h += '<div class="rowlist">' + tgt.map(function (t, i) {
        return '<div class="rl"><span>' + esc(t.Skl_Name) + '</span>' +
          '<span class="q" style="display:flex;gap:8px;align-items:center">+' + t.Pt +
          ' <button class="x" data-del="' + i + '" style="border:0;background:none;color:var(--dim);cursor:pointer">×</button></span></div>';
      }).join('') + '</div>';
    }
    h += '</div></section>';
    h += '<div style="display:flex;gap:8px"><button class="btn p" data-af="run" style="flex:1">搜索配装</button>' +
      '<button class="btn" data-af="demo">示例</button></div>';
    h += '<section class="card" id="asfRes"><div class="card-h">搜索结果<span class="n" id="asfCnt">' +
      ASF_RES.length + ' 套</span></div><div class="card-b" id="asfList">' + asfListHTML() + '</div></section>';
    box.innerHTML = h;

    $$('[data-af]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        var a = b.dataset.af;
        if (a === 'clear') { CD.asfClear(); ASF_RES = []; paintAsfRight(); }
        else if (a === 'run') {
          var n = CD.asfRun();
          ASF_RES = CD.rowsFor('_DGV_AsftoAsb', {});
          paintAsfRight();
          toast(n ? '搜索完成：找到 ' + n + ' 套' : '没有找到满足条件的组合，试试减少目标技能');
        } else {
          CD.asfClear();
          var from = CD.rowsFor('_DGV_SklList_From', {});
          ['攻击', '见切', '弱点特效'].forEach(function (nm) {
            var hit = from.filter(function (r) { return r.Skl_Name === nm; })[0];
            if (hit) CD.asfAdd(hit);
          });
          ASF_RES = [];
          paintAsfRight();
        }
      });
    });
    $$('tr[data-del]', box).forEach(function (x) { x.addEventListener('click', function () { }); });
    $$('[data-del]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        CD.asfDel(); ASF_RES = []; paintAsfRight();
      });
    });
  }

  function asfListHTML() {
    if (!ASF_RES.length) return '<div class="empty" style="padding:14px">还没有结果</div>';
    return '<div class="res">' + ASF_RES.map(function (r, i) {
      var p = [];
      for (var k = 1; k <= 5; k++) {
        p.push('<span>' + esc(r['Amr' + k + '_Name'] || '—') + '</span>');
      }
      return '<div class="r"><div class="h"><b>方案 ' + (i + 1) + '</b>' +
        '<span class="m">防御 ' + r.Def + ' · 满 ' + r.MaxDef + '</span></div>' +
        '<div class="p">' + p.join('') + '</div></div>';
    }).join('') + '</div>';
  }

  /* ---------------- 关于 ---------------- */
  function aboutView() {
    $('#special').innerHTML =
      '<div class="split wide"><section class="card"><div class="card-h">关于本站</div>' +
      '<div class="card-b" style="font-size:13px;line-height:1.9">' +
      '<p style="margin-top:0">本站是 <b>Ping\'s MHXX Dex v1.2 Build5</b> 的网页版重构，界面按原程序的窗体结构重新编排为“左侧目录 + 右侧内容”，' +
      '数据表列、筛选项与联动关系取自原程序反编译结果。</p>' +
      '<p>所有图片素材（武器图、防具图、怪物图、猎虫、随从装备、道具图标、勋章、任务类型、地图、音符）均来自原程序内嵌资源。</p>' +
      '<p style="color:var(--dim)">数据与素材版权归原作者 <b>pingtendo</b> 所有，遵循 CC BY-NC-ND 4.0，仅供非商业用途。</p>' +
      '</div></section>' +
      '<aside class="detail"><section class="card"><div class="card-h">版本入口</div><div class="card-b">' +
      '<div class="rowlist">' +
      '<div class="rl"><a href="app.html">网页版（当前）</a></div>' +
      '<div class="rl"><a href="classic.html">桌面窗体复刻版</a></div>' +
      '<div class="rl"><a href="index.html">手机单列版</a></div>' +
      '</div></div></section></aside></div>';
  }

  /* ---------------- 事件 ---------------- */
  document.addEventListener('click', function (e) {
    var tb = e.target.closest('.tab[data-t]');
    if (tb) {
      var box = document.getElementById(tb.dataset.t);
      var i = +tb.dataset.i;
      $$('.tab[data-t="' + tb.dataset.t + '"]').forEach(function (x) { x.classList.toggle('on', x === tb); });
      if (box) {
        var key = ST.key;
        var r = ST.sel;
        var map = {
          qst: ['_DGV_QsttoItmA', '_DGV_QsttoItmB', '_DGV_QsttoItmC', '_DGV_QsttoItmD'],
          hfh: ['_DGV_HfhtoItmA', '_DGV_HfhtoItmB', '_DGV_HfhtoItmC'],
          ara: ['_DGV_AratoWpnA', '_DGV_AratoAmrA', '_DGV_AratoItm']
        }[key];
        if (map && r) box.innerHTML = mini(map[i], r, 30);
      }
      return;
    }
    var db = e.target.closest('.tab[data-drop]');
    if (db) {
      var n = db.dataset.drop;
      $$('.tab[data-drop]').forEach(function (x) { x.classList.toggle('on', x === db); });
      var b = $('#dropBox');
      if (b && ST.sel) b.innerHTML = mini('_DGV_Itm' + n, ST.sel, 30);
      return;
    }
  });

  // 目录点击
  navEl.addEventListener('click', function (e) {
    var a = e.target.closest('[data-go]'); if (!a) return;
    e.preventDefault();
    location.hash = '#/' + a.dataset.go;
    document.body.classList.remove('nav-open');
    $('#mask').hidden = true;
  });
  // 目录搜索
  $('#nav-q').addEventListener('input', function () {
    var q = this.value.trim().toLowerCase();
    $$('.nv').forEach(function (a) {
      a.style.display = !q || a.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
    });
    $$('[data-g]').forEach(function (g) {
      var any = false, el = g.nextElementSibling;
      while (el && !el.hasAttribute('data-g')) {
        if (el.classList.contains('nv') && el.style.display !== 'none') any = true;
        el = el.nextElementSibling;
      }
      g.style.display = any ? '' : 'none';
    });
  });
  // 抽屉
  $('#btn-menu').addEventListener('click', function () {
    document.body.classList.add('nav-open');
    $('#mask').hidden = false;
  });
  $('#mask').addEventListener('click', function () {
    document.body.classList.remove('nav-open');
    this.hidden = true;
  });

  // 路由
  function route() {
    var k = (location.hash || '').replace(/^#\/?/, '').split('?')[0] || 'wpn';
    if (!PAGES[k]) k = 'wpn';
    render(k);
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);

  /* ---------------- 启动 ---------------- */
  var nLoaded = 0;
  CD.load(function (n) {
    nLoaded++;
    var pct = Math.min(100, nLoaded / 31 * 100);
    var b = $('#boot-bar'), m = $('#boot-msg');
    if (b) b.style.width = pct + '%';
    if (m) m.textContent = '正在载入 ' + n + '…';
  }).then(function () {
    S = CD.spec; D = CD.data;
    CNT = {
      wpn: D.weapons.length, amr: D.armor.length, jew: D.jewels.length, itm: D.items.length,
      skl: D.skills.trees.length, cbo: D.combo.length, qst: D.quests.length,
      mon: D.monsters.length, loc: (D.maps.locs || []).length, song: D.hhsongs.length,
      ammo: D.bowgun.rows.length, kinsect: D.kinsects.length, peliwpn: D.peli_weapons.length,
      peliamr: D.peli_armor.length, peliteam: (function () {
        var n = 0; Object.keys(D.peliteam.data || {}).forEach(function (z) {
          Object.keys(D.peliteam.data[z]).forEach(function (r) { n += D.peliteam.data[z][r].length; });
        }); return n;
      })(), hfh: D.hfh.length, vet: D.veggie.length, ara: D.arena.length, awd: D.medals.length
    };
    buildNav();
    $('#boot').remove();
    $('#shell').hidden = false;
    route();
  }).catch(function (e) {
    console.error(e);
    var m = $('#boot-msg');
    if (m) { m.textContent = '载入失败：' + e.message; m.style.color = '#c0392b'; }
  });
})();
