/* classic_data.js — 原版界面数据层
   把 exe 反编译出的 DataGridView 列名（数据库字段名）直接绑到 ETL 导出的 JSON。
   行对象：普通字段为显示值；_raw 为原始数据；_icon / _sharp 供图片列使用。 */
(function (g) {
  'use strict';
  var CD = {};
  var FILES = ['weapons', 'armor', 'jewels', 'items', 'quests', 'monsters', 'skills',
    'recipes', 'weapon_upg', 'quest_rewards', 'mon_drops', 'maps', 'medals', 'hhsongs',
    'bowgun', 'kinsects', 'peli_weapons', 'peli_armor', 'hfh', 'peliteam', 'veggie',
    'arena', 'combo', 'item_src', 'item_use', 'item_icons', 'labels', 'wpn_gun',
    'wpn_songs', 'extra_links', 'meta'];
  var S = null, D = {}, IX = {};

  CD.load = function (progress) {
    return fetch('data/classic_spec.json').then(function (r) { return r.json(); })
      .then(function (s) {
        S = s;
        return Promise.all(FILES.map(function (n) {
          return fetch('data/' + n + '.json').then(function (r) {
            if (!r.ok) throw new Error(n);
            return r.json();
          }).then(function (j) { D[n] = j; if (progress) progress(n); });
        }));
      }).then(function () {
        buildIndex();
        CD.spec = S; CD.data = D; CD.idx = IX;
        return S;
      });
  };

  function mapOf(arr, key) {
    var m = new Map();
    (arr || []).forEach(function (r) { m.set(key ? r[key] : r[0], r); });
    return m;
  }
  function buildIndex() {
    IX.items = mapOf(D.items); IX.weapons = mapOf(D.weapons); IX.armor = mapOf(D.armor);
    IX.jewels = mapOf(D.jewels); IX.quests = mapOf(D.quests); IX.monsters = mapOf(D.monsters);
    IX.hhsongs = mapOf(D.hhsongs); IX.kinsects = mapOf(D.kinsects);
    IX.peliWeapons = mapOf(D.peli_weapons); IX.peliArmor = mapOf(D.peli_armor);
    IX.hfh = mapOf(D.hfh); IX.arena = mapOf(D.arena); IX.medals = mapOf(D.medals);
    IX.trees = mapOf(D.skills.trees);
    IX.combo = mapOf(D.combo);
    IX.loc = {}; (D.maps.locs || []).forEach(function (x) { IX.loc[x[0]] = x[1]; });
    IX.zone = {}; (D.peliteam.zones || []).forEach(function (x) { IX.zone[x[0]] = x[1]; });
  }

  /* ---------------- 基础工具 ---------------- */
  CD.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  };
  CD.cv = function (v) {
    if (v === 0 || v === '0') return '-';
    if (v == null || v === '') return '';
    if (typeof v === 'number') return v.toLocaleString('en-US');
    return String(v);
  };
  CD.itemIcon = function (id, px) {
    var ic = D.item_icons; px = px || 16;
    if (!ic) return '';
    var i = ic.index[String(id)];
    if (i == null || i < 0) return '';
    var c = ic.cols, s = ic.cell, k = px / s;
    return '<i class="ico" style="display:inline-block;width:' + px + 'px;height:' + px + 'px;' +
      'background-image:url(img/icon/items.png);background-position:-' + (i % c * s * k) + 'px -' +
      (Math.floor(i / c) * s * k) + 'px;background-size:' + (c * s * k) + 'px auto"></i>';
  };
  CD.wpnIcon = function (f, px) {
    return f ? '<img src="img/w/' + f + '.webp" style="width:' + (px || 16) + 'px;height:' + (px || 16) + 'px;object-fit:contain">' : '';
  };
  CD.amrIcon = function (f, px) {
    return f ? '<img src="img/a/' + f + '.webp" style="width:' + (px || 16) + 'px;height:' + (px || 16) + 'px;object-fit:contain">' : '';
  };
  CD.monIcon = function (id, px) {
    return '<img src="img/m/' + id + '.webp" style="width:' + (px || 16) + 'px;height:' + (px || 16) + 'px;object-fit:contain">';
  };
  CD.sharpBar = function (s, plus, p1) {
    if (!s || s.length < 14) return '';
    var v = [], i;
    for (i = 0; i < 7; i++) v.push(parseInt(s.substr(i * 2, 2), 10) || 0);
    var total = v.reduce(function (a, b) { return a + b; }, 0);
    if (plus > 0 && p1 === 1) {
      var top = 0; while (top < 7 && !v[top]) top++;
      if (top < 7) { v[top] += plus * 10; total += plus * 10; }
    }
    var SH = ['#9b59b6', '#e8ecef', '#2980b9', '#27ae60', '#f1c40f', '#e67e22', '#c0392b'];
    var cap = Math.max(90, total), seg = '';
    for (i = 6; i >= 0; i--) if (v[i] > 0) seg += '<i style="width:' + (v[i] / cap * 100).toFixed(2) + '%;background:' + SH[i] + '"></i>';
    return '<span class="sharp">' + seg + '</span>';
  };
  var L = function (k) { return (D.labels && D.labels[k]) || {}; };
  CD.itemName = function (id) { var r = IX.items.get(+id); return r ? r[1] : ''; };
  CD.wpnName = function (id) { var r = IX.weapons.get(+id); return r ? r[2] : ''; };
  CD.amrName = function (id) { var r = IX.armor.get(+id); return r ? r[2] : ''; };
  CD.monName = function (id) { var r = IX.monsters.get(+id); return r ? r[1] : ''; };
  CD.treeName = function (id) { var r = IX.trees.get(+id); return r ? r[1] : ''; };
  CD.locName = function (id) { return L('loc')[id] || IX.loc[id] || ''; };
  CD.elemName = function (elems) {
    if (!elems || !elems.length) return '';
    var E = L('elem');
    return elems.map(function (e) { return (E[e[0]] || '') + (e[1] ? e[1] : ''); }).join(' ');
  };
  CD.partName = ['', '头', '胴', '腕', '腰', '脚'];

  function row(o, raw, id, icon, sharp) {
    o._raw = raw; o._id = id; if (icon) o._icon = icon; if (sharp) o._sharp = sharp;
    return o;
  }
  function ir(id, qty, pct) { // 道具行（带图标），同时提供数据库字段名与中文表头
    var nm = CD.itemName(id);
    return row({ Itm_ID: id, Itm_Name: nm, '道具': nm, Qty: qty, '数量': qty,
      Pct: pct, '概率': pct }, [id, qty, pct], id, CD.itemIcon(id, 16));
  }

  /* ---------------- 主表 ---------------- */
  function wpnRow(w) {
    var bs = w[17] || [], sh = L('shotType'), gap = L('rapidGap');
    return row({
      Wpn_ID: w[0], Wpn_Type_ID: w[1], Wpn_Name: w[2], Child: w[11], Rare: w[3], Atk: w[4],
      SpAtk1_ID: w[5][0] ? w[5][0][0] : '', SpAtk1_Pt: w[5][0] ? w[5][0][1] : '',
      SpAtk2_ID: w[5][1] ? w[5][1][0] : '', SpAtk2_Pt: w[5][1] ? w[5][1][1] : '',
      SpAtk_Name: CD.elemName(w[5]), Affinity: w[6], Def: w[7], Slot: w[8],
      GLShotType_Name: sh[w[12]] || '', AxePhial_Name: L('axePhial')[w[13]] || '',
      ISKinsectType_Name: L('kinsectType')[w[15]] || '',
      GunReloadSpd_Name: L('reload')[w[18]] || '', GunRecoil_Name: L('recoil')[w[20]] || '',
      GunSteadiness_Name: L('steadiness')[w[19]] || '',
      BowShot_Name: L('bowShot')[w[16]] || '',
      BowShotType1_Name: sh[bs[0]] || '', BowShotType2_Name: sh[bs[1]] || '',
      BowShotType3_Name: sh[bs[2]] || '', BowShotType4_Name: sh[bs[3]] || '',
      ProPx: w[21], LvUpPx: w[22], SharpP1: w[23], 间隔: gap[w[18]] || ''
    }, w, w[0], CD.wpnIcon(w[10], 16), CD.sharpBar(w[9], 0, w[23]));
  }
  function amrRow(a) {
    var r = a[7] || [];
    return row({
      Amr_ID: a[0], Amr_Name: a[2], BorG: a[8], MorF: a[9], Rare: a[3], Part: a[1],
      Slot: a[4], Def: a[5], MaxDef: a[6], Res_Fire: r[0], Res_Water: r[1],
      Res_Ice: r[3], Res_Thunder: r[2], Res_Dragon: r[4], Price: a[11], 防御: a[5]
    }, a, a[0], CD.amrIcon(a[10], 16));
  }
  function itmRow(i) {
    return row({ Itm_ID: i[0], Itm_Name: i[1], Rare: i[2], Max: i[3], Sell: i[4], Buy: i[5], Hex: i[6] },
      i, i[0], CD.itemIcon(i[0], 16));
  }
  function jewRow(j) {
    var sk = j[4] || [], it = IX.items.get(j[3]);
    return row({
      Jew_ID: j[0], Itm_ID: j[3], Jew_Name: j[1], Slot: j[2], Price: it ? it[5] : '',
      SklTree1_ID: sk[0] ? sk[0][0] : '', SklTree1_Name: sk[0] ? CD.treeName(sk[0][0]) : '', SklTree1_Pt: sk[0] ? sk[0][1] : '',
      SklTree2_ID: sk[1] ? sk[1][0] : '', SklTree2_Name: sk[1] ? CD.treeName(sk[1][0]) : '', SklTree2_Pt: sk[1] ? sk[1][1] : ''
    }, j, j[0], CD.itemIcon(j[3], 16));
  }
  function qstRow(q) {
    return row({
      Qst_ID: q[0], Qst_Name: q[1], Qst_Lv: q[2], Qst_Type: q[3], Qst_Key: q[4],
      Loc_Name: q[5], Qst_Goal: q[6], Qst_Goal2: q[12], Fee: q[8], Time: q[9],
      Reward: q[10], HRP: q[11], 任务: q[1], 地图: q[5], 报酬金: q[10]
    }, q, q[0], '');
  }
  function sklTreeRow(t) {
    var o = { SklTree_ID: t[0], SklTree_Name: t[1], 技能系统: t[1] };
    var pos = t[2].filter(function (x) { return x > 0; });
    for (var i = 0; i < 7; i++) {
      o['Pt' + i] = pos[i] != null ? pos[i] : '';
      // 原程序技能页：每列是该阈值触发的技能名
      o['Skl' + i] = t[3][i] || '';
    }
    o.Pt = pos[pos.length - 1] || ''; o.Skl_Name = t[3][t[3].length - 1] || '';
    return row(o, t, t[0], '');
  }
  function hhsongRow(s) {
    return row({
      HHSong_ID: s[0], '#': s[0], HHSongRank_ID: s[1],
      Note1_ID: s[2][0], Note2_ID: s[2][1], Note3_ID: s[2][2], Note4_ID: s[2][3],
      '旋律效果': s[3], '持续时间': s[4], '吹笛名人': s[5],
      '重奏效果': s[6], Reload: s[8], Category1_Name: s[9], Category2_Name: s[10]
    }, s, s[0], '');
  }
  function hfhRow(h) {
    return row({
      Hfh_ID: h[0], '#': h[0], '等级': h[2], '任务': h[1], '地图': h[3],
      '成功率': h[4], '大成功率': h[5], '受理费': h[6], '追加契约金': h[7],
      '怪物': (h[8] || []).map(CD.monName).join('、'), '报酬': ''
    }, h, h[0], '');
  }
  function vetRow(v) {
    return row({
      '#': v[0], ItmOut_ID: v[0], '道具 (给出)': CD.itemName(v[0]),
      ItmIn_ID: v[1], '道具 (入手)': CD.itemName(v[1]), '概率': v[2],
      Loc_ID: v[3], '地图': CD.locName(v[3])
    }, v, v[0], CD.itemIcon(v[1], 16));
  }
  function araRow(a) {
    return row({
      Ara_ID: a[0], '#': a[0], '任务': CD.locName(a[1]) + ' 斗技', '地图': a[1],
      '报酬金': a[2], '人数': a[3], S: a[4], A: a[5], B: a[6],
      '怪物': (a[7] || []).map(CD.monName).join('、')
    }, a, a[0], '');
  }
  function peliWpnRow(p) {
    return row({
      PeliWpn_ID: p[0], '#': p[0], '随从武器': CD.itemName(p[0]) || ('#' + p[0]), Part: p[1],
      '稀有度': p[3], '类型': L('peliType')[p[2]] || p[2], '近身': p[5], '会心率': p[6],
      AtkD_SpAtkPt: p[7], '远程': p[8], '属性': CD.elemName([[p[14], p[10]]]),
      '防御': p[11], '生产价': p[12]
    }, p, p[0], p[4] ? '<img src="img/pw/' + p[4] + '.webp" style="width:16px;height:16px">' : '');
  }
  function peliAmrRow(p) {
    var r = p[5] || [];
    return row({
      PeliAmr_ID: p[0], '#': p[0], '随从防具': p[2], Part: p[1], '稀有度': p[3],
      '防御': p[4], Res_Fire: r[0], Res_Water: r[1], Res_Thunder: r[2], Res_Ice: r[3], Res_Dragon: r[4]
    }, p, p[0], p[6] ? '<img src="img/pa/' + p[6] + '.webp" style="width:16px;height:16px">' : '');
  }
  function kinsectRow(k) {
    // DB_ISKinsect.Type 存的是 31/32，对应 ID_Wpn_ISKinsectType 的 1=切断 / 2=打击
    return row({ ISKinsect_ID: k[0], '#': k[0], '猎虫': k[1],
      '类型': L('kinsectType')[k[2] - 30] || k[2], '稀有度': k[3] },
      k, k[0], k[4] ? '<img src="img/k/' + k[4] + '.webp" style="width:16px;height:16px">' : '');
  }
  function medalRow(m) {
    return row({ Awd_ID: m[0], '#': m[0], '勋章': m[1], '说明': m[2] }, m, m[0], '');
  }

  /* ---------------- 联动：从选中的行取上下文 ---------------- */
  function sel(ctx) { return ctx && ctx.sel ? ctx.sel : null; }
  function sid(ctx) { var s = sel(ctx); return s ? s._id : 0; }
  function recipe(ctx, kind, prefix) {
    var s = sel(ctx); if (!s || s._kind !== kind) return [];
    return (D.recipes[prefix + s._id] || []).map(function (x) { return ir(x[0], x[1], ''); });
  }
  function useList(ctx, key) {
    var s = sel(ctx); if (!s || s._kind !== 'itm') return [];
    var u = D.item_use[String(s._id)] || {}, list = u[key] || [];
    return list.map(function (x) {
      var k = x[0], t = k[0], id = +k.slice(1), nm = '', icon = '';
      if (t === 'w') { nm = CD.wpnName(id); var w = IX.weapons.get(id); icon = w ? CD.wpnIcon(w[10], 16) : ''; }
      else if (t === 'a') { nm = CD.amrName(id); var a = IX.armor.get(id); icon = a ? CD.amrIcon(a[10], 16) : ''; }
      else if (t === 'j') { var j = IX.jewels.get(id); nm = j ? j[1] : ''; icon = j ? CD.itemIcon(j[3], 16) : ''; }
      else if (t === 'p') { var p = IX.peliWeapons.get(id); nm = p ? (CD.itemName(p[0]) || '#' + id) : '#' + id; }
      else if (t === 'q') { var q = IX.peliArmor.get(id); nm = q ? q[2] : '#' + id; }
      else nm = '#' + id;
      return row({ '数量': x[1], Qty: x[1], Wpn_Name: nm, Amr_Name: nm, Jew_Name: nm,
        '武器': nm, '防具': nm, '装饰品': nm, '随从武器': nm, '随从防具': nm, '装饰珠': nm,
        '调合': nm, '山菜爷': nm, Amr_ID: id, Wpn_ID: id, Jew_ID: id, Rare: '', Part: '' },
        [id, x[1]], id, icon);
    });
  }
  function srcList(ctx, key) {
    var s = sel(ctx); if (!s || s._kind !== 'itm') return [];
    var d = D.item_src[String(s._id)] || {}, list = d[key] || [];
    return list.map(function (x) {
      var o = {}, ic = CD.itemIcon(s._id, 16);
      if (key === 'm') {
        o = { Qty: x[1], Pct: x[3], Rank: L('rank')[x[1]] || x[1],
          Mon_GetItmType: x[2], Mon_ID: x[0], Mon_Name: CD.monName(x[0]),
          '数量': x[1], '概率': x[3], '获取方式': x[2], '怪物': CD.monName(x[0]) };
        ic = x[0] ? CD.monIcon(x[0], 16) : '';
      } else if (key === 'l') {
        o = { Rank: L('rank')[x[2]] || x[2], Loc_ID: x[0], Loc_Ara: x[1],
          Loc_Name: CD.locName(x[0]), '等级': L('rank')[x[2]] || x[2],
          '地图': CD.locName(x[0]), '区域': x[1], '类型': x[1] };
      } else if (key === 'q') {
        var q = IX.quests.get(x);
        o = { Qst_ID: x, Qst_Name: q ? q[1] : '#' + x, Qst_Lv: q ? q[2] : '',
          Qty: '', Pct: '', Type: '',
          '任务': q ? q[1] : '#' + x, '等级': q ? q[2] : '', '数量': '', '概率': '' };
      } else if (key === 'v') {
        o = { Pct: x[1], ItmIn_ID: x[0], Itm_Name: CD.itemName(x[0]),
          '道具 (入手)': CD.itemName(x[0]), '道具 (给出)': CD.itemName(s._id) };
      } else if (key === 'h') {
        var h = IX.hfh.get(x[0]);
        o = { Hfh_ID: x[0], Hfh_Name: h ? h[1] : '', Rank: h ? h[2] : '',
          Qty: '', Pct: x[2], Type: x[1],
          '任务': h ? h[1] : '', '等级': h ? h[2] : '', '数量': '', '概率': x[2], '报酬': x[1] };
      } else if (key === 'p') {
        o = { PeliZone: L('peliZone')[x[0]] || '', Rank: L('rank')[x[1]] || x[1],
          Pct: x[2], '地带': L('peliZone')[x[0]] || '', '等级': L('rank')[x[1]] || x[1],
          '概率': x[2], '数量': '' };
      } else if (key === 'a') {
        o = { Ara_ID: x[0], Pct: x[1], '斗技大会': '#' + x[0], '概率': x[1], '数量': '' };
      } else if (key === 'c') {
        var c = IX.combo.get(x);
        o = { Cbo_ID: x, Itm_Name: c ? CD.itemName(c[1]) : '', Qty: c ? c[5] : '',
          '结果': c ? CD.itemName(c[1]) : '', '道具A': c ? CD.itemName(c[2]) : '',
          '道具B': c ? CD.itemName(c[3]) : '', '数量': c ? c[5] : '' };
      }
      return row(o, x, x[0] != null ? x[0] : x, ic);
    });
  }
  function rewardRows(ctx, t) {
    var s = sel(ctx); if (!s || s._kind !== 'qst') return [];
    var r = D.quest_rewards[String(s._id)] || {};
    return (r[t] || []).map(function (x) { return ir(x[0], x[1], x[2]); });
  }
  function gunRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'wpn') return [];
    var a = D.wpn_gun[String(s._id)] || [];
    return a.map(function (x) {
      var nm = CD.itemName(x[0]), gap = L('rapidGap')[x[5]] || '';
      return row({ Itm_ID: x[0], Itm_Name: nm, '道具': nm,
        LoadQty: x[1], '装填数': x[1], LoadQtyP: x[2], '追加': x[2],
        Max: x[3], '数量': x[3], SpFireQty: x[4], '特殊射击数量': x[4],
        RapidFireGap_Name: gap, RapidFireGap_Nam: gap, '间隔': gap },
        x, x[0], CD.itemIcon(x[0], 16));
    });
  }
  function songRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'wpn') return [];
    return (D.wpn_songs[String(s._id)] || []).map(function (x) {
      var so = IX.hhsongs.get(x[0]);
      return row({ '#': x[0], '旋律效果': so ? so[3] : '', Note1_ID: so ? so[2][0] : '',
        Note2_ID: so ? so[2][1] : '', Note3_ID: so ? so[2][2] : '', Note4_ID: so ? so[2][3] : '',
        HHSongRank_ID: x[1] }, so || x, x[0], '');
    });
  }
  function monRows(ctx, kind) {
    var s = sel(ctx); if (!s || s._kind !== 'mon') return [];
    // monsters.json 行结构：[ID, 名称, 肉质, 异常耐性, 陷阱] —— 名称占 1，数据从 2 开始
    var m = s._raw || [];
    if (kind === 'weak') return (m[2] || []).map(function (x) {
      // 属性数组顺序：火 水 冰 雷 龙
      return row({ MonPart_Num: x[0], '#': x[0], MonPart_Name: x[1], MonPartCond_Name: '',
        Cut: x[2], Impact: x[3], Shot: x[4],
        Fir: x[5][0], Wtr: x[5][1], Ice: x[5][2], Thd: x[5][3], Drg: x[5][4], Diz: x[6] }, x, x[0], '');
    });
    if (kind === 'ail') return (m[3] || []).map(function (x) {
      var si = (x[0] >= 1 && x[0] <= 13 && x[0] !== 12)
        ? 'img/i/Stat_' + ('0' + x[0]).slice(-2) + '.png' : '';
      return row({ Stat_ID: x[0], TolInitial: x[1], TolIncrease: x[2], TolMax: x[3],
        Duration: x[4], Damage: x[5],
        '初始耐性': x[1], '耐性增量': x[2], '最大耐性': x[3],
        '持续时间': x[4], '总伤害': x[5] }, x, x[0],
        si ? '<img src="' + si + '" width="18" height="18" style="object-fit:contain" alt="">' : '');
    });
    if (kind === 'trap') return (m[4] || []).map(function (x) {
      return row({ Trap_ID: x[0], IsEffect_Text: (x[1] === 1 || x[1] === '1') ? '○' : '×',
        Duration: x[2], DurationEnraged: x[3], DurationFatigued: x[4],
        '持续时间': x[2], '愤怒时持续时间': x[3], '疲劳时持续时间': x[4] }, x, x[0], '');
    });
    return [];
  }
  function dropRows(ctx, rank) {
    var s = sel(ctx); if (!s || s._kind !== 'mon') return [];
    var d = D.mon_drops[String(s._id)] || {};
    return (d[String(rank)] || []).map(function (x) {
      return row({ Itm_ID: x[0], '道具': CD.itemName(x[0]), '数量': x[1], '概率': x[2],
        '获取方式': x[3] }, x, x[0], CD.itemIcon(x[0], 16));
    });
  }
  function amrSkillRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'amr') return [];
    return ((s._raw || [])[12] || []).map(function (x) {
      return row({ SklTree_ID: x[0], '技能系统': CD.treeName(x[0]), '点数': x[1] }, x, x[0], '');
    });
  }
  function jewelMatRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'jew') return [];
    return recipe(ctx, 'jew', 'j');
  }
  function sklArmRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'skl') return [];
    var tid = s._id, out = [];
    D.armor.forEach(function (a) {
      (a[12] || []).forEach(function (x) {
        if (x[0] === tid) out.push(row({ '点数': x[1], Amr_ID: a[0], Rare: a[3], Part: a[1],
          '防具': a[2], '插槽': a[4], '防御': a[5] }, a, a[0], CD.amrIcon(a[10], 16)));
      });
    });
    return out.slice(0, 300);
  }
  function sklJewRows(ctx) {
    var s = sel(ctx); if (!s || s._kind !== 'skl') return [];
    var tid = s._id, out = [];
    D.jewels.forEach(function (j) {
      (j[4] || []).forEach(function (x) {
        if (x[0] === tid) out.push(row({ '点数': x[1], Jew_ID: j[0], Itm_ID: j[3],
          '装饰品': j[1], '插槽': j[2] }, j, j[0], CD.itemIcon(j[3], 16)));
      });
    });
    return out;
  }
  function locItmRows(ctx, area) {
    var s = sel(ctx); if (!s || s._kind !== 'loc') return [];
    var d = D.maps.data[String(s._id)] || {}, rank = ctx.rank || '1';
    var areas = d[rank] || [];
    var pick = area === 1 ? areas.filter(function (x) { return x[0] <= 5; })
      : area === 2 ? areas.filter(function (x) { return x[0] > 5 && x[0] <= 10; })
        : areas.filter(function (x) { return x[0] > 10; });
    var out = [];
    pick.forEach(function (ar) {
      (ar[1] || []).forEach(function (it) {
        out.push(row({ '区域': ar[0], Itm_ID: it[0], '道具': CD.itemName(it[0]), '类型': it[1] },
          it, it[0], CD.itemIcon(it[0], 16)));
      });
    });
    return out;
  }
  function comboRows(ctx) {
    return D.combo.map(function (c) {
      return row({ Cbo_ID: c[0], ItmC_ID: c[1], ItmC_Name: CD.itemName(c[1]),
        ItmA_ID: c[2], ItmA_Name: CD.itemName(c[2]), ItmB_ID: c[3], ItmB_Name: CD.itemName(c[3]),
        Succ: c[4], Qty: c[5], '结果': CD.itemName(c[1]) }, c, c[0], CD.itemIcon(c[1], 16));
    });
  }
  function peliTeamRows(ctx) {
    var out = [];
    Object.keys(D.peliteam.data || {}).forEach(function (z) {
      var rv = D.peliteam.data[z];
      Object.keys(rv).forEach(function (rk) {
        rv[rk].forEach(function (x) {
          out.push(row({ '#': out.length + 1, '地带': L('peliZone')[z] || '', '等级': L('rank')[rk] || rk,
            Itm_ID: x[0], '道具': CD.itemName(x[0]), '数量': x[1], '概率': x[2] },
            x, x[0], CD.itemIcon(x[0], 16)));
        });
      });
    });
    return out;
  }
  function ammoRows(ctx) {
    var B = D.bowgun;
    return B.rows.map(function (r) {
      var w = IX.weapons.get(r[0]);
      var o = { '#': r[0], '武器': w ? w[2] : '#' + r[0], Wpn_Type_ID: w ? w[1] : '', Rare: w ? w[3] : '' };
      for (var i = 1; i <= 17; i++) {
        var a = r[i] || [0, 0, 0];
        for (var lv = 1; lv <= 3; lv++) o['A' + ('0' + i).slice(-2) + '_' + lv + '_Qty'] = a[lv - 1];
      }
      return row(o, r, r[0], w ? CD.wpnIcon(w[10], 16) : '');
    });
  }
  function hfhRewardRows(ctx, t) {
    var s = sel(ctx); if (!s || s._kind !== 'hfh') return [];
    return ((s._raw || [])[9] || []).filter(function (x) { return x[3] === t; })
      .map(function (x) { return ir(x[0], x[1], x[2]); });
  }
  function araRows(ctx, kind) {
    var s = sel(ctx); if (!s || s._kind !== 'ara') return [];
    var a = s._raw || [], idx = { wpn: 8, amr: 9, itm: 10, box: 11 }[kind] || 10;
    return (a[idx] || []).map(function (x) {
      if (kind === 'wpn') return row({ Wpn_ID: x[0], '武器': CD.wpnName(x[0]), Rare: '', Part: x[1] }, x, x[0], CD.wpnIcon((IX.weapons.get(x[0]) || [])[10], 16));
      if (kind === 'amr') return row({ Amr_ID: x[0], '防具': CD.amrName(x[0]), Rare: '', Part: x[1] }, x, x[0], CD.amrIcon((IX.armor.get(x[0]) || [])[10], 16));
      return ir(x[0], x[1], x[2]);
    });
  }

  /* ---------------- 统一入口 ---------------- */
  var MAIN = {
    '_DGV_WpnList': function () { return D.weapons.map(wpnRow); },
    '_DGV_AmrList': function () { return D.armor.map(amrRow); },
    '_DGV_ItmList': function () { return D.items.map(itmRow); },
    '_DGV_JewList': function () { return D.jewels.map(jewRow); },
    '_DGV_QstList': function () { return D.quests.map(qstRow); },
    '_DGV_MonList': function () { return (D.monsters || []).map(function (m) {
      return row({ Mon_ID: m[0], Mon_Name: m[1], '怪物': m[1] }, m, m[0], CD.monIcon(m[0], 16));
    }); },
    '_DGV_SklList': function () { return D.skills.trees.map(sklTreeRow); },
    '_DGV_CboList': comboRows,
    '_DGV_HHSongList': function () { return D.hhsongs.map(hhsongRow); },
    '_DGV_HfhList': function () { return D.hfh.map(hfhRow); },
    '_DGV_VetList': function () { return D.veggie.map(vetRow); },
    '_DGV_AraList': function () { return D.arena.map(araRow); },
    '_DGV_PeliWpnList': function () { return D.peli_weapons.map(peliWpnRow); },
    '_DGV_PeliAmrList': function () { return D.peli_armor.map(peliAmrRow); },
    '_DGV_PeliTeamList': peliTeamRows,
    '_DGV_BGAmmoList': ammoRows,
    '_DGV_ISKinsectList': function () { return D.kinsects.map(kinsectRow); },
    '_DGV_AwdList': function () { return D.medals.map(medalRow); },
    '_DGV_TlsList': function () { return []; }
  };
  var LINK = {
    '_DGV_WpntoItmP': function (c) { return recipe(c, 'wpn', 'w'); },
    '_DGV_WpntoItmU': function (c) {
      var s = sel(c); if (!s || s._kind !== 'wpn') return [];
      return (D.weapon_upg[String(s._id)] || []).map(function (x) { return ir(x[0], x[1], ''); });
    },
    '_DGV_Gun': gunRows, '_DGV_WpntoHHSong': songRows,
    '_DGV_AmrtoItm': function (c) { return recipe(c, 'amr', 'a'); },
    '_DGV_AmrtoSklTree': amrSkillRows,
    '_DGV_JewtoItm': jewelMatRows,
    '_DGV_SklTreetoAmr': sklArmRows, '_DGV_SklTreetoJew': sklJewRows,
    '_DGV_QsttoItmA': function (c) { return rewardRows(c, 'A'); },
    '_DGV_QsttoItmB': function (c) { return rewardRows(c, 'B'); },
    '_DGV_QsttoItmC': function (c) { return rewardRows(c, 'C'); },
    '_DGV_QsttoItmD': function (c) { return rewardRows(c, 'D'); },
    '_DGV_Weak': function (c) { return monRows(c, 'weak'); },
    '_DGV_Ail': function (c) { return monRows(c, 'ail'); },
    '_DGV_Trap': function (c) { return monRows(c, 'trap'); },
    '_DGV_HfhtoItmA': function (c) { return hfhRewardRows(c, 'A'); },
    '_DGV_HfhtoItmB': function (c) { return hfhRewardRows(c, 'B'); },
    '_DGV_HfhtoItmC': function (c) { return hfhRewardRows(c, 'C'); },
    '_DGV_AratoWpnA': function (c) { return araRows(c, 'wpn'); },
    '_DGV_AratoAmrA': function (c) { return araRows(c, 'amr'); },
    '_DGV_AratoItm': function (c) { return araRows(c, 'itm'); },
    '_DGV_LoctoItm1': function (c) { return locItmRows(c, 1); },
    '_DGV_LoctoItm2': function (c) { return locItmRows(c, 2); },
    '_DGV_LoctoItm3': function (c) { return locItmRows(c, 3); },
    // 道具「用处」列
    '_DGV_ItmtoWpn': function (c) { return useList(c, 'w'); },
    '_DGV_ItmtoAmr': function (c) { return useList(c, 'a'); },
    '_DGV_ItmtoJew': function (c) { return useList(c, 'j'); },
    '_DGV_ItmtoPeliWpn': function (c) { return useList(c, 'p'); },
    '_DGV_ItmtoPeliAmr': function (c) { return useList(c, 'q'); },
    '_DGV_ItmtoCboU': function (c) { return useList(c, 'c'); },
    '_DGV_ItmtoVetU': function (c) { return useList(c, 'v'); },
    // 道具「来源」列
    '_DGV_ItmtoMon': function (c) { return srcList(c, 'm'); },
    '_DGV_ItmtoLoc': function (c) { return srcList(c, 'l'); },
    '_DGV_ItmtoQst': function (c) { return srcList(c, 'q'); },
    '_DGV_ItmtoVetS': function (c) { return srcList(c, 'v'); },
    '_DGV_ItmtoHfh': function (c) { return srcList(c, 'h'); },
    '_DGV_ItmtoPeliTeam': function (c) { return srcList(c, 'p'); },
    '_DGV_ItmtoAra': function (c) { return srcList(c, 'a'); },
    '_DGV_ItmtoCboS': function (c) { return srcList(c, 'c'); }
  };
  // 怪物 12 个掉落分组
  for (var i = 1; i <= 12; i++) {
    (function (n) { LINK['_DGV_Itm' + n] = function (c) { return dropRows(c, n); }; })(i);
  }
  // 斗技大会 A~E 组
  ['A', 'B', 'C', 'D', 'E'].forEach(function (t) {
    LINK['_DGV_AratoWpn' + t] = function (c) { return araRows(c, 'wpn'); };
    LINK['_DGV_AratoAmr' + t] = function (c) { return araRows(c, 'amr'); };
    LINK['_DGV_AratoItm' + t] = function (c) { return araRows(c, 'itm'); };
  });

  /* ---------------- 地图 / 猎虫 / 勋章 ---------------- */
  function locRows(c, rank) {
    var s = sel(c); if (!s || s._kind !== 'loc') return [];
    var d = D.maps.data[String(s._id)] || {}, areas = d[rank] || [], out = [];
    areas.forEach(function (ar) {
      (ar[1] || []).forEach(function (it) {
        var nm = CD.itemName(it[0]);
        out.push(row({ Loc_Ara: ar[0], '区域': ar[0], Itm_ID: it[0], Itm_Name: nm,
          Loc_GetType_ID: it[1], '类型': it[1] }, it, it[0], CD.itemIcon(it[0], 16)));
      });
    });
    return out;
  }
  LINK['_DGV_LoctoItm1'] = function (c) { return locRows(c, '1'); };
  LINK['_DGV_LoctoItm2'] = function (c) { return locRows(c, '2'); };
  LINK['_DGV_LoctoItm3'] = function (c) { return locRows(c, '3'); };
  CD.locList = function () {
    return (D.maps.locs || []).map(function (x) {
      return row({ Loc_ID: x[0], Loc_Name: x[1] }, x, x[0], '');
    });
  };

  LINK['_DGV_ISKinsecttoItm'] = function (c) {
    var s = sel(c); if (!s || s._kind !== 'kinsect') return [];
    return ((s._raw || [])[6] || []).map(function (x) { return ir(x[0], x[1], ''); });
  };
  LINK['_DGV_ISKinsectBugSkill'] = function (c) {
    var s = sel(c); if (!s || s._kind !== 'kinsect') return [];
    return ((s._raw || [])[5] || []).map(function (n) {
      return row({ BugSkill_Name: n, '虫技能': n }, [n], 0, '');
    });
  };
  LINK['_DGV_ISKinsectExtractSkill'] = function (c) {
    var s = sel(c); if (!s || s._kind !== 'kinsect') return [];
    var k = s._raw || [];
    // k[7]：DB_ISKinsectExtractSkill 的中文名称；缺失时退回猎虫类型名
    var list = (k[7] || []).length ? k[7] : [L('kinsectType')[k[2] - 30] || ''];
    return list.filter(Boolean).map(function (n, i) {
      return row({ ExtractSkill_Name: n, '精华技能': n }, [n], i, '');
    });
  };
  /* 反编译对照补齐：旋律→可演奏武器、随从武器/防具→生产素材 */
  var NOTE_COLOR = ['#c0392b', '#2980b9', '#27ae60', '#8e44ad', '#d35400', '#16a085', '#7f8c8d', '#c2185b'];
  function noteIcon(id) {
    if (!(id >= 1 && id <= 8)) return '';
    return '<span style="display:inline-block;width:15px;height:15px;border-radius:50%;background:' +
      NOTE_COLOR[id - 1] + ';color:#fff;text-align:center;line-height:15px;font-size:10px">' + id + '</span>';
  }
  LINK['_DGV_HHSongtoWpn'] = function (c) {
    var s = sel(c); if (!s || s._kind !== 'song') return [];
    var list = ((D.extra_links || {}).song_wpn || {})[String(s._id)] || [];
    return list.map(function (x) {
      var w = IX.weapons.get(x[0]) || [], notes = w[14] || [];
      var o = row({ Wpn_ID: x[0], Wpn_Name: CD.wpnName(x[0]), Wpn_Type_ID: w[1] || '',
        Rare: w[3] || '', HHNote1_ID: notes[0], HHNote2_ID: notes[1], HHNote3_ID: notes[2] },
        w, x[0], CD.wpnIcon(w[10], 16));
      o._icons = {
        DGVImgCol_WpnNote1: noteIcon(notes[0]),
        DGVImgCol_WpnNote2: noteIcon(notes[1]),
        DGVImgCol_WpnNote3: noteIcon(notes[2]),
        DGVImgCol_Wpn: CD.wpnIcon(w[10], 16)
      };
      return o;
    });
  };
  function peliMats(c, kind, key) {
    var s = sel(c); if (!s || s._kind !== kind) return [];
    var map = ((D.extra_links || {})[key]) || {};
    return (map[String(s._id)] || []).map(function (x) { return ir(x[0], x[1], ''); });
  }
  LINK['_DGV_PeliWpntoItm'] = function (c) { return peliMats(c, 'peliWpn', 'peli_wpn'); };
  LINK['_DGV_PeliAmrtoItm'] = function (c) { return peliMats(c, 'peliAmr', 'peli_amr'); };
  CD.medalList = function () { return D.medals.map(medalRow); };

  /* ---------------- 套装配装器（技能列表 + 搜索） ---------------- */
  var ASF_TARGETS = [], ASF_RESULTS = [];
  function sklFromRows() {
    var out = [];
    D.skills.trees.forEach(function (t) {
      var pos = t[2].filter(function (x) { return x > 0; });
      pos.forEach(function (p, i) {
        var nm = t[3][i] || t[1];
        out.push(row({ Skl_ID: t[0] * 100 + i, '#': t[0], Skl_Name: nm, '技能': nm,
          SklTree_ID: t[0], SklTree_Name: t[1], '技能系统': t[1], Pt: p, '点数': p },
          [t[0], p, nm], t[0], ''));
      });
    });
    return out;
  }
  MAIN['_DGV_SklList_From'] = sklFromRows;
  MAIN['_DGV_SklList_To'] = function () {
    return ASF_TARGETS.map(function (t, i) {
      return row({ Skl_ID: i + 1, '#': i + 1, Skl_Name: t.name, '技能': t.name,
        SklTree_ID: t.tree, SklTree_Name: t.treeName, '技能系统': t.treeName,
        Pt: t.pt, '点数': t.pt }, t, i, '');
    });
  };
  MAIN['_DGV_AsftoAsb'] = function () { return ASF_RESULTS; };
  CD.asfAdd = function (r) {
    if (!r) return;
    var tree = r.SklTree_ID, pt = r.Pt;
    if (!tree || !pt) return;
    var ex = ASF_TARGETS.filter(function (x) { return x.tree === tree; })[0];
    if (ex) ex.pt = pt, ex.name = r.Skl_Name;
    else ASF_TARGETS.push({ tree: tree, treeName: r.SklTree_Name, name: r.Skl_Name, pt: pt });
  };
  CD.asfDel = function () { ASF_TARGETS.pop(); };
  CD.asfClear = function () { ASF_TARGETS = []; ASF_RESULTS = []; };
  CD.asfRun = function () {
    ASF_RESULTS = [];
    if (!ASF_TARGETS.length) return 0;
    var need = ASF_TARGETS.map(function (t) { return t.pt; });
    var tidx = new Map(ASF_TARGETS.map(function (t, i) { return [t.tree, i]; }));
    var byPart = {};
    D.armor.forEach(function (a) { (byPart[a[1]] = byPart[a[1]] || []).push(a); });
    var cand = [1, 2, 3, 4, 5].map(function (p) {
      var all = byPart[p] || [];
      var hit = all.map(function (a) {
        var pts = new Array(need.length).fill(0), sum = 0;
        (a[12] || []).forEach(function (x) {
          var i = tidx.get(x[0]); if (i != null && x[1] > 0) { pts[i] += x[1]; sum += x[1]; }
        });
        return { a: a, pts: pts, sum: sum, def: a[5], max: a[6] };
      }).filter(function (x) { return x.sum > 0; })
        .sort(function (x, y) { return y.sum - x.sum || y.def - x.def; }).slice(0, 26);
      var used = new Set(hit.map(function (x) { return x.a[0]; }));
      // 即使某部位完全没有目标技能，也要能选一件「凑数」装备，否则 DFS 到不了终点
      var filler = all.slice().sort(function (a, b) { return b[5] - a[5]; })
        .filter(function (a) { return !used.has(a[0]); }).slice(0, 6)
        .map(function (a) {
          return { a: a, pts: new Array(need.length).fill(0), sum: 0, def: a[5], max: a[6] };
        });
      return hit.concat(filler);
    });
    var bnd = cand.map(function (list) {
      var m = new Array(need.length).fill(0);
      list.forEach(function (x) { x.pts.forEach(function (v, i) { if (v > m[i]) m[i] = v; }); });
      return m;
    });
    var nodes = 0;
    function dfs(part, pts, picked) {
      if (ASF_RESULTS.length >= 40 || nodes++ > 120000) return;
      if (part === 5) {
        // 剩余缺口可由孔位装装饰品补足（每孔按 2 点估）
        var slots = picked.reduce(function (s, x) { return s + (x.a[4] || 0); }, 0);
        if (pts.every(function (v, i) { return v + slots * 2 >= need[i]; })) {
          var o = { ID: ASF_RESULTS.length + 1, '#': ASF_RESULTS.length + 1, Def: 0, MaxDef: 0 };
          picked.forEach(function (x, i) {
            o['Amr' + (i + 1) + '_ID'] = x.a[0];
            o['Amr' + (i + 1) + '_Name'] = x.a[2];
            o.Def += x.def; o.MaxDef += x.max;
          });
          ASF_RESULTS.push(row(o, picked, ASF_RESULTS.length + 1, ''));
        }
        return;
      }
      var ok = true;
      for (var i = 0; i < need.length; i++) {
        var can = pts[i] + 10;                 // 装饰品余量
        for (var k = part; k < 5; k++) can += bnd[k][i];
        if (can < need[i]) { ok = false; break; }
      }
      if (!ok) return;
      var list = cand[part];
      for (var j = 0; j < list.length; j++) {
        var c = list[j], np = pts.slice();
        for (var z = 0; z < need.length; z++) np[z] += c.pts[z];
        dfs(part + 1, np, picked.concat(c));
        if (ASF_RESULTS.length >= 40) return;
      }
    }
    dfs(0, new Array(need.length).fill(0), []);
    return ASF_RESULTS.length;
  };

  /* ---------------- 套装模拟器（原程序 Armor Set Builder） ----------------
     控件布局来自反编译：武器 3 孔 + 5 个部位各 1 件装备/3 孔 + 护石 3 孔。
     状态存于此，rowsFor 按 form==='asb' 分派到专用结果表。 */
  var ASB = {
    armor: [null, null, null, null, null],
    jewels: [[null, null, null], [null, null, null], [null, null, null],
      [null, null, null], [null, null, null]],
    wpnJewels: [null, null, null],
    charmJewels: [null, null, null],
    charmPts: [],
    active: 0, pendingArmor: null, pendingJewel: null
  };
  CD.asb = ASB;
  var ASB_PART = ['头', '胴', '腕', '腰', '脚'];
  CD.ASB_PART = ASB_PART;

  function asbPts() {
    var p = {};
    function add(list) {
      (list || []).forEach(function (x) { p[x[0]] = (p[x[0]] || 0) + x[1]; });
    }
    ASB.armor.forEach(function (a) { if (a) add(a[12]); });
    [ASB.wpnJewels].concat(ASB.jewels, [ASB.charmJewels]).forEach(function (js) {
      js.forEach(function (j) { if (j) add(j[4]); });
    });
    add(ASB.charmPts);
    return p;
  }
  CD.asbStats = function () {
    var def = 0, mx = 0, slots = 0, used = 0;
    ASB.armor.forEach(function (a, i) {
      if (!a) return;
      def += a[5] || 0; mx += a[6] || 0; slots += a[4] || 0;
      ASB.jewels[i].forEach(function (j) { if (j) used += j[2] || 0; });
    });
    [ASB.wpnJewels, ASB.charmJewels].forEach(function (js) {
      js.forEach(function (j) { if (j) used += j[2] || 0; });
    });
    var p = asbPts(), on = [];
    D.skills.trees.forEach(function (t) {
      var pos = t[2].filter(function (x) { return x > 0; }), lv = 0;
      pos.forEach(function (v, i) { if ((p[t[0]] || 0) >= v) lv = i + 1; });
      if (lv > 0) on.push((t[3][lv - 1] || t[1]) + ' Lv.' + lv);
    });
    return { def: def, mx: mx, slots: slots, used: used, skills: on };
  };
  CD.asbPickArmor = function (r) {
    ASB.pendingArmor = r ? r._raw : null;
    return ASB.pendingArmor ? '待装备：' + ASB.pendingArmor[2] + ' · 点右侧部位按钮或「＋」加入套装' : '';
  };
  CD.asbPickJewel = function (r) {
    ASB.pendingJewel = r ? r._raw : null;
    return ASB.pendingJewel ? '待镶嵌：' + ASB.pendingJewel[1] + ' · 点孔位按钮装入' : '';
  };
  CD.asbSetActive = function (i) { ASB.active = i; };
  CD.asbAddArmor = function (slot) {
    var a = ASB.pendingArmor;
    if (!a) return '请先在左侧「防具」列表点选一件防具';
    var i = (slot == null) ? (a[1] - 1) : slot;
    if (!(i >= 0 && i <= 4)) i = ASB.active;
    ASB.armor[i] = a;
    return '已装备 ' + a[2] + ' → ' + ASB_PART[i];
  };
  CD.asbRemoveArmor = function (slot) {
    var i = slot == null ? ASB.active : slot;
    if (!ASB.armor[i]) return '该部位还没有装备';
    var nm = ASB.armor[i][2];
    ASB.armor[i] = null; ASB.jewels[i] = [null, null, null];
    return '已卸下 ' + nm;
  };
  function jewelArray(group, slot) {
    if (group === 'wpn') return ASB.wpnJewels;
    if (group === 'charm') return ASB.charmJewels;
    return ASB.jewels[slot];
  }
  CD.asbSetJewel = function (group, slot, idx) {
    var arr = jewelArray(group, slot);
    if (!arr) return '孔位不存在';
    if (!ASB.pendingJewel) { arr[idx] = null; return '已取下该孔装饰珠'; }
    var j = ASB.pendingJewel;
    // 武器/护石按 3 孔处理；防具按该件装备的实际孔数
    var cap = group === 'amr' ? (ASB.armor[slot] ? ASB.armor[slot][4] || 0 : 0) : 3;
    var used = 0;
    arr.forEach(function (x, k) { if (x && k !== idx) used += x[2] || 0; });
    if ((j[2] || 0) + used > cap) return '孔位不足：此处可用 ' + cap + ' 孔，该珠需 ' + j[2] + ' 孔';
    arr[idx] = j;
    return '已镶嵌 ' + j[1];
  };
  CD.asbRemoveJewel = function (slot) {
    var i = slot == null ? ASB.active : slot;
    var arr = ASB.jewels[i]; if (!arr) return '';
    var n = arr.filter(Boolean).length;
    ASB.jewels[i] = [null, null, null];
    return n ? '已取下 ' + n + ' 颗装饰珠' : '该部位没有装饰珠';
  };
  // 首次打开时载入一套示例配装，便于直接看到三张联动表；可随时移除或粘贴套装码覆盖
  CD.asbDemo = function () {
    var picks = {};
    D.armor.forEach(function (a) {
      if (!picks[a[1]] && a[1] >= 1 && a[1] <= 5 && String(a[2]).indexOf('皮制') === 0) picks[a[1]] = a;
    });
    for (var p = 1; p <= 5; p++) if (picks[p]) ASB.armor[p - 1] = picks[p];
    var one = D.jewels.filter(function (j) { return j[2] === 1; });
    ASB.armor.forEach(function (a, i) {
      if (a && a[4] >= 1 && one.length) ASB.jewels[i][0] = one[i % one.length];
    });
    return true;
  };
  function ids(arr) { return arr.map(function (x) { return x ? x[0] : 0; }); }
  CD.asbCode = function () {
    var o = [ids(ASB.armor), ASB.jewels.map(ids), ids(ASB.wpnJewels),
      ids(ASB.charmJewels), ASB.charmPts];
    try { return 'MHXXASB1' + btoa(JSON.stringify(o)); } catch (e) { return ''; }
  };
  CD.asbLoadCode = function (s) {
    s = String(s || '').trim();
    if (s.indexOf('MHXXASB1') !== 0) return '套装码格式不正确（应以 MHXXASB1 开头）';
    try {
      var o = JSON.parse(atob(s.slice(8)));
      ASB.armor = (o[0] || []).map(function (id) { return IX.armor.get(id) || null; });
      ASB.jewels = (o[1] || []).map(function (js) {
        return (js || []).map(function (id) { return IX.jewels.get(id) || null; });
      });
      while (ASB.jewels.length < 5) ASB.jewels.push([null, null, null]);
      ASB.wpnJewels = (o[2] || []).map(function (id) { return IX.jewels.get(id) || null; });
      ASB.charmJewels = (o[3] || []).map(function (id) { return IX.jewels.get(id) || null; });
      ASB.charmPts = o[4] || [];
    } catch (e) { return '套装码解析失败'; }
    return '套装码已载入';
  };

  var ASB_ROWS = {};
  ASB_ROWS['_DGV_AmrList'] = function (ctx) {
    var ft = ctx.filters || {}, parts = ft.parts || [], kw = (ft.kw || '').toLowerCase();
    return D.armor.filter(function (a) {
      if (parts.length && parts.indexOf(a[1]) < 0) return false;
      if (kw && String(a[2]).toLowerCase().indexOf(kw) < 0) return false;
      return true;
    }).map(amrRow);
  };
  ASB_ROWS['_DGV_JewList'] = function (ctx) {
    var kw = ((ctx.filters || {}).kw || '').toLowerCase();
    return D.jewels.filter(function (j) {
      return !kw || String(j[1]).toLowerCase().indexOf(kw) >= 0;
    }).map(jewRow);
  };
  ASB_ROWS['_DGV_AsbtoAmr'] = function () {
    return ASB.armor.filter(Boolean).map(amrRow);
  };
  ASB_ROWS['_DGV_SklList'] = function () {
    var p = asbPts(), out = [];
    D.skills.trees.forEach(function (t) {
      var v = p[t[0]] || 0; if (!v) return;
      var pos = t[2].filter(function (x) { return x > 0; });
      var o = { SklTree_ID: t[0], SklTree_Name: t[1], Pt: v, SortID: t[0] };
      for (var i = 0; i < 7; i++) o['Pt' + i] = pos[i] != null ? pos[i] : '';
      var lv = 0;
      pos.forEach(function (x, i) { if (v >= x) lv = i + 1; });
      o.Skl_Name = lv > 0 ? (t[3][lv - 1] || t[1]) : '';
      out.push(row(o, t, t[0], ''));
    });
    return out;
  };
  ASB_ROWS['_DGV_AsbtoItm'] = function () {
    var bag = {};
    function put(id, q) { if (id) bag[id] = (bag[id] || 0) + (q || 1); }
    ASB.armor.forEach(function (a) {
      if (!a) return;
      (D.recipes['a' + a[0]] || []).forEach(function (x) { put(x[0], x[1]); });
    });
    var all = ASB.wpnJewels.concat(ASB.charmJewels);
    ASB.jewels.forEach(function (js) { all = all.concat(js); });
    all.forEach(function (j) {
      if (!j) return;
      put(j[3], 1);
      (D.recipes['j' + j[0]] || []).forEach(function (x) { put(x[0], x[1]); });
    });
    return Object.keys(bag).map(function (k) { return ir(+k, bag[k], ''); });
  };

  CD.rowsFor = function (t, ctx) {
    try {
      if (ctx && ctx.form === 'asb' && ASB_ROWS[t]) return ASB_ROWS[t](ctx);
      if (MAIN[t]) return MAIN[t](ctx);
      if (LINK[t]) return LINK[t](ctx);
      return [];
    } catch (e) { console.warn('rowsFor', t, e); return []; }
  };
  CD.isMain = function (t) { return !!MAIN[t]; };
  CD.kindOfTable = function (t) {
    return { '_DGV_WpnList': 'wpn', '_DGV_AmrList': 'amr', '_DGV_ItmList': 'itm',
      '_DGV_JewList': 'jew', '_DGV_QstList': 'qst', '_DGV_MonList': 'mon',
      '_DGV_SklList': 'skl', '_DGV_HfhList': 'hfh', '_DGV_AraList': 'ara',
      '_DGV_LocList': 'loc', '_DGV_CboList': 'cbo', '_DGV_VetList': 'vet',
      '_DGV_HHSongList': 'song', '_DGV_PeliWpnList': 'peliWpn',
      '_DGV_PeliAmrList': 'peliAmr', '_DGV_ISKinsectList': 'kinsect',
      '_DGV_AwdList': 'awd' }[t] || '';
  };
  CD.mainRows = function (t) { return CD.rowsFor(t, {}); };
  CD.weaponRows = function () { return D.weapons.map(wpnRow); };

  g.ClassicData = CD;
})(window);
