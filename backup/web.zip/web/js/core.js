/* MHXX 资料库 · 核心：数据加载、路由、通用组件 */
(function () {
  const A = window.A = {};
  A.data = {};
  A.$ = (s, r) => (r || document).querySelector(s);
  A.$$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));

  A.esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  A.fmt = n => (n == null || n === '' || isNaN(n)) ? '—' : Number(n).toLocaleString('en-US');

  /* ---------- 数据加载 ---------- */
  const cache = {};
  A.load = function (names) {
    const todo = names.filter(n => !cache[n]);
    return Promise.all(todo.map(n => fetch('data/' + n + '.json')
      .then(r => { if (!r.ok) throw new Error('data/' + n + '.json'); return r.json(); })
      .then(j => { cache[n] = j; A.data[n] = j; delete A.idx['by:' + n]; }))).then(() => {
        names.forEach(n => { A.data[n] = cache[n]; });
        return A.data;
      });
  };

  A.idx = {};
  A.index = function (name, build) {
    if (!A.idx[name]) A.idx[name] = build();
    return A.idx[name];
  };
  A.byId = function (file, keyIdx) {
    return A.index('by:' + file, () => {
      const m = new Map();
      (A.data[file] || []).forEach(r => m.set(r[keyIdx || 0], r));
      return m;
    });
  };

  /* ---------- 图标 ---------- */
  A.itemIcon = function (id, size) {
    const ic = A.data.item_icons;
    const px = size || 30;
    if (!ic) return `<i class="ico" style="width:${px}px;height:${px}px"></i>`;
    const idx = ic.index[String(id)];
    if (idx == null || idx < 0) return `<i class="ico" style="width:${px}px;height:${px}px"></i>`;
    const c = ic.cols, s = ic.cell, x = (idx % c) * s, y = Math.floor(idx / c) * s, k = px / s;
    return `<i class="ico" style="width:${px}px;height:${px}px;background-image:url(img/icon/items.png);background-position:-${x * k}px -${y * k}px;background-size:${c * s * k}px auto"></i>`;
  };
  A.wpnImg = f => f ? `img/w/${f}.webp` : '';
  A.amrImg = f => f ? `img/a/${f}.webp` : '';
  A.monImg = id => `img/m/${id}.webp`;

  /* ---------- 展示工具 ---------- */
  A.elemHtml = function (ids) {
    const L = (A.data.labels && A.data.labels.elem) || {};
    if (!ids || !ids.length) return '<span class="dim">无</span>';
    return ids.map(([id, pt]) => `<span class="el e${id}">${L[id] || '?'}${pt || ''}</span>`).join(' ');
  };
  // 数据顺序为 紫白蓝绿黄橙赤（下标 0..6），显示时从赤到紫
  const SHARP = ['#9b59b6', '#e8ecef', '#2980b9', '#27ae60', '#f1c40f', '#e67e22', '#c0392b'];
  A.sharpBar = function (s, h, plus, p1) {
    if (!s || s.length < 14) return '';
    const vals = [];
    for (let i = 0; i < 7; i++) vals.push(parseInt(s.substr(i * 2, 2), 10) || 0);
    let total = vals.reduce((a, b) => a + b, 0);
    // 原程序筛选区的「锋利度 +1 / +2」：匠加成延展最高斩味段，
    // 仅在 DB_Wpn.SharpP1 = 1（该武器可受匠加成）时生效
    if (plus > 0 && p1 === 1) {
      let top = 0;
      while (top < 7 && !vals[top]) top++;
      if (top < 7) { const ex = plus * 10; vals[top] += ex; total += ex; }
    }
    const cap = Math.max(90, total);
    let seg = '';
    for (let i = 6; i >= 0; i--) {
      const v = vals[i];
      if (v > 0) seg += `<i style="width:${(v / cap * 100).toFixed(2)}%;background:${SHARP[i]}"></i>`;
    }
    return `<span class="sharp" style="height:${h || 9}px" title="${total}">${seg}</span>`;
  };
  A.sharpTotal = function (s) {
    if (!s || s.length < 14) return 0;
    let t = 0;
    for (let i = 0; i < 7; i++) t += parseInt(s.substr(i * 2, 2), 10) || 0;
    return t;
  };
  A.res5 = function (arr) {
    const R = ['火', '水', '雷', '冰', '龙'];
    const parts = arr.map((v, i) => v ? `<i class="${v > 0 ? 'res-p' : 'res-n'}">${R[i]}${v > 0 ? '+' : ''}${v}</i>` : '').filter(Boolean);
    return parts.length ? `<span class="res5">${parts.join('')}</span>` : '<span class="dim">—</span>';
  };
  A.slotHtml = function (n) {
    if (!n) return '<span class="dim">—</span>';
    let h = '';
    for (let i = 0; i < n; i++) h += '<b class="dslot"></b>';
    return `<span class="slots">${h}</span>`;
  };
  A.lvNum = name => { const m = /Lv\.(\d+)/.exec(name || ''); return m ? +m[1] : 1; };
  A.stripLv = name => (name || '').replace(/\s*-\s*Lv\.\d+$/, '');

  A.skillLevel = function (treeId, pts) {
    const trees = (A.data.skills && A.data.skills.trees) || [];
    const t = trees.find(x => x[0] === treeId);
    if (!t) return { lv: 0, name: '', max: 0, next: null };
    // levels 里混着负面阈值（如攻击 -20,-15,-10,10,15,20），等级只能按「正值」循序计数
    const pos = t[2].filter(x => x > 0).sort((a, b) => a - b), names = t[3];
    if (pts < 0) return { lv: -1, name: t[1], max: pos.length, next: null };
    if (!pts) return { lv: 0, name: t[1], max: pos.length, next: pos[0] };
    let lv = 0;
    for (let i = 0; i < pos.length; i++) if (pts >= pos[i]) lv = i + 1;
    return { lv: lv, name: names[lv - 1] || t[1], max: pos.length, next: lv < pos.length ? pos[lv] : null };
  };

  /* ---------- 路由 ---------- */
  A.routes = {};
  A.route = (name, def) => { A.routes[name] = def; };
  A.current = null;
  A.params = {};

  A.setTitle = function (title, sub) {
    A.$('#ttl').textContent = title;
    A.$('#sub').textContent = sub || '';
    document.title = title + ' · MHXX 资料库';
  };

  A.searchHandler = null;
  A.setSearch = function (ph, handler, value) {
    const wrap = A.$('#search-wrap'), q = A.$('#q');
    if (!ph) { wrap.hidden = true; A.searchHandler = null; return; }
    wrap.hidden = false;
    q.placeholder = ph;
    q.value = value || '';
    A.searchHandler = handler;
  };

  A.activateNav = function (name) {
    A.$$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.nav === name));
  };

  A.go = function (name, params, push) {
    const q = new URLSearchParams();
    Object.keys(params || {}).forEach(k => { if (params[k] != null && params[k] !== '') q.set(k, params[k]); });
    const hash = '#/' + name + (q.toString() ? '?' + q.toString() : '');
    if (location.hash === hash) { A.render(); return; }
    if (push === false) location.replace(hash); else location.hash = hash;
  };
  A.back = () => { if (history.length > 1) history.back(); else A.go('home', null, false); };

  A.render = async function () {
    const raw = location.hash.replace(/^#\/?/, '') || 'home';
    const [name, qs] = raw.split('?');
    const params = {};
    new URLSearchParams(qs || '').forEach((v, k) => { params[k] = v; });
    const def = A.routes[name] || A.routes.home;
    A.current = A.routes[name] ? name : 'home';
    A.params = params;

    const view = A.$('#view');
    A.$('#btn-back').hidden = (A.current === 'home');
    A.setSearch(null);
    A.activateNav(A.current === 'home' || A.current === 'data' ? A.current : (def.nav || A.current));
    A.setTitle(def.title || '', def.sub || '');

    if (def.load) {
      view.innerHTML = '<div class="loading"><span></span>读取数据…</div>';
      try { await A.load(def.load); } catch (e) {
        view.innerHTML = '<div class="empty">数据加载失败<br><span class="dim">' + A.esc(String(e)) + '</span></div>';
        return;
      }
    }
    view.innerHTML = '';
    const host = document.createElement('div');
    view.appendChild(host);
    window.scrollTo(0, 0);
    def.mount(host, params);
  };

  /* ---------- 表格 ---------- */
  A.table = function (opt) {
    const cols = opt.cols;
    const wrap = document.createElement('div');
    wrap.className = 'tblwrap' + (opt.cls ? ' ' + opt.cls : '');
    let rows = opt.rows || [];
    let shown = 0, sortK = opt.sortK, sortDesc = !!opt.sortDesc;
    const STEP = 80;

    const pct = cols.some(c => c.p);
    wrap.innerHTML = '<table class="tbl' + (pct ? ' fixed' : '') + '"><thead><tr>' +
      cols.map((c, i) => `<th class="a${c.a || 'l'}${c.k != null ? ' sortable' : ''}" data-i="${i}" style="${c.p ? 'width:' + c.p + '%;' : c.w ? 'min-width:' + c.w + 'px;' : ''}${c.style || ''}">${c.t}</th>`).join('') +
      '</tr></thead><tbody></tbody></table><div class="tbl-more"></div>';
    const tbody = A.$('tbody', wrap);
    const more = A.$('.tbl-more', wrap);

    const cellHtml = c => {
      if (c == null) return '<td></td>';
      if (typeof c !== 'object') return `<td>${c}</td>`;
      return `<td class="a${c.a || ''} ${c.cls || ''}" style="${c.style || ''}">${c.html != null ? c.html : A.esc(c.t)}</td>`;
    };
    const rowHtml = (r, i) => `<tr data-i="${i}">${r.map(cellHtml).join('')}</tr>`;

    function append() {
      if (shown >= rows.length) return;
      const to = Math.min(rows.length, shown + STEP);
      let h = '';
      for (let i = shown; i < to; i++) h += rowHtml(rows[i], i);
      tbody.insertAdjacentHTML('beforeend', h);
      shown = to;
      more.textContent = rows.length ? (shown < rows.length ? `下滑查看更多（${shown}/${rows.length}）` : `共 ${rows.length} 条`) : '';
    }
    function sortRows() {
      if (sortK == null) return;
      const val = r => { const c = r[sortK]; return (c && c.v !== undefined) ? c.v : (c && c.t !== undefined ? c.t : c); };
      rows.sort((a, b) => {
        const x = val(a), y = val(b);
        const nx = typeof x === 'number' ? x : parseFloat(x), ny = typeof y === 'number' ? y : parseFloat(y);
        if (!isNaN(nx) && !isNaN(ny)) return sortDesc ? ny - nx : nx - ny;
        return sortDesc ? String(y).localeCompare(String(x), 'zh') : String(x).localeCompare(String(y), 'zh');
      });
    }
    function setRows(list) {
      rows = list;
      sortRows();
      shown = 0; tbody.innerHTML = '';
      if (!rows.length) { more.textContent = opt.empty || '没有结果'; return; }
      append();
    }

    wrap.addEventListener('click', e => {
      const th = e.target.closest('th.sortable');
      if (th) {
        const k = cols[+th.dataset.i].k;
        if (sortK === k) sortDesc = !sortDesc; else { sortK = k; sortDesc = true; }
        A.$$('th', wrap).forEach(x => x.classList.remove('asc', 'desc'));
        th.classList.add(sortDesc ? 'desc' : 'asc');
        sortRows(); shown = 0; tbody.innerHTML = ''; append();
        return;
      }
      const tr = e.target.closest('tbody tr');
      if (tr && opt.onRow) opt.onRow(rows[+tr.dataset.i], +tr.dataset.i);
    });

    A.scroller = function () {
      if (shown >= rows.length) return;
      const r = wrap.getBoundingClientRect();
      if (r.bottom < window.innerHeight + 700) append();
    };

    setRows(rows);
    return { el: wrap, setRows, all: () => rows };
  };

  /* ---------- 控件 ---------- */
  A.chips = function (items, active, onPick, opt) {
    const box = document.createElement('div');
    box.className = 'chips' + (opt && opt.wrap ? ' wrapc' : '');
    box.innerHTML = items.map(([k, t]) =>
      `<button class="chip${String(k) === String(active) ? ' on' : ''}" data-v="${A.esc(k)}">${t}</button>`).join('');
    box.addEventListener('click', e => {
      const b = e.target.closest('.chip'); if (!b) return;
      A.$$('.chip', box).forEach(x => x.classList.remove('on'));
      b.classList.add('on');
      onPick(b.dataset.v);
    });
    return box;
  };

  A.seg = function (items, active, onPick) {
    const box = document.createElement('div');
    box.className = 'seg';
    box.innerHTML = items.map(([k, t]) => `<button class="${k === active ? 'on' : ''}" data-v="${k}">${t}</button>`).join('');
    box.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      A.$$('button', box).forEach(x => x.classList.remove('on'));
      b.classList.add('on'); onPick(b.dataset.v);
    });
    return box;
  };

  A.select = function (items, active, onChange, cls) {
    const s = document.createElement('select');
    s.className = 'sel ' + (cls || '');
    s.innerHTML = items.map(([k, t]) => `<option value="${A.esc(k)}"${String(k) === String(active) ? ' selected' : ''}>${t}</option>`).join('');
    s.addEventListener('change', () => onChange(s.value));
    return s;
  };

  A.row = function () {
    const d = document.createElement('div');
    d.className = 'filters';
    for (let i = 0; i < arguments.length; i++) if (arguments[i]) d.appendChild(arguments[i]);
    return d;
  };

  /* ---------- 弹层 ---------- */
  A.sheet = function (title, html) {
    A.$('#sheet-title').textContent = title;
    const body = A.$('#sheet-body');
    body.innerHTML = '<div id="sheet-live"></div>';
    A.$('#sheet-live').innerHTML = html;
    A.$('#mask').classList.add('on');
    body.scrollTop = 0;
  };
  A.closeSheet = function () { A.$('#mask').classList.remove('on'); };

  A.toast = function (msg) {
    const t = A.$('#toast');
    t.textContent = msg; t.classList.add('on');
    clearTimeout(A._tt); A._tt = setTimeout(() => t.classList.remove('on'), 1600);
  };

  A.stat = (k, v, cls) => `<div class="stat"><div class="k">${k}</div><div class="v ${cls || ''}">${v}</div></div>`;
  A.sec = t => `<div class="section-title">${t}</div>`;
  A.card = (html, cls) => `<div class="card ${cls || ''}">${html}</div>`;

  A.matTable = function (list, label, opt) {
    if (!list || !list.length) return '';
    const M = A.byId('items');
    return A.card(A.sec(label || '素材') +
      `<table class="grid"><tbody>${list.map(([id, q]) => {
        const it = M.get(id) || [id, '未知'];
        return `<tr data-item="${id}"><td class="withico">${A.itemIcon(id, 24)}<span>${A.esc(it[1])}</span></td><td class="num">×${q}</td></tr>`;
      }).join('')}</tbody></table>`, opt && opt.cls);
  };

  A.kv = pairs => `<table class="grid kv"><tbody>${pairs.filter(Boolean).map(([k, v]) =>
    `<tr><td class="k">${k}</td><td class="v">${v}</td></tr>`).join('')}</tbody></table>`;

  /* ---------- 道具详情 ---------- */
  A.itemSheet = function (id) {
    const M = A.byId('items');
    const it = M.get(+id);
    if (!it) { A.toast('找不到该道具'); return; }
    A.load(['item_src', 'combo', 'hfh', 'item_use', 'weapons', 'armor', 'jewels']).then(() => {
      const src = A.data.item_src[String(id)] || {};
      const MO = A.byId('monsters');
      const L = A.data.labels || {};
      let h = `<div class="detail-head"><div class="pic sq">${A.itemIcon(id, 64)}</div>
        <div class="grow"><h2>${A.esc(it[1])}</h2>
        <div class="meta"><span>稀有度 ${it[2]}</span><span>携带上限 ${it[3]}</span></div>
        <div class="meta"><span>卖价 ${A.fmt(it[4])} z</span><span>买价 ${A.fmt(it[5])} z</span></div></div></div>`;

      if (src.c && src.c.length) {
        const C = A.data.combo.filter(c => src.c.indexOf(c[0]) >= 0);
        h += A.card(A.sec('调和') + `<table class="grid"><tbody>${C.map(c =>
          `<tr><td class="withico">${A.itemIcon(c[2], 22)}<span>${A.esc((M.get(c[2]) || [0, '?'])[1])}</span><span class="dim"> + </span>${A.itemIcon(c[3], 22)}<span>${A.esc((M.get(c[3]) || [0, '?'])[1])}</span></td><td class="num">${c[4]}%</td></tr>`).join('')}</tbody></table>`);
      }
      if (src.m && src.m.length) {
        const g = {};
        src.m.forEach(x => { (g[x[0]] = g[x[0]] || []).push(x); });
        h += A.card(A.sec('怪物素材') + Object.keys(g).map(mid => {
          const mon = MO.get(+mid);
          return `<div class="sub-h">${A.esc(mon ? mon[1] : '#' + mid)}</div><table class="grid"><tbody>${g[mid].map(x =>
            `<tr><td>${['下位', '上位', 'G级'][x[1] - 1] || 'R' + x[1]}</td><td class="dim">${['—', '剥取', '捕获', '掉落', '部位破坏'][x[2]] || ''}</td><td class="num">${x[3]}%</td></tr>`).join('')}</tbody></table>`;
        }).join(''));
      }
      if (src.l && src.l.length) {
        const seen = {};
        const rows = src.l.filter(x => { const k = x[0] + '-' + x[2]; if (seen[k]) return false; seen[k] = 1; return true; }).slice(0, 24);
        h += A.card(A.sec('地图采集') + `<table class="grid"><tbody>${rows.map(x =>
          `<tr><td>${A.esc((L.loc || {})[x[0]] || x[0])}</td><td>${x[1] > 0 ? x[1] + '区' : '—'}</td><td class="dim">${['下位', '上位', 'G级'][x[2] - 1] || ''}</td></tr>`).join('')}</tbody></table>`);
      }
      if (src.v && src.v.length) {
        h += A.card(A.sec('山菜爷爷交换') + `<table class="grid"><tbody>${src.v.map(x =>
          `<tr><td class="withico">${A.itemIcon(x[0], 22)}<span>${A.esc((M.get(x[0]) || [0, '?'])[1])}</span></td><td class="num">${x[1]}%</td></tr>`).join('')}</tbody></table>`);
      }
      if (src.h && src.h.length) {
        const H = A.byId('hfh');
        h += A.card(A.sec('游荡猎人委托') + `<table class="grid"><tbody>${src.h.slice(0, 20).map(x => {
          const q = H.get(x[0]) || [0, '委托'];
          return `<tr><td>${A.esc(q[1])}</td><td class="dim">${({ A: '地图', B: '成功', C: '大成功' })[x[1]] || x[1]}</td><td class="num">${x[2]}%</td></tr>`;
        }).join('')}</tbody></table>`);
      }
      if (src.p && src.p.length) {
        h += A.card(A.sec('猛喵队') + `<table class="grid"><tbody>${src.p.map(x =>
          `<tr><td>${A.esc((L.peliZone || {})[x[0]] || '—')}</td><td class="dim">${['下位', '上位', 'G级'][x[1] - 1] || ''}</td><td class="num">${x[2]}%</td></tr>`).join('')}</tbody></table>`);
      }
      if (src.a && src.a.length) {
        h += A.card(A.sec('斗技大会') + `<table class="grid"><tbody>${src.a.map(x =>
          `<tr><td>斗技大会 #${x[0]}</td><td class="num">${x[1]}%</td></tr>`).join('')}</tbody></table>`);
      }
      if (src.q && src.q.length) {
        const Q = A.byId('quests');
        h += A.card(A.sec('任务报酬') + `<table class="grid"><tbody>${src.q.slice(0, 24).map(qid => {
          const q = Q.get(qid);
          return `<tr data-qst="${qid}"><td>${A.esc(q ? q[1] : '#' + qid)}</td><td class="num dim">${q ? q[2] : ''}</td></tr>`;
        }).join('')}</tbody></table>` + (src.q.length > 24 ? `<div class="dim pad">共 ${src.q.length} 个任务</div>` : ''));
      }

      /* 原程序道具窗体「用处」分组：该素材能造哪些武器 / 防具 / 装饰珠 */
      const USE = A.data.item_use[String(id)] || {};
      const nameOf = {
        w: k => { const x = A.byId('weapons').get(+k); return x ? x[2] : '#' + k; },
        a: k => { const x = A.byId('armor').get(+k); return x ? x[2] : '#' + k; },
        j: k => { const x = A.byId('jewels').get(+k); return x ? x[1] : '#' + k; }
      };
      [['w', '武器'], ['a', '防具'], ['j', '装饰珠']].forEach(([kind, label]) => {
        const list = USE[kind] || [];
        if (!list.length) return;
        h += A.card(A.sec('用处 · ' + label + `（${list.length}）`) +
          `<table class="grid"><tbody>${list.slice(0, 25).map(x => {
            const oid = String(x[0]).slice(1);
            return `<tr data-use="${kind}${oid}"><td>${A.esc(nameOf[kind](oid))}</td><td class="num dim">×${x[1]}</td></tr>`;
          }).join('')}</tbody></table>` + (list.length > 25 ? `<div class="dim pad">共 ${list.length} 件</div>` : ''));
      });
      A.sheet(it[1], h);
      A.$('#sheet-live').addEventListener('click', e => {
        const u = e.target.closest('[data-use]');
        if (!u) return;
        const kind = u.dataset.use[0], oid = +u.dataset.use.slice(1);
        if (kind === 'w' && A.weaponSheet) A.weaponSheet(A.byId('weapons').get(oid));
        if (kind === 'a' && A.armorSheet) A.armorSheet(A.byId('armor').get(oid));
        if (kind === 'j' && A.jewelSheet) A.jewelSheet(A.byId('jewels').get(oid));
      });
    });
  };

  window.addEventListener('scroll', () => { if (A.scroller) A.scroller(); }, { passive: true });
})();
