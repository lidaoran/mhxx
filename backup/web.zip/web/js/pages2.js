/* 页面：任务 / 怪物 / 地图 / 勋章 / 笛旋律 / 弩弹药 / 猎虫 / 随从 / 交易 / 斗技 / 关于 */
(function () {
  const A = window.A;
  const RANK = ['下位', '上位', 'G级'];
  // monsters.json 的属性数组顺序：火 水 冰 雷 龙（与 DB_Mon_Weak 导出顺序一致）
  const RESN = ['火', '水', '冰', '雷', '龙'];
  const GET = ['—', '剥取', '捕获', '掉落', '部位破坏', '?'];
  const TRAP = { 1: '落穴陷阱', 2: '麻痹陷阱', 3: '闪光弹', 4: '音爆弹', 5: '肉' };

  /* ================= 任务 ================= */
  A.route('quests', {
    title: '任务', sub: '', load: ['quests', 'quest_rewards', 'labels', 'monsters', 'maps', 'mon_drops', 'items', 'item_icons'],
    mount(view, params) {
      const Q = A.data.quests, L = A.data.labels;
      let lv = '0', type = '0', loc = '0', mon = '0', keyword = '';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);

      const lvItems = [['0', '全部等级']].concat(Object.keys(L.qstLv).filter(k => +k > 0).map(k => [k, L.qstLv[k]]));
      const typeItems = [['0', '全部类型']].concat(Object.keys(L.qstType).map(k => [k, L.qstType[k]]));
      const locItems = [['0', '全部地图']].concat(Object.keys(L.loc).filter(k => +k > 0).map(k => [k, L.loc[k]]));
      const monItems = [['0', '全部怪物']].concat(A.data.monsters.map(m => [String(m[0]), m[1]]));
      head.appendChild(A.row(A.select(lvItems, lv, v => { lv = v; paint(); }), A.select(typeItems, type, v => { type = v; paint(); })));
      head.appendChild(A.row(A.select(locItems, loc, v => { loc = v; paint(); }), A.select(monItems, mon, v => { mon = v; paint(); })));
      /* 原程序 _CheckBox_Key「关键？」 */
      let keyOnly = false;
      const kl = document.createElement('label');
      kl.className = 'togglerow';
      kl.innerHTML = '<input type="checkbox" id="q-key"> 仅显示关键任务';
      kl.querySelector('input').addEventListener('change', e => { keyOnly = e.target.checked; paint(); });
      head.appendChild(kl);
      A.setSearch('搜索任务名…', v => { keyword = v.trim(); paint(); });

      function filtered() {
        return Q.filter(q => (!+lv || q[2] === L.qstLv[+lv]) && (!+type || q[3] === L.qstType[+type])
          && (!+loc || q[5] === L.loc[+loc]) && (!+mon || q[7].indexOf(+mon) >= 0)
          && (!keyOnly || !!q[4]) && (!keyword || q[1].indexOf(keyword) >= 0));
      }
      function paint() {
        const list = filtered();
        A.setTitle('任务', `${list.length.toLocaleString()} / ${Q.length.toLocaleString()}`);
        body.innerHTML = '';
        const rows = list.map(q => [
          { html: `<span class="cellname">${A.esc(q[1])}</span>`, v: q[1] },
          { t: q[2], cls: 'dim', v: q[2] },
          { t: q[3], v: q[3] },
          { html: q[7].slice(0, 4).map(m => `<img class="mi" src="${A.monImg(m)}" alt="">`).join(''), v: q[7].length },
          { t: A.fmt(q[10]), a: 'r', v: q[10] }
        ]);
        const t = A.table({
          cols: [{ t: '任务', k: 0, p: 38 }, { t: '等级', k: 1, p: 22 }, { t: '类型', k: 2, p: 12 },
          { t: '怪物', k: 3, p: 15 }, { t: '报酬金', a: 'r', k: 4, p: 13 }],
          rows, onRow: r => questSheet(r.__q)
        });
        rows.forEach((r, i) => { r.__q = list[i]; });
        body.appendChild(t.el);
      }
      paint();
      if (params.id) questSheet(A.byId('quests').get(+params.id));
    }
  });

  function questSheet(q) {
    if (!q) return;
    const RW = A.data.quest_rewards[String(q[0])] || {};
    const M = A.byId('items'), MO = A.byId('monsters');
    const nm = id => A.esc((M.get(id) || [0, '?'])[1]);
    const label = { A: 'A · 主要目标报酬第一行', B: 'B · 主要目标报酬第二行', C: 'C · 次要目标报酬', D: 'D · 其他报酬' };
    let h = `<div class="detail-head"><div class="grow"><h2>${A.esc(q[1])}</h2>
      <div class="meta"><span>${q[2]}</span><span>${q[3]}</span><span>${q[5]}</span>${q[4] ? `<span class="tag on">${A.esc(q[4])}</span>` : ''}</div></div></div>`;
    h += `<div class="stat-grid">${A.stat('报酬金', A.fmt(q[10]))}${A.stat('契约金', A.fmt(q[8]))}${A.stat('时间', q[9] ? q[9] + ' 分' : '—')}</div>`;
    h += A.card(A.sec('目标') + `<div class="pad text">${A.esc(q[6] || '—')}${q[12] ? '<br><span class="dim">次要：' + A.esc(q[12]) + '</span>' : ''}</div>`);
    if (q[7].length) {
      h += A.card(A.sec('出现怪物') + `<div class="monrow">${q[7].map(m => {
        const mo = MO.get(m);
        return `<div class="monchip"><img src="${A.monImg(m)}" alt=""><span>${A.esc(mo ? mo[1] : m)}</span></div>`;
      }).join('')}</div>`);
    }
    ['A', 'B', 'C', 'D'].forEach(k => {
      const list = RW[k] || [];
      if (!list.length) return;
      h += A.card(A.sec(`${label[k]}（${list.length}）`) + `<table class="grid"><tbody>${list.map(([id, qty, pct]) =>
        `<tr data-item="${id}"><td class="withico">${A.itemIcon(id, 22)}<span>${nm(id)}</span></td><td class="num dim">×${qty}</td><td class="num">${pct}%</td></tr>`).join('')}</tbody></table>`);
    });
    A.sheet(q[1], h);
    A.$('#sheet-live').addEventListener('click', e => {
      const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
    });
  }

  /* ================= 怪物 ================= */
  A.route('monsters', {
    title: '怪物', sub: '', load: ['monsters', 'mon_drops', 'items', 'item_icons', 'labels'],
    mount(view, params) {
      const MO = A.data.monsters;
      let keyword = '';
      const body = document.createElement('div');
      view.appendChild(body);
      A.setSearch('搜索怪物…', v => { keyword = v.trim(); paint(); });
      function paint() {
        const list = MO.filter(m => !keyword || m[1].indexOf(keyword) >= 0);
        A.setTitle('怪物', `${list.length} / ${MO.length}`);
        body.innerHTML = '';
        const rows = list.map(m => [
          { html: `<span class="nm ico-row"><img class="mi lg" src="${A.monImg(m[0])}" alt=""><span>${A.esc(m[1])}</span></span>`, v: m[1] },
          { t: m[2].length, a: 'r', v: m[2].length },
          { t: m[3].length || '—', a: 'r', v: m[3].length },
          { t: m[4].length || '—', a: 'r', v: m[4].length }
        ]);
        const t = A.table({
          cols: [{ t: '怪物', k: 0, w: 190 }, { t: '部位', a: 'r', k: 1, w: 48 }, { t: '异常', a: 'r', k: 2, w: 48 }, { t: '陷阱', a: 'r', k: 3, w: 48 }],
          rows, onRow: r => monSheet(r.__m[0])
        });
        rows.forEach((r, i) => { r.__m = list[i]; });
        body.appendChild(t.el);
      }
      paint();
      if (params.id) monSheet(+params.id);
    }
  });

  function monSheet(id) {
    const m = A.data.monsters.find(x => x[0] === id);
    if (!m) return;
    const drops = A.data.mon_drops[String(id)] || {};
    const M = A.byId('items');
    const nm = i => A.esc((M.get(i) || [0, '?'])[1]);
    let h = `<div class="detail-head"><div class="pic mo"><img src="${A.monImg(id)}" alt=""></div>
      <div class="grow"><h2>${A.esc(m[1])}</h2><div class="meta"><span>部位 ${m[2].length}</span><span>异常 ${m[3].length}</span></div></div></div>`;

    h += '<div class="seg-tabs" data-tabs="mon"><button class="on" data-t="meat">肉质</button><button data-t="drop">道具</button><button data-t="ail">异常</button><button data-t="trap">陷阱</button></div>';
    h += '<div id="mo-meat">';
    if (m[2].length) {
      h += `<div class="scrollx"><table class="grid meat"><thead><tr><th>部位</th><th>切</th><th>打</th><th>弹</th>
        ${RESN.map(r => `<th>${r}</th>`).join('')}<th>气绝</th></tr></thead><tbody>${m[2].map(p =>
          `<tr><td>${A.esc(p[1] || '部位' + p[0])}</td><td>${p[2] || '—'}</td><td>${p[3] || '—'}</td><td>${p[4] || '—'}</td>
          ${p[5].map(v => `<td class="${v >= 45 ? 'res-hi' : v > 0 ? 'res-p' : 'dim'}">${v || '—'}</td>`).join('')}
          <td>${p[6] || '—'}</td></tr>`).join('')}</tbody></table></div>`;
    } else h += '<div class="empty">暂无肉质数据</div>';
    h += '</div>';

    h += '<div id="mo-drop" hidden>';
    const ranks = Object.keys(drops).sort((a, b) => a - b);
    if (ranks.length) {
      h += '<div class="seg-tabs small" data-tabs="rank">' + ranks.map((r, i) =>
        `<button class="${i === 0 ? 'on' : ''}" data-r="${r}">${RANK[r - 1] || 'R' + r}</button>`).join('') + '</div>';
      ranks.forEach((r, i) => {
        const list = drops[r].slice().sort((a, b) => b[2] - a[2]);
        h += `<div class="rankbox" data-rank="${r}" ${i ? 'hidden' : ''}><table class="grid"><tbody>${list.map(x =>
          `<tr data-item="${x[0]}"><td class="withico">${A.itemIcon(x[0], 22)}<span>${nm(x[0])}</span></td>
           <td class="num dim">×${x[1]}</td><td class="num">${x[2]}%</td><td class="dim">${GET[x[3]] || ''}</td></tr>`).join('')}</tbody></table></div>`;
      });
    } else h += '<div class="empty">暂无掉落数据</div>';
    h += '</div>';

    h += '<div id="mo-ail" hidden>' + (m[3].length ?
      `<table class="grid"><thead><tr><th>异常</th><th>初始</th><th>增量</th><th>上限</th><th>持续</th><th>伤害</th></tr></thead><tbody>${m[3].map(a =>
        `<tr><td>${['—', '毒', '麻痹', '睡眠', '气绝', '爆破', '减气', '骑乘', '?', '?', '?', '?'][a[0]] || '异常' + a[0]}</td>
        <td class="num">${a[1]}</td><td class="num">${a[2]}</td><td class="num">${a[3]}</td><td class="num">${a[4] || '—'}</td><td class="num">${a[5] || '—'}</td></tr>`).join('')}</tbody></table>`
      : '<div class="empty">暂无数据</div>') + '</div>';

    h += '<div id="mo-trap" hidden>' + (m[4].length ?
      `<table class="grid"><thead><tr><th>陷阱</th><th>有效</th><th>持续</th><th>愤怒</th><th>疲劳</th></tr></thead><tbody>${m[4].map(t =>
        `<tr><td>${TRAP[t[0]] || '陷阱' + t[0]}</td><td class="${t[1] > 0 ? 'res-p' : 'res-n'}">${t[1] > 0 ? '有效' : '无效'}</td>
        <td class="num">${t[2] || '—'}</td><td class="num">${t[3] || '—'}</td><td class="num">${t[4] || '—'}</td></tr>`).join('')}</tbody></table>`
      : '<div class="empty">暂无数据</div>') + '</div>';

    A.sheet(m[1], h);
    const sb = A.$('#sheet-live');
    sb.addEventListener('click', e => {
      const tab = e.target.closest('[data-tabs="mon"] button');
      if (tab) {
        A.$$('[data-tabs="mon"] button', sb).forEach(b => b.classList.remove('on'));
        tab.classList.add('on');
        ['meat', 'drop', 'ail', 'trap'].forEach(k => { A.$('#mo-' + k, sb).hidden = (k !== tab.dataset.t); });
        return;
      }
      const rt = e.target.closest('[data-tabs="rank"] button');
      if (rt) {
        A.$$('[data-tabs="rank"] button', sb).forEach(b => b.classList.remove('on'));
        rt.classList.add('on');
        A.$$('.rankbox', sb).forEach(b => { b.hidden = b.dataset.rank !== rt.dataset.r; });
        return;
      }
      const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
    });
  }

  /* ================= 地图 ================= */
  A.route('maps', {
    title: '地图', sub: '', load: ['maps', 'labels', 'items', 'item_icons'],
    mount(view) {
      const D = A.data.maps;
      let loc = String(D.locs[0] ? D.locs[0][0] : 1), rank = '1';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      head.appendChild(A.chips(D.locs.map(([id, n]) => [String(id), n]), loc, v => { loc = v; paint(); }, { wrap: true }));
      head.appendChild(A.row(A.seg([['1', '下位'], ['2', '上位'], ['3', 'G级']], rank, v => { rank = v; paint(); })));
      const M = A.byId('items');
      function paint() {
        const ld = (D.data[loc] || {})[rank] || [];
        A.setTitle('地图', (D.locs.find(x => String(x[0]) === loc) || [0, ''])[1]);
        body.innerHTML = '';
        if (!ld.length) { body.innerHTML = '<div class="empty">该难度暂无采集数据</div>'; return; }
        ld.forEach(([ara, items]) => {
          const t = document.createElement('div');
          t.className = 'card';
          t.innerHTML = `<div class="ara-h">${ara > 0 ? ara + ' 区' : '营地/秘境'}<span class="dim">${items.length} 种</span></div>
            <table class="grid"><tbody>${items.map(([id, gt]) =>
              `<tr data-item="${id}"><td class="withico">${A.itemIcon(id, 22)}<span>${A.esc((M.get(id) || [0, '?'])[1])}</span></td>
              <td class="dim">${['—', '采集', '钓鱼', '矿脉', '虫捕', '?'][gt] || '采集'}</td></tr>`).join('')}</tbody></table>`;
          body.appendChild(t);
        });
      }
      // 绑在 body 上，只能绑一次；放 paint 里会随难度切换不断叠加
      body.addEventListener('click', e => {
        const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
      });
      paint();
    }
  });

  /* ================= 勋章 ================= */
  A.route('medals', {
    title: '勋章', sub: '', load: ['medals'],
    mount(view) {
      const MD = A.data.medals;
      view.innerHTML = `<div class="medal-grid">${MD.map(m =>
        `<button data-m="${m[0]}"><img loading="lazy" src="img/i/Awd_${String(m[0]).padStart(3, '0')}.png" alt=""><span>${A.esc(m[1])}</span></button>`).join('')}</div>`;
      view.addEventListener('click', e => {
        const b = e.target.closest('[data-m]'); if (!b) return;
        const m = MD.find(x => x[0] === +b.dataset.m);
        A.sheet(m[1], `<div class="detail-head"><div class="pic sq"><img src="img/i/Awd_${String(m[0]).padStart(3, '0')}.png" style="width:64px;height:64px;image-rendering:auto"></div>
          <div class="grow"><h2>${A.esc(m[1])}</h2></div></div>
          <div class="card pad text">${A.esc(m[2] || '暂无说明')}</div>`);
      });
    }
  });

  /* ================= 笛旋律 ================= */
  A.route('hh', {
    title: '笛旋律', sub: '', load: ['hhsongs', 'labels', 'weapons'],
    mount(view) {
      const S = A.data.hhsongs, L = A.data.labels;
      let cat = '0';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      const cats = [['0', '全部']].concat(Object.keys(L.songCat).map(k => [k, L.songCat[k]]));
      head.appendChild(A.chips(cats, cat, v => { cat = v; paint(); }));
      const notes = n => n > 0 ? `<i class="note n${n}"></i>` : '';
      function paint() {
        const list = S.filter(s => !+cat || s[10] === L.songCat[+cat] || s[9] === L.songCat[+cat]);
        A.setTitle('笛旋律', `${list.length} / ${S.length}`);
        body.innerHTML = '';
        const rows = list.map(s => [
          { html: s[2].filter(n => n > 0).map(notes).join(''), v: s[2].filter(n => n > 0).length },
          { html: `<span class="nm">${A.esc(s[3] || '—')}</span>`, v: s[3] },
          { t: s[4] || '—', a: 'c', v: s[4] },
          { t: s[5] || '—', a: 'c', v: s[5] },
          { html: `<span class="dim">${A.esc(s[6] || '—')}</span>`, v: s[6] },
          { t: s[7] || '—', a: 'c', v: s[7] },
          { t: s[8] || '—', a: 'c', v: s[8] }
        ]);
        body.appendChild(A.table({
          cols: [{ t: '音色', a: 'c', k: 0, w: 62 }, { t: '旋律效果', k: 1, w: 150 }, { t: '持', a: 'c', k: 2, w: 40 },
          { t: '吹', a: 'c', k: 3, w: 40 }, { t: '重奏效果', k: 4, w: 150 }, { t: '持', a: 'c', k: 5, w: 40 }, { t: '吹', a: 'c', k: 6, w: 40 }],
          rows
        }).el);
      }
      paint();
    }
  });

  /* ================= 弩弹药 ================= */
  A.route('bowgun', {
    title: '弩弹药', sub: '', load: ['bowgun', 'weapons', 'labels'],
    mount(view, params) {
      const B = A.data.bowgun, W = A.byId('weapons');
      let ammo = '-1', onlyMax = '0';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      head.appendChild(A.chips([['-1', '全部弹种']].concat(B.ammo.map((a, i) => [String(i), a])), ammo, v => { ammo = v; paint(); }, { wrap: true }));
      head.appendChild(A.row(A.select([['0', '全部武器'], ['1', '通常/贯穿 Lv3'], ['2', '含速射']], onlyMax, v => { onlyMax = v; paint(); })));
      function paint() {
        let rows = B.rows.map(r => [r[0], r.slice(1)]);
        if (ammo !== '-1') rows = rows.filter(([, a]) => a[+ammo].some(q => q > 0));
        if (onlyMax === '1') rows = rows.filter(([, a]) => a[+ammo] && a[+ammo][2] > 0);
        A.setTitle('弩弹药', `${rows.length} 把`);
        body.innerHTML = '';
        const cols = [{ t: '武器', k: 0, w: 150 }].concat(B.ammo.map((a, i) => ({ t: a.replace('弹', ''), a: 'c', w: 30 })));
        const data = rows.slice(0, 400).map(([wid, a]) => {
          const w = W.get(wid);
          return [{ html: `<span class="nm">${A.esc(w ? w[2] : wid)}</span>`, v: w ? w[2] : '' }]
            .concat(a.map((q, i) => ({ html: q[2] ? '<b class="lv3">3</b>' : q[1] ? '<b class="lv2">2</b>' : q[0] ? '<b class="lv1">1</b>' : '<span class="dim">·</span>', a: 'c', v: q[2] ? 3 : q[1] ? 2 : q[0] ? 1 : 0 })));
        });
        const t = A.table({ cols, rows: data, onRow: r => weaponSheetById(r.__w) });
        data.forEach((r, i) => { r.__w = rows[i][0]; });
        body.appendChild(t.el);
        if (rows.length > 400) body.insertAdjacentHTML('beforeend', '<div class="dim pad center">仅显示前 400 把，请用弹种筛选</div>');
      }
      paint();
    }
  });
  function weaponSheetById(id) { A.closeSheet(); A.weaponSheet(A.byId('weapons').get(id)); }

  /* ================= 猎虫 ================= */
  A.route('kinsect', {
    title: '猎虫', sub: '', load: ['kinsects', 'labels', 'items', 'item_icons'],
    mount(view) {
      const K = A.data.kinsects;
      const body = document.createElement('div');
      view.appendChild(body);
      const M = A.byId('items');
      body.innerHTML = `<div class="tree">${K.map(k =>
        `<div class="tnode" data-k="${k[0]}"><span class="tw">${A.esc(k[1])}<em>${((A.data.labels.kinsectType || {})[k[2] - 30] || '—')}</em></span>
         <span class="tr dim">R${k[3]}</span></div>`).join('')}</div>`;
      A.setTitle('猎虫', `${K.length} 只`);
      body.addEventListener('click', e => {
        const n = e.target.closest('[data-k]'); if (!n) return;
        const k = K.find(x => x[0] === +n.dataset.k);
        let h = `<div class="detail-head"><div class="pic w"><img src="img/k/${k[4]}.webp" alt="" onerror="this.style.display='none'"></div>
          <div class="grow"><h2>${A.esc(k[1])}</h2><div class="meta"><span>${((A.data.labels.kinsectType || {})[k[2] - 30] || '—')}</span><span>稀有度 ${k[3]}</span></div></div></div>`;
        if (k[6].length) h += A.matTable(k[6], '强化素材');
        h += A.card(A.sec('虫技能') + (k[5].length ? `<div class="pad text">${k[5].map(A.esc).join('<br>')}</div>` : '<div class="pad dim">—</div>'));
        if (k[7] && k[7].length) h += A.card(A.sec('精华技能') + `<div class="pad text">${k[7].map(A.esc).join('<br>')}</div>`);
        A.sheet(k[1], h);
        A.$('#sheet-live').addEventListener('click', e => {
          const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
        });
      });
    }
  });

  /* ================= 随从武器 ================= */
  A.route('peli-w', {
    title: '随从武器', sub: '', load: ['peli_weapons', 'labels'],
    mount(view) {
      const P = A.data.peli_weapons;
      let keyword = '';
      const body = document.createElement('div');
      view.appendChild(body);
      A.setSearch('搜索随从武器…', v => { keyword = v.trim(); paint(); });
      function paint() {
        const list = P.filter(p => !keyword || p[2].indexOf(keyword) >= 0);
        A.setTitle('随从武器', `${list.length} / ${P.length}`);
        body.innerHTML = '';
        const rows = list.map(p => [
          { html: `<span class="nm">${A.esc(p[2] || '随从武器')}</span>`, v: p[2] },
          { t: p[3], a: 'c', v: p[3] },
          { t: p[5], a: 'r', v: p[5] },
          { t: (p[6] > 0 ? '+' : '') + Math.round(p[6] * 100) + '%', a: 'r', v: p[6] },
          { t: p[8], a: 'r', v: p[8] },
          { t: p[11] || '—', a: 'r', v: p[11] },
          { t: A.fmt(p[12]), a: 'r', v: p[12] }
        ]);
        const t = A.table({
          cols: [{ t: '随从武器', k: 0, p: 32 }, { t: '稀', a: 'c', k: 1, p: 8 }, { t: '近身', a: 'r', k: 2, p: 12 },
          { t: '会心', a: 'r', k: 3, p: 12 }, { t: '远程', a: 'r', k: 4, p: 12 }, { t: '防', a: 'r', k: 5, p: 9 },
          { t: '生产价', a: 'r', k: 6, p: 15 }],
          rows, onRow: r => {
            const p = r.__p;
            A.sheet(p[2] || '随从武器', `<div class="detail-head"><div class="pic w"><img src="img/pw/${p[4]}.webp" alt="" onerror="this.style.display='none'"></div>
              <div class="grow"><h2>${A.esc(p[2] || '随从武器')}</h2><div class="meta"><span>${p[2] ? '' : '类型 ' + p[2]}</span><span>稀有度 ${p[3]}</span></div></div></div>
              ${A.kv([['近身攻击', p[5] + ' / 会心 ' + Math.round(p[6] * 100) + '% / 属性 ' + p[7]], ['远程攻击', p[8] + ' / 会心 ' + Math.round(p[9] * 100) + '% / 属性 ' + p[10]], ['防御', p[11]], ['生产价', A.fmt(p[12]) + ' z']])}`);
          }
        });
        rows.forEach((r, i) => { r.__p = list[i]; });
        body.appendChild(t.el);
      }
      paint();
    }
  });

  /* ================= 随从防具 ================= */
  A.route('peli-a', {
    title: '随从防具', sub: '', load: ['peli_armor'],
    mount(view) {
      const P = A.data.peli_armor;
      let keyword = '';
      const body = document.createElement('div');
      view.appendChild(body);
      A.setSearch('搜索随从防具…', v => { keyword = v.trim(); paint(); });
      function paint() {
        const list = P.filter(p => !keyword || p[2].indexOf(keyword) >= 0);
        A.setTitle('随从防具', `${list.length} / ${P.length}`);
        body.innerHTML = '';
        const rows = list.map(p => [
          { html: `<span class="nm">${A.esc(p[2])}</span>`, v: p[2] },
          { t: ['—', '头', '身', '腕', '腰', '脚'][p[1]] || p[1], a: 'c', v: p[1] },
          { t: p[3], a: 'c', v: p[3] },
          { t: p[4], a: 'r', v: p[4] },
          { html: A.res5(p[5]), v: 0 }
        ]);
        body.appendChild(A.table({
          cols: [{ t: '随从防具', k: 0, p: 40 }, { t: '部位', a: 'c', k: 1, p: 12 }, { t: '稀', a: 'c', k: 2, p: 8 },
          { t: '防御', a: 'r', k: 3, p: 12 }, { t: '耐性', k: 4, p: 28 }],
          rows
        }).el);
      }
      paint();
    }
  });

  /* ================= 猛喵队 ================= */
  A.route('pt', {
    title: '猛喵队', sub: '', load: ['peliteam', 'labels', 'items', 'item_icons'],
    mount(view) {
      const D = A.data.peliteam, L = A.data.labels;
      let zone = String(D.zones[0] ? D.zones[0][0] : 1), rank = '1';
      const head = document.createElement('div'), body = document.createElement('div');
      view.appendChild(head); view.appendChild(body);
      head.appendChild(A.chips(D.zones.map(([id, n]) => [String(id), n]), zone, v => { zone = v; paint(); }, { wrap: true }));
      head.appendChild(A.row(A.seg([['1', '下位'], ['2', '上位'], ['3', 'G级']], rank, v => { rank = v; paint(); })));
      const M = A.byId('items');
      function paint() {
        const list = ((D.data[zone] || {})[rank] || []).slice().sort((a, b) => b[2] - a[2]);
        A.setTitle('猛喵队', (D.zones.find(z => String(z[0]) === zone) || [0, ''])[1]);
        body.innerHTML = '';
        const rows = list.map(x => [
          { html: `<span class="nm ico-row">${A.itemIcon(x[0], 26)}<span>${A.esc((M.get(x[0]) || [0, '?'])[1])}</span></span>`, v: (M.get(x[0]) || [0, '?'])[1] },
          { t: x[1], a: 'r', v: x[1] },
          { t: x[2] + '%', a: 'r', v: x[2] }
        ]);
        const t = A.table({ cols: [{ t: '道具', k: 0, w: 200 }, { t: '数量', a: 'r', k: 1, w: 50 }, { t: '概率', a: 'r', k: 2, w: 60 }], rows, empty: '暂无数据', onRow: r => A.itemSheet(r.__i[0]) });
        rows.forEach((r, i) => { r.__i = list[i]; });
        body.appendChild(t.el);
      }
      paint();
    }
  });

  /* ================= 游荡猎人 ================= */
  A.route('hfh', {
    title: '游荡猎人', sub: '', load: ['hfh', 'labels', 'items', 'item_icons', 'monsters'],
    mount(view) {
      const H = A.data.hfh;
      A.setTitle('游荡猎人', `${H.length} 个委托`);
      const rows = H.map(h => [
        { html: `<span class="nm">${A.esc(h[1])}</span>`, v: h[1] },
        { t: h[2], cls: 'dim', v: h[2] },
        { t: h[3], v: h[3] },
        { t: h[4] + '%', a: 'r', v: h[4] },
        { t: h[5] + '%', a: 'r', v: h[5] },
        { t: h[6], a: 'r', v: h[6] }
      ]);
      const t = A.table({
        cols: [{ t: '委托', k: 0, p: 32 }, { t: '等级', k: 1, p: 22 }, { t: '地图', k: 2, p: 16 },
        { t: '成功', a: 'r', k: 3, p: 10 }, { t: '大成功', a: 'r', k: 4, p: 10 }, { t: '受理费', a: 'r', k: 5, p: 10 }],
        rows, onRow: r => {
          const h = r.__h, M = A.byId('items');
          const g = { A: [], B: [], C: [] };
          h[9].forEach(x => { (g[x[3]] = g[x[3]] || []).push(x); });
          const label = { A: '地图报酬', B: '成功报酬', C: '大成功报酬' };
          let html = `<div class="detail-head"><div class="grow"><h2>${A.esc(h[1])}</h2>
            <div class="meta"><span>${h[2]}</span><span>${h[3]}</span><span>成功 ${h[4]}%</span><span>大成功 ${h[5]}%</span></div>
            <div class="meta"><span>受理费 ${h[6]} z</span><span>追加 ${h[7]} z</span></div></div></div>`;
          ['A', 'B', 'C'].forEach(k => {
            if (!g[k] || !g[k].length) return;
            html += A.card(A.sec(`${label[k]}（${g[k].length}）`) + `<table class="grid"><tbody>${g[k].map(x =>
              `<tr data-item="${x[0]}"><td class="withico">${A.itemIcon(x[0], 22)}<span>${A.esc((M.get(x[0]) || [0, '?'])[1])}</span></td>
               <td class="num dim">×${x[1]}</td><td class="num">${x[2]}%</td></tr>`).join('')}</tbody></table>`);
          });
          A.sheet(h[1], html);
          A.$('#sheet-live').addEventListener('click', e => {
            const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
          });
        }
      });
      rows.forEach((r, i) => { r.__h = H[i]; });
      view.appendChild(t.el);
    }
  });

  /* ================= 山菜爷爷 ================= */
  A.route('veggie', {
    title: '山菜爷爷', sub: '', load: ['veggie', 'items', 'item_icons', 'labels'],
    mount(view) {
      const V = A.data.veggie, M = A.byId('items'), L = A.data.labels;
      const nm = id => A.esc((M.get(id) || [0, '?'])[1]);
      A.setTitle('山菜爷爷', `${V.length} 条交换`);
      const rows = V.map(v => [
        { html: `<span class="nm ico-row">${A.itemIcon(v[0], 26)}<span>${nm(v[0])}</span></span>`, v: nm(v[0]) },
        { html: `<span class="ico-row">${A.itemIcon(v[1], 24)}<span>${nm(v[1])}</span></span>`, v: nm(v[1]) },
        { t: v[2] + '%', a: 'r', v: v[2] },
        { t: v[3] > 0 ? (L.loc[v[3]] || '') : '—', v: v[3] }
      ]);
      view.appendChild(A.table({
        cols: [{ t: '交出', k: 0, p: 32 }, { t: '获得', k: 1, p: 32 }, { t: '概率', a: 'r', k: 2, p: 14 }, { t: '地图', k: 3, p: 22 }],
        rows, onRow: r => A.itemSheet(r.__v[1])
      }).el);
      rows.forEach((r, i) => { r.__v = V[i]; });
    }
  });

  /* ================= 斗技大会 ================= */
  A.route('arena', {
    title: '斗技大会', sub: '', load: ['arena', 'weapons', 'armor', 'items', 'item_icons', 'monsters'],
    mount(view) {
      const AR = A.data.arena;
      A.setTitle('斗技大会', `${AR.length} 个任务`);
      const rows = AR.map(a => [
        { html: `<span class="nm">${a[7].map(m => `<img class="mi" src="${A.monImg(m)}" alt="">`).join('')} 斗技任务 #${a[0]}</span>`, v: a[0] },
        { t: a[1], v: a[1] },
        { t: A.fmt(a[2]), a: 'r', v: a[2] },
        { t: a[3], a: 'c', v: a[3] },
        { t: a[4], a: 'c', v: a[4] }
      ]);
      const t = A.table({
        cols: [{ t: '任务', k: 0, w: 146 }, { t: '地图', k: 1, w: 74 }, { t: '报酬金', a: 'r', k: 2, w: 54 },
        { t: '人数', a: 'c', k: 3, w: 38 }, { t: 'S', a: 'c', k: 4, w: 40 }],
        rows, onRow: r => {
          const a = r.__a;
          const W = A.byId('weapons'), AR2 = A.byId('armor'), M = A.byId('items'), MO = A.byId('monsters');
          let h = `<div class="detail-head"><div class="grow"><h2>斗技任务 #${a[0]}</h2>
            <div class="meta"><span>${a[1]}</span><span>报酬 ${A.fmt(a[2])} z</span><span>${a[3]} 人</span></div>
            <div class="meta"><span>S ${a[4]}</span><span>A ${a[5]}</span><span>B ${a[6]}</span></div></div></div>`;
          h += A.card(A.sec('目标怪物') + `<div class="monrow">${a[7].map(m => `<div class="monchip"><img src="${A.monImg(m)}" alt=""><span>${A.esc((MO.get(m) || [0, m])[1])}</span></div>`).join('')}</div>`);
          if (a[8].length) {
            h += A.card(A.sec('指定武器') + `<table class="grid"><tbody>${a[8].map(([wid, t2]) =>
              `<tr><td class="dim">${t2}</td><td>${A.esc((W.get(wid) || [0, 0, '?'])[2])}</td></tr>`).join('')}</tbody></table>`);
          }
          if (a[9].length) {
            h += A.card(A.sec('提供防具') + `<table class="grid"><tbody>${a[9].map(([aid]) =>
              `<tr><td>${A.esc((AR2.get(aid) || [0, 0, '?'])[2])}</td></tr>`).join('')}</tbody></table>`);
          }
          if (a[11].length) {
            h += A.card(A.sec('道具箱') + `<table class="grid"><tbody>${a[11].map(([id, q]) =>
              `<tr data-item="${id}"><td class="withico">${A.itemIcon(id, 22)}<span>${A.esc((M.get(id) || [0, '?'])[1])}</span></td><td class="num">×${q}</td></tr>`).join('')}</tbody></table>`);
          }
          A.sheet('斗技大会 #' + a[0], h);
          A.$('#sheet-live').addEventListener('click', e => {
            const it = e.target.closest('[data-item]'); if (it) A.itemSheet(it.dataset.item);
          });
        }
      });
      rows.forEach((r, i) => { r.__a = AR[i]; });
      view.appendChild(t.el);
    }
  });

  /* ================= 关于 ================= */
  A.route('about', {
    title: '关于', sub: '',
    load: ['meta'],
    mount(view) {
      const m = A.data.meta || {};
      view.innerHTML = `
      <div class="card pad">
        <div class="h2">MHXX 资料库 · 网页版</div>
        <div class="dim mt4">怪物猎人 XX（Monster Hunter XX / GU）中文资料 · 全功能移植</div>
        <div class="kvtable mt12">
          ${A.kv([['武器', A.fmt(m.weapons) + ' 把'], ['防具', A.fmt(m.armor) + ' 件'], ['装饰品', A.fmt(m.jewels) + ' 种'],
        ['道具', A.fmt(m.items) + ' 种'], ['技能系统', m.skills + ' 个'], ['任务', A.fmt(m.quests) + ' 个'],
        ['怪物', m.monsters + ' 种'], ['猎虫', m.kinsects + ' 只'], ['勋章', m.medals + ' 枚'],
        ['笛旋律', m.songs + ' 条'], ['委托', m.hfh + ' 个'], ['调和', m.combo + ' 条']])}
        </div>
      </div>
      <div class="card pad">
        <div class="sec-in">装到手机上</div>
        <div class="text mt8">iPhone：Safari 打开 → 分享 → 添加到主屏幕，之后全屏离线可用。<br>
        Android：Chrome 菜单 → 安装应用 / 添加到主屏幕。</div>
      </div>
      <div class="card pad">
        <div class="sec-in">数据来源</div>
        <div class="text dim mt8">武器、防具、技能、任务、地图与图标来自 <b>Ping's MHXX Dex</b>（作者 pingtendo），
        按 CC BY-NC-ND 4.0 使用：保留署名、不得商用、不得二次演绎。游戏素材版权归 CAPCOM 所有。<br>
        本页仅作个人游戏查询用途。</div>
      </div>`;
    }
  });
})();
