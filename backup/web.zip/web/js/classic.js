/* classic.js — WinForms 界面渲染引擎
   所有控件按 classic_spec.json 中的绝对坐标放置；坐标直接来自 exe 的 IL。 */
(function () {
  'use strict';
  var CD = window.ClassicData, S = null;
  var CW = 1100, CH = 760, scale = 1;
  var world, canvas, desktop, tasklist, startmenu;
  var wins = {}, zTop = 20, openSeq = 0;
  var ST = {};   // 每个窗体的状态
  var asbDemoDone = false, activeKey = 'main';

  /* ---------------- 小工具 ---------------- */
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function px(n) { return (n || 0) + 'px'; }
  function q(sel, root) { return (root || document).querySelector(sel); }
  function qa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function setMsg(s) { var n = q('#status-msg'); if (n) n.textContent = s; }

  /* ---------------- 列定义 ---------------- */
  var NUMHINT = /稀有|威力|会心|防御|插槽|孔|数量|概率|卖价|买价|价|点数|持间|时间|费|HRP|报酬|耐性|伤害|Cut|Impact|Shot|Fir|Wtr|Thd|Ice|Drg|Diz|Pt|Rare|Atk|Def|Slot|Qty|Succ|Fee|Reward|HRP|Max|Sell|Buy|Res_|Lv|#/;
  function colWidth(c) {
    if (c.c === 'DGVImgCol_WpnSharp') return 120;   // 原程序斩味条列
    if (c.w && +c.w >= 20) return +c.w;
    var h = c.h || '';
    if (c.c.indexOf('DGVImgCol') === 0) return 22;
    var n = 0;
    for (var i = 0; i < h.length; i++) n += h.charCodeAt(i) > 255 ? 13 : 7;
    return Math.max(38, Math.min(190, n + 16));
  }
  // 原程序按当前武器类型动态隐藏专属列
  function wpnType() {
    var st = ST.wpn;
    return (st && st.filters && +st.filters.type) || 1;
  }
  function wantWpnCol(c) {
    var n = c.c, t = wpnType();
    if (/^GLShotType/.test(n)) return t === 8;
    if (/^AxePhial/.test(n)) return t === 9 || t === 10;
    if (/^ISKinsectType/.test(n)) return t === 11;
    if (/^Gun/.test(n)) return t === 12 || t === 13;
    if (/^BowShot/.test(n)) return t === 14;
    if (/HHNote/.test(n)) return t === 6;
    return true;
  }
  function visibleCols(t) {
    var cols = (S.tables[t] || []).filter(function (c) {
      if (c.v === 0) return false;
      if (t === '_DGV_WpnList' && !wantWpnCol(c)) return false;
      return true;
    });
    var base = [], imgs = [];
    cols.forEach(function (c) {
      if (c.c.indexOf('DGVImgCol') === 0) imgs.push(c); else base.push(c);
    });
    imgs.sort(function (a, b) { return (a.i == null ? 999 : a.i) - (b.i == null ? 999 : b.i); });
    imgs.forEach(function (im) {
      var at = im.i == null ? base.length : Math.min(base.length, Math.max(0, im.i));
      base.splice(at, 0, im);
    });
    // 原程序武器表把「锋利度」放在插槽之后、生产价之前（IL 里的 DisplayIndex 含隐藏列）
    if (t === '_DGV_WpnList') {
      var si = -1, fi = -1;
      base.forEach(function (c, i) { if (c.c === 'Slot') si = i; if (c.c === 'DGVImgCol_WpnSharp') fi = i; });
      if (si >= 0 && fi >= 0 && fi !== si + 1) {
        var sharp = base.splice(fi, 1)[0];
        base.splice(fi < si ? si : si + 1, 0, sharp);
      }
    }
    return base.map(function (c) {
      return { c: c.c, h: c.h, w: colWidth(c), img: c.c.indexOf('DGVImgCol') === 0,
        sharp: /Sharp/i.test(c.c), num: NUMHINT.test(c.h || '') || NUMHINT.test(c.c) };
    });
  }

  /* ---------------- DataGridView ---------------- */
  // 部分列在 exe 里用数据库字段名，行对象里存的是中文表头，做一层别名
  var ALIAS = {
    Itm_Name: '道具', Wpn_Name: '武器', Amr_Name: '防具', Mon_Name: '怪物',
    Qst_Name: '任务', Jew_Name: '装饰品', SklTree_Name: '技能系统',
    ItmC_Name: '结果', ItmA_Name: '道具A', ItmB_Name: '道具B',
    LoadQty: '装填数', LoadQtyP: '追加', Max: '数量', SpFireQty: '特殊射击数量',
    RapidFireGap_Name: '间隔', RapidFireGap_Nam: '间隔', Qty: '数量', Succ: '成功率',
    MonPart_Name: '部位', HHSongRank_ID: '等级', Jew_Name_: '装饰珠',
    '数量': 'Qty', '道具': 'Itm_Name', '武器': 'Wpn_Name', '防具': 'Amr_Name'
  };
  function cellHTML(col, r) {
    if (col.img) {
      if (r._icons && r._icons[col.c] !== undefined) return r._icons[col.c];
      return col.sharp ? (r._sharp || '') : (r._icon || '');
    }
    var v = r[col.c];
    if (v === undefined && ALIAS[col.c]) v = r[ALIAS[col.c]];
    if (v && typeof v === 'object' && 'html' in v) return v.html;
    return CD.esc(CD.cv(v));
  }
  function buildTable(el, tname, rows, key) {
    var cols = visibleCols(tname);
    el._rows = rows || []; el._cols = cols; el._tname = tname; el._key = key;
    el._shown = 0; el._sortCol = -1; el._asc = true;
    var head = '<thead><tr>' + cols.map(function (c, i) {
      return '<th data-ci="' + i + '" class="' + (c.img ? 'imgcol' : '') + (c.num ? ' num' : '') +
        '" style="width:' + c.w + 'px;min-width:' + c.w + 'px;max-width:' + c.w + 'px">' + CD.esc(c.h) + '</th>';
    }).join('') + '</tr></thead>';
    var totalW = cols.reduce(function (s, c) { return s + c.w; }, 0);
    el.innerHTML = '<table style="width:' + Math.max(totalW, el.clientWidth || 0) + 'px">' + head + '<tbody></tbody></table>';
    var tb = q('tbody', el);
    if (!rows || !rows.length) {
      tb.innerHTML = '<tr><td class="empty" colspan="' + Math.max(1, cols.length) + '"></td></tr>';
      return;
    }
    appendRows(el, 70);
    if (!el._bound) {
      el._bound = 1;
      el.addEventListener('scroll', function () {
        if (el.scrollTop + el.clientHeight > el.scrollHeight - 160) appendRows(el, 70);
      });
      el.addEventListener('click', function (ev) {
        var th = ev.target.closest('th[data-ci]');
        if (th) return sortBy(el, +th.dataset.ci);
        var tr = ev.target.closest('tr[data-r]');
        if (!tr) return;
        qa('tr.sel', el).forEach(function (x) { x.classList.remove('sel'); });
        tr.classList.add('sel');
        var r = el._rows[+tr.dataset.r];
        if (r) selectRow(key, tname, r);
      });
    }
  }
  function appendRows(el, n) {
    if (!el._rows || el._shown >= el._rows.length) return;
    var to = Math.min(el._rows.length, el._shown + n), h = '', cols = el._cols;
    for (var i = el._shown; i < to; i++) {
      var r = el._rows[i];
      h += '<tr data-r="' + i + '">' + cols.map(function (c) {
        return '<td class="' + (c.img ? 'imgcol' : '') + (c.num ? ' num' : '') + '">' + cellHTML(c, r) + '</td>';
      }).join('') + '</tr>';
    }
    q('tbody', el).insertAdjacentHTML('beforeend', h);
    el._shown = to;
  }
  function sortBy(el, ci) {
    var c = el._cols[ci]; if (!c || !el._rows.length) return;
    if (el._sortCol === ci) el._asc = !el._asc; else { el._sortCol = ci; el._asc = true; }
    var s = el._asc ? 1 : -1;
    el._rows.sort(function (a, b) {
      var x = a[c.c], y = b[c.c];
      if (typeof x === 'number' && typeof y === 'number') return (x - y) * s;
      return String(x == null ? '' : x).localeCompare(String(y == null ? '' : y), 'zh') * s;
    });
    q('tbody', el).innerHTML = ''; el._shown = 0; appendRows(el, 70); el.scrollTop = 0;
  }
  function paintDGV(el, tname, key) {
    var rows = CD.rowsFor(tname, ctxOf(key)) || [];
    buildTable(el, tname, rows, key);
    var host = el.closest('.win'), st = host ? q('.winstatus .cnt', host) : null;
    if (st && CD.isMain(tname)) st.textContent = rows.length + ' 行';
  }

  /* ---------------- 上下文 / 联动 ---------------- */
  function ctxOf(key) {
    var s = ST[key] || {};
    return { form: key, sel: s.sel, filters: s.filters || {}, rank: s.rank, sharp: s.sharp };
  }
  function ancOf(form, i) {
    var out = [], seen = {}, p = form.controls[i].p, guard = 0;
    while (p >= 0 && guard++ < 20 && !seen[p]) { seen[p] = 1; out.push(p); p = form.controls[p].p; }
    return out;
  }
  function selectRow(key, tname, r) {
    var st = ST[key]; if (!st) return;
    // 套装模拟器：左表点选只是「待装备 / 待镶嵌」，不触发普通联动
    if (key === 'asb' && (tname === '_DGV_AmrList' || tname === '_DGV_JewList')) {
      st.sel = r; st.selTable = tname;
      return setMsg(tname === '_DGV_AmrList' ? CD.asbPickArmor(r) : CD.asbPickJewel(r));
    }
    r._kind = r._kind || CD.kindOfTable(tname);
    st.sel = r; st.selTable = tname;
    // 联动所有非主表
    Object.keys(st.dgvs).forEach(function (t) {
      if (CD.isMain(t) || t === tname) return;
      paintDGV(st.dgvs[t], t, key);
    });
    // 图片
    updatePicture(key, r);
    // 武器窗体：按类型切换装填弹药 / 旋律分组
    if (key === 'wpn') {
      var w = r._raw || [], ty = w[1];
      setGroupVisible(key, '_GroupBox_Gun', ty === 12 || ty === 13);
      setGroupVisible(key, '_GroupBox_HHSong', ty === 6);
    }
    setMsg(st.title + ' · ' + (r.Wpn_Name || r.Itm_Name || r.Amr_Name || r.Mon_Name || r.Qst_Name || r.Jew_Name || r['任务'] || ('#' + r._id)) + ' 已选中');
  }
  function updatePicture(key, r) {
    var st = ST[key], f = S.forms[key]; if (!st || !f) return;
    f.controls.forEach(function (c, i) {
      if (c.t !== 'PictureBox') return;
      var node = st.nodes[i]; if (!node) return;
      var src = '';
      if (c.n === '_PictureBox_WpnImg' && r._kind === 'wpn') {
        var w = r._raw; src = w && w[10] ? 'img/w/' + w[10] + '.webp' : '';
      } else if (c.n === '_PictureBox_Mon' && r._kind === 'mon') src = 'img/m/' + r._id + '.webp';
      else if (/AmrImg|_PictureBox_Amr/.test(c.n) && r._kind === 'amr') {
        var a = r._raw; src = a && a[10] ? 'img/a/' + a[10] + '.webp' : '';
      } else if (c.n === '_PictureBox_ISKinsectImg' && r._kind === 'kinsect') {
        var k = r._raw; src = k && k[4] ? 'img/k/' + k[4] + '.webp' : '';
      }
      node.innerHTML = src ? '<img src="' + src + '">' : '';
    });
    if (key === 'awd' && r._kind === 'awd') {
      f.controls.forEach(function (c, i) {
        var n = st.nodes[i]; if (!n) return;
        if (c.n === '_Label_Name') n.textContent = r['勋章'] || '';
        if (c.n === '_Label_Des') n.textContent = r['说明'] || '';
      });
    }
  }
  function setGroupVisible(key, name, on) {
    var st = ST[key], f = S.forms[key]; if (!st || !f) return;
    var root = -1;
    f.controls.forEach(function (c, i) { if (c.n === name) root = i; });
    if (root < 0) return;
    hideTree(key, root, !on);
  }
  function hideTree(key, root, hide) {
    var st = ST[key], f = S.forms[key]; if (!st) return;
    [root].concat(f.controls.map(function (c, i) { return ancOf(f, i).indexOf(root) >= 0 ? i : -1; })
      .filter(function (x) { return x >= 0; })).forEach(function (i) {
        if (st.nodes[i]) st.nodes[i].style.display = hide ? 'none' : '';
      });
  }

  /* ---------------- 主表筛选 ---------------- */
  function applyFilter(key) {
    var st = ST[key]; if (!st) return;
    // 模拟器有两张主表（防具 / 装饰珠），搜索与部位筛选同时作用于两者
    if (key === 'asb') {
      ['_DGV_AmrList', '_DGV_JewList'].forEach(function (t) {
        if (st.dgvs[t]) paintDGV(st.dgvs[t], t, key);
      });
      return;
    }
    var main = st.mainTable; if (!main) return;
    var d = st.nodes[st.mainIdx]; if (!d) return;
    var all = CD.mainRows(main);
    var ft = st.filters || {}, kw = (ft.kw || '').toLowerCase(), ty = +ft.type || 0;
    var rows = all.filter(function (r) {
      if (kw) {
        var nm = (r.Wpn_Name || r.Itm_Name || r.Amr_Name || r.Mon_Name || r.Qst_Name ||
          r.Jew_Name || r.SklTree_Name || r['任务'] || r['怪物'] || r['道具'] || '').toLowerCase();
        if (nm.indexOf(kw) < 0) return false;
      }
      if (ty && key === 'wpn' && r._raw[1] !== ty) return false;
      if (ft.lastNode && key === 'wpn' && r._raw[11] > 0) return false;
      if (ft.elem && key === 'wpn') {
        var es = r._raw[5] || [];
        if (!es.some(function (e) { return e[0] === +ft.elem; })) return false;
      }
      if (ft.keyQst && key === 'qst' && !/关键|★|Key|◎|●/.test(r._raw[4] || '')) return false;
      if (ft.lv && key === 'qst' && r._raw[2] !== ft.lv) return false;
      if (ft.loc && key === 'qst' && r._raw[5] !== ft.loc) return false;
      if (ft.qtype && key === 'qst' && r._raw[3] !== ft.qtype) return false;
      if (ft.part && key === 'amr' && r._raw[1] !== +ft.part) return false;
      if (ft.borg && key === 'amr' && r._raw[8] !== 0 && r._raw[8] !== +ft.borg) return false;
      return true;
    });
    buildTable(d, main, rows, key);
    var cnt = q('.winstatus .cnt', d.closest('.win'));
    if (cnt) cnt.textContent = rows.length + ' / ' + all.length + ' 行';
  }

  /* ---------------- TreeView（武器强化树） ---------------- */
  var TREE = null;
  function buildTree() {
    if (TREE) return TREE;
    var W = CD.data.weapons, byType = {}, kids = new Map(), roots = [];
    W.forEach(function (w) { (byType[w[1]] = byType[w[1]] || []).push(w); });
    function lv(s) { var m = String(s).match(/Lv\.(\d+)/); return m ? +m[1] : 1; }
    Object.keys(byType).forEach(function (t) {
      var a = byType[t];
      a.forEach(function (w, i) {
        var L = lv(w[2]), p = null;
        if (L > 1) for (var j = i - 1; j >= Math.max(0, i - 16); j--) {
          if (lv(a[j][2]) === L - 1) { p = a[j]; break; }
        }
        if (p) { if (!kids.has(p[0])) kids.set(p[0], []); kids.get(p[0]).push(w); }
        else roots.push(w);
      });
    });
    TREE = { kids: kids, roots: roots };
    return TREE;
  }
  function paintTree(node, key, expandAll) {
    var T = buildTree();
    var shown = T.roots.slice(0, 260);
    function line(w, depth) {
      var ch = T.kids.get(w[0]) || [];
      return '<div class="tn" data-w="' + w[0] + '" style="padding-left:' + (2 + depth * 13) + 'px">' +
        (ch.length ? '<span class="tg" data-tg="' + w[0] + '">' + (expandAll ? '▾' : '▸') + '</span>' : '<span class="tg ph">·</span>') +
        (w[10] ? CD.wpnIcon(w[10], 16) : '<i style="width:16px"></i>') +
        '<span>' + CD.esc(String(w[2]).replace(/\s*-\s*Lv\.\d+/, '')) + '</span>' +
        '<em>Lv.' + (String(w[2]).match(/Lv\.(\d+)/) || [0, 1])[1] + '</em></div>';
    }
    node.innerHTML = shown.map(function (w) { return line(w, 0); }).join('');
    if (!node._bound) {
      node._bound = 1;
      node.addEventListener('click', function (ev) {
        var tg = ev.target.closest('[data-tg]');
        if (tg) { ev.stopPropagation(); return toggleNode(node, tg.dataset.tg, tg); }
        var tn = ev.target.closest('.tn[data-w]'); if (!tn) return;
        qa('.tn.sel', node).forEach(function (x) { x.classList.remove('sel'); });
        tn.classList.add('sel');
        var w = CD.idx.weapons.get(+tn.dataset.w);
        if (w) {
          var r = { _raw: w, _id: w[0], _kind: 'wpn', Wpn_Name: w[2] };
          ST[key].sel = r;
          Object.keys(ST[key].dgvs).forEach(function (t) { if (!CD.isMain(t)) paintDGV(ST[key].dgvs[t], t, key); });
          updatePicture(key, r);
          setGroupVisible(key, '_GroupBox_Gun', w[1] === 12 || w[1] === 13);
          setGroupVisible(key, '_GroupBox_HHSong', w[1] === 6);
          setMsg(w[2] + ' 已选中');
        }
      });
    }
  }
  function toggleNode(node, id, tg) {
    var after = tg.closest('.tn');
    var next = after.nextElementSibling;
    if (next && next.dataset.grp === id) { next.remove(); tg.textContent = '▸'; return; }
    var T = buildTree(), ch = T.kids.get(+id) || [], box = el('div');
    box.dataset.grp = id;
    var depth = (+after.style.paddingLeft.replace('px', '') - 2) / 13 + 1;
    box.innerHTML = ch.map(function (w) {
      var cc = T.kids.get(w[0]) || [];
      return '<div class="tn" data-w="' + w[0] + '" style="padding-left:' + (2 + depth * 13) + 'px">' +
        (cc.length ? '<span class="tg" data-tg="' + w[0] + '">▸</span>' : '<span class="tg ph">·</span>') +
        (w[10] ? CD.wpnIcon(w[10], 16) : '<i style="width:16px"></i>') +
        '<span>' + CD.esc(String(w[2]).replace(/\s*-\s*Lv\.\d+/, '')) + '</span></div>';
    }).join('');
    after.parentNode.insertBefore(box, after.nextSibling);
    tg.textContent = '▾';
  }

  /* 猎虫窗体左树（原程序是 TreeView，不是 DataGridView） */
  function paintKinsectTree(node, key) {
    var K = CD.data.kinsects;
    node.innerHTML = K.map(function (k) {
      var ico = k[4] ? '<img src="img/k/' + k[4] + '.webp" style="width:16px;height:16px">' : '<i style="width:16px"></i>';
      return '<div class="tn" data-k="' + k[0] + '">' + ico + '<span>' + CD.esc(k[1]) +
        '</span><em>R' + k[3] + '</em></div>';
    }).join('');
    node.addEventListener('click', function (ev) {
      var tn = ev.target.closest('.tn[data-k]'); if (!tn) return;
      qa('.tn.sel', node).forEach(function (x) { x.classList.remove('sel'); });
      tn.classList.add('sel');
      var k = CD.idx.kinsects.get(+tn.dataset.k); if (!k) return;
      var st = ST[key];
      st.sel = { _id: k[0], _kind: 'kinsect', _raw: k };
      Object.keys(st.dgvs).forEach(function (t) { paintDGV(st.dgvs[t], t, key); });
      updatePicture(key, st.sel);
      setMsg(k[1]);
    });
  }

  /* ---------------- 控件渲染 ---------------- */
  /* 原程序这些 Radio/Check 是图标按钮（exe 内嵌资源），这里用等尺寸字形还原 */
  var WPN_GLYPH = ['大', '太', '片', '双', '锤', '笛', '枪', '铳', '斧', '盾', '棍', '轻', '重', '弓'];
  var ELEM_GLYPH = { 1: '火', 2: '水', 3: '雷', 4: '冰', 5: '龙', 6: '毒', 7: '麻', 8: '睡', 9: '爆' };
  var NOTE_GLYPH = ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧'];
  function iconGlyph(n) {
    var m = String(n).match(/_RadioButton_Wpn(\d+)/);
    if (m) return { t: WPN_GLYPH[+m[1] - 1] || '?', c: '#2b5f96', tip: '武器类型 ' + m[1] };
    m = String(n).match(/_CheckBox_SpAtk(\d)/);
    if (m) return { t: ELEM_GLYPH[m[1]] || '?', c: '#a8501a', tip: '属性 ' + (ELEM_GLYPH[m[1]] || '') };
    m = String(n).match(/_CheckBox_Note(\d)/);
    if (m) return { t: NOTE_GLYPH[+m[1] - 1] || '?', c: '#6c4a94', tip: '笛音色 ' + m[1] };
    m = String(n).match(/_CheckBox_QstIcon(\d)/);
    if (m) return { t: '★', c: '#b08420', tip: '任务图标 ' + m[1] };
    return null;
  }

  function comboOptions(f, c) {
    var D = CD.data, L = D.labels, out = [['', '全部']];
    if (c.n === '_ComboBox_Lv') Object.keys(L.qstLv).slice(0, 45).forEach(function (k) { out.push([L.qstLv[k], L.qstLv[k]]); });
    else if (c.n === '_ComboBox_Type') Object.keys(L.qstType).forEach(function (k) { out.push([L.qstType[k], L.qstType[k]]); });
    else if (c.n === '_ComboBox_Loc' || c.n === '_ComboBox_Loc2') Object.keys(L.loc).forEach(function (k) { out.push([L.loc[k], L.loc[k]]); });
    else if (c.n === '_ComboBox_Mon') D.monsters.forEach(function (m) { out.push([m[1], m[1]]); });
    else if (c.n === '_ComboBox_SklTree' || /SklTree/.test(c.n)) D.skills.trees.forEach(function (t) { out.push([t[1], t[1]]); });
    else if (c.n === '_ComboBox_SpFilter' || c.n === '_ComboBox_SpFilter2') {
      Object.keys(L.axePhial).forEach(function (k) { out.push([L.axePhial[k], L.axePhial[k]]); });
      Object.keys(L.shotType).forEach(function (k) { out.push([L.shotType[k], L.shotType[k]]); });
    } else if (/Part/.test(c.n)) [1, 2, 3, 4, 5].forEach(function (p) { out.push([String(p), CD.partName[p]]); });
    else if (/BorG/.test(c.n)) out = [['', '全部'], ['1', '剑士'], ['2', '枪手']];
    return out;
  }
  function makeCtl(f, c, i, key) {
    var st = ST[key], d = el('div', 'ctl'), t = c.t;
    d.dataset.i = i; d.dataset.n = c.n;
    d.style.left = px(c.x); d.style.top = px(c.y); d.style.width = px(c.w); d.style.height = px(c.h);
    if (key === 'main' && t !== 'MenuStrip' && t !== 'TableLayoutPanel') d.style.top = px(c.y + 26);

    if (t === 'GroupBox') {
      d.className = 'ctl gbox';
      if (c.tx) d.appendChild(el('span', 'glab', CD.esc(c.tx)));
    } else if (t === 'Panel' || t === 'TableLayoutPanel' || t === 'SplitContainer' || t === 'TabControl' || t === 'TabPage' || t === 'FlowLayoutPanel') {
      d.className = 'ctl panel';
      d.style.pointerEvents = 'none';
      if (t === 'SplitContainer') {
        var pr = c.pr || {}, sd = +(pr.SplitterDistance || 0), ori = pr.Orientation == null ? 1 : +pr.Orientation;
        if (sd > 0) {
          var ln = el('div', 'splitln');
          if (ori === 0) { ln.style.cssText = 'left:0;top:' + sd + 'px;width:100%;height:4px'; }
          else { ln.style.cssText = 'left:' + sd + 'px;top:0;width:4px;height:100%'; }
          d.appendChild(ln);
        }
      }
    } else if (t === 'MenuStrip') {
      d.className = 'ctl menubar';
      var mi = [['Language', ['English', '简体中文', '繁體中文', '日本語', '한국어', 'Deutsch', 'Français', 'Italiano', 'Español']],
      ['Settings', ['Auto Check Update', 'One Process', 'Save Language', 'Sort ComboBox', 'Hide Empty Panels']],
      ['Help', ['Update', 'About', "Ping's MHXX Dex (Web)"]]];
      mi.forEach(function (m) {
        var it = el('div', 'menuitem', CD.esc(m[0]));
        var pop = el('div', 'menu-pop', m[1].map(function (x) { return '<div>' + CD.esc(x) + '</div>'; }).join(''));
        it.appendChild(pop); d.appendChild(it);
        it.addEventListener('click', function (ev) {
          ev.stopPropagation();
          qa('.menuitem.open', d).forEach(function (x) { if (x !== it) x.classList.remove('open'); });
          it.classList.toggle('open');
        });
      });
      d.style.width = px(f.w);
    } else if (t === 'DataGridView') {
      d.className = 'ctl dgv';
      st.dgvs[c.n] = d;
      if (CD.isMain(c.n)) { st.mainTable = c.n; st.mainIdx = i; }
      paintDGV(d, c.n, key);
    } else if (t === 'TreeView') {
      d.className = 'ctl tv';
      if (c.n === '_TVW_ISKinsectList') paintKinsectTree(d, key);
      else paintTree(d, key, false);
      st.tree = d;
    } else if (t === 'Button') {
      d.className = 'ctl wbtn' + (key === 'main' ? ' main' : '');
      var label = c.tx || '';
      if (S.btn2key[c.n]) label = S.btnCn[S.btn2key[c.n]] || label;
      d.textContent = label;
      d.title = c.n;
      d.style.pointerEvents = 'auto';
      if (S.btn2key[c.n]) d.addEventListener('click', function () { open(S.btn2key[c.n]); });
      else if (c.n === '_Button_Expand' || c.n === '_Button_Collapse')
        d.addEventListener('click', function () { if (st.tree) paintTree(st.tree, key, c.n === '_Button_Expand'); });
      else d.addEventListener('click', function () { onGenericButton(key, c, d); });
    } else if (t === 'CheckBox' || t === 'RadioButton') {
      var radio = t === 'RadioButton', pr = c.pr || {};
      var gl = iconGlyph(c.n), only = !c.tx && c.w <= 26;
      d.className = 'ctl wck ' + (radio ? 'rd' : 'ck') + (only ? ' icononly' : '') + (gl ? ' hasimg' : '');
      var on = pr.Checked === 1 || pr.CheckState === 1;
      d.innerHTML = '<span class="box' + (on ? ' on' : '') + '">' +
        (gl ? '<b style="display:block;width:100%;height:100%;text-align:center;line-height:18px;' +
          'font-size:12px;font-weight:600;color:' + gl.c + '">' + gl.t + '</b>' : '') + '</span>' +
        '<span class="lb">' + CD.esc(c.tx) + '</span>';
      d.style.pointerEvents = 'auto';
      d.title = (gl && gl.tip) || c.n;
      d.addEventListener('click', function () { onCheck(key, c, d, radio); });
    } else if (t === 'ComboBox') {
      d.className = 'ctl wcombo'; d.style.pointerEvents = 'auto';
      var opts = comboOptions(f, c);
      d.innerHTML = '<select>' + opts.map(function (o) {
        return '<option value="' + CD.esc(o[0]) + '">' + CD.esc(o[1]) + '</option>';
      }).join('') + '</select>';
      d.title = c.n;
      q('select', d).addEventListener('change', function (ev) { onCombo(key, c, ev.target.value); });
    } else if (t === 'TextBox') {
      d.className = 'ctl wtext' + (/Search/i.test(c.n) ? ' search' : '');
      d.style.pointerEvents = 'auto';
      d.innerHTML = '<input placeholder="" spellcheck="false">';
      d.title = c.n;
      if (/Search/i.test(c.n)) {
        q('input', d).addEventListener('input', function (ev) {
          var v = ev.target.value.trim().toLowerCase();
          // 搜索框按窗体位置就近绑定主表
          ST[key].filters.kw = v; applyFilter(key);
        });
      }
    } else if (t === 'NumericUpDown') {
      d.className = 'ctl wnum'; d.style.pointerEvents = 'auto';
      d.innerHTML = '<input value="0"><span class="spin"><i>▴</i><i>▾</i></span>';
    } else if (t === 'Label') {
      d.className = 'ctl wlab'; d.textContent = c.tx;
    } else if (t === 'PictureBox') {
      d.className = 'ctl wpic' + (/Search/i.test(c.n) ? ' searchbox' : '');
      d.title = c.n;
      if (/slot|Jew/i.test(c.n)) d.classList.add('slotico');
    } else if (t === 'ToolStripMenuItem' || t === 'ToolStripSeparator' || t.indexOf('Column') >= 0) {
      return null;
    } else {
      d.className = 'ctl'; d.style.pointerEvents = 'none';
      if (c.tx) d.textContent = c.tx;
    }
    return d;
  }
  function onCheck(key, c, d, radio) {
    var box = q('.box', d), st = ST[key];
    if (radio) {
      var f = S.forms[key];
      f.controls.forEach(function (o, i) {
        if (o.t === 'RadioButton' && st.nodes[i] && st.nodes[i] !== d && sameGroup(o.n, c.n)) {
          q('.box', st.nodes[i]).classList.remove('on');
        }
      });
      box.classList.add('on');
    } else box.classList.toggle('on');
    var on = box.classList.contains('on');
    // 套装模拟器：5 个部位筛选按钮
    if (key === 'asb' && /_CheckBox_Part\d/.test(c.n)) {
      var parts = [];
      S.forms.asb.controls.forEach(function (o, j) {
        var mm = String(o.n).match(/_CheckBox_Part(\d)/);
        if (mm && st.nodes[j] && q('.box', st.nodes[j]).classList.contains('on')) parts.push(+mm[1]);
      });
      st.filters.parts = parts;
      return applyFilter(key);
    }
    // 武器类型
    // 地图选择：27 个 RadioButton 直接决定右侧三张采集表
    var lm = String(c.n).match(/_RadioButton_Loc(\d+)/);
    if (lm) {
      var lid = +lm[1];
      st.sel = { _id: lid, _kind: 'loc', _raw: [lid] };
      Object.keys(st.dgvs).forEach(function (t) { paintDGV(st.dgvs[t], t, key); });
      setMsg(CD.locName(lid) + ' · 采集一览');
      return;
    }
    var m = String(c.n).match(/_RadioButton_Wpn(\d+)/);
    if (m) {
      var wt = on ? +m[1] : 0;
      st.filters.type = wt;
      setGroupVisible('wpn', '_Panel_FilterNote', wt === 6);
      setGroupVisible('wpn', '_Panel_Filter1', wt >= 8 && wt <= 14);
      setGroupVisible('wpn', '_Panel_Filter2', wt === 12 || wt === 13 || wt === 14);
      setGroupVisible('wpn', '_Panel_SharpP1', wt >= 1 && wt <= 7);
      S.forms.wpn.controls.forEach(function (c, i) {
        if (c.n === '_CheckBox_SpFire' && ST.wpn && ST.wpn.nodes[i])
          ST.wpn.nodes[i].style.display = (wt === 12 || wt === 13) ? '' : 'none';
      });
      return applyFilter(key);
    }
    // 怪物页签
    if (/_RadioButton_(Item|Weak|Ail)/.test(c.n)) {
      var tag = c.n.match(/_RadioButton_(Item|Weak|Ail)/)[1];
      var want = { Item: '_Panel_Item', Weak: '_Panel_Weak', Ail: '_Panel_Ail' }[tag];
      f.controls.forEach(function (o, i) {
        if (o.t === 'Panel' && /_Panel_(Item|Weak|Ail)/.test(o.n)) {
          hideTree(key, i, o.n !== want);
        }
      });
      return;
    }
    if (c.n === '_CheckBox_LastNode') { st.filters.lastNode = on; return applyFilter(key); }
    if (c.n === '_CheckBox_Key') { st.filters.keyQst = on; return applyFilter(key); }
    var em = String(c.n).match(/_CheckBox_SpAtk(\d)/);
    if (em) { st.filters.elem = on ? em[1] : 0; return applyFilter(key); }
    var sh = String(c.n).match(/_RadioButton_Sharp(\d)/);
    if (sh && on) { st.sharp = +sh[1]; setMsg('锋利度 +' + sh[1] + '（匠加成）'); }
  }
  function sameGroup(a, b) {
    var ra = String(a).replace(/\d+$/, ''), rb = String(b).replace(/\d+$/, '');
    return ra === rb;
  }
  function onCombo(key, c, v) {
    var st = ST[key], f = st.filters;
    if (c.n === '_ComboBox_Lv') f.lv = v;
    else if (c.n === '_ComboBox_Loc') f.loc = v;
    else if (c.n === '_ComboBox_Type') f.qtype = v;
    else if (/Part/.test(c.n)) f.part = v;
    else if (/BorG/.test(c.n)) f.borg = v;
    else return;
    applyFilter(key);
  }
  /* ---------------- 套装模拟器交互 ---------------- */
  function asbCodeInput() {
    var st = ST.asb, f = S.forms.asb; if (!st || !f) return null;
    for (var i = 0; i < f.controls.length; i++) {
      if (f.controls[i].n === '_TextBox_Code' && st.nodes[i]) return q('input', st.nodes[i]);
    }
    return null;
  }
  function asbRefresh() {
    var st = ST.asb; if (!st) return;
    ['_DGV_AsbtoAmr', '_DGV_SklList', '_DGV_AsbtoItm'].forEach(function (t) {
      if (st.dgvs[t]) paintDGV(st.dgvs[t], t, 'asb');
    });
    var A = CD.asb, f = S.forms.asb, m;
    f.controls.forEach(function (c, i) {
      var n = st.nodes[i]; if (!n || c.t !== 'Button') return;
      var nm = String(c.n);
      if ((m = nm.match(/^_Button_Amr([1-5])$/))) {
        var a = A.armor[+m[1] - 1];
        n.textContent = a ? a[2] : '＋ ' + CD.ASB_PART[+m[1] - 1];
      } else if ((m = nm.match(/^_Button_WpnJew([1-3])$/))) {
        var j1 = A.wpnJewels[+m[1] - 1];
        n.textContent = j1 ? j1[1] : '武器孔 ' + m[1];
      } else if ((m = nm.match(/^_Button_Amr([1-6])Jew([1-3])$/))) {
        var rw = +m[1], cl = +m[2];
        var js = rw === 6 ? A.charmJewels : A.jewels[rw - 1];
        var j2 = (js || [])[cl - 1];
        n.textContent = j2 ? j2[1] : '○';
      } else if (nm === '_Button_AddAmr') n.textContent = '＋';
      else if (nm === '_Button_RemoveAmr') n.textContent = '移除选中部位装备';
      else if (nm === '_Button_RemoveJew') n.textContent = '清空选中部位装饰珠';
      else if (nm === '_Button_CalcByCode') n.textContent = '↧';
      else if (nm === '_Button_ScreenShot') n.textContent = '⧉';
    });
    var ci = asbCodeInput(); if (ci) ci.value = CD.asbCode();
    var s = CD.asbStats();
    setMsg('套装模拟器 · 防御 ' + s.def + ' / 满 ' + s.mx + ' · 孔 ' + s.used + '/' + (s.slots + 6) +
      (s.skills.length ? ' · ' + s.skills.slice(0, 4).join('、') : ' · 尚未激活技能'));
  }
  function asbButton(c) {
    var nm = String(c.n), m, msg = '';
    if (nm === '_Button_AddAmr') msg = CD.asbAddArmor(null);
    else if (nm === '_Button_RemoveAmr') msg = CD.asbRemoveArmor(null);
    else if (nm === '_Button_RemoveJew') msg = CD.asbRemoveJewel(null);
    else if ((m = nm.match(/^_Button_Amr([1-5])$/))) {
      var i = +m[1] - 1; CD.asbSetActive(i);
      msg = '已选中部位：' + CD.ASB_PART[i] +
        (CD.asb.pendingArmor ? ' · 点「＋」加入所选防具' : ' · 点「移除装备」可卸下');
    } else if ((m = nm.match(/^_Button_WpnJew([1-3])$/))) {
      msg = CD.asbSetJewel('wpn', 0, +m[1] - 1);
    } else if ((m = nm.match(/^_Button_Amr([1-6])Jew([1-3])$/))) {
      var rw = +m[1], cl = +m[2] - 1;
      msg = rw === 6 ? CD.asbSetJewel('charm', 0, cl) : CD.asbSetJewel('amr', rw - 1, cl);
    } else if (nm === '_Button_CalcByCode') {
      var ci = asbCodeInput(); msg = CD.asbLoadCode(ci ? ci.value : '');
    } else if (nm === '_Button_ScreenShot') {
      var ci2 = asbCodeInput();
      if (ci2) { ci2.value = CD.asbCode(); if (ci2.select) ci2.select(); }
      msg = '已生成套装码，可复制保存';
    } else return false;
    asbRefresh();
    setMsg(msg);
    return true;
  }

  function onGenericButton(key, c, d) {
    var st = ST[key];
    if (key === 'asb' && asbButton(c)) return;
    if (key === 'asf') {
      var to = st.dgvs['_DGV_SklList_To'];
      if (c.n === '_Button_Add') {
        if (!st.sel || !st.sel.SklTree_ID) return setMsg('请先在「技能列表」里选中一个技能');
        CD.asfAdd(st.sel);
        paintDGV(to, '_DGV_SklList_To', 'asf');
        return setMsg('已添加目标技能：' + (st.sel.Skl_Name || ''));
      }
      if (c.n === '_Button_Delete') {
        CD.asfDel(); paintDGV(to, '_DGV_SklList_To', 'asf');
        return setMsg('已移除最后一个目标技能');
      }
      if (c.n === '_Button_Run') {
        setMsg('正在搜索套装…');
        var n = CD.asfRun();
        paintDGV(st.dgvs['_DGV_AsftoAsb'], '_DGV_AsftoAsb', 'asf');
        return setMsg('搜索完成：找到 ' + n + ' 套');
      }
    }
    if (/CalcByCode|ScreenShot|Save|Load|Run|Add|Remove|Delete|Invert|Calc/.test(c.n)) {
      setMsg('已选中：' + c.n);
    }
  }

  /* ---------------- 窗体 ---------------- */
  function formTitle(key, f) {
    if (key === 'main') return f.title;
    var n = '';
    if (key === 'wpn') n = ' (' + CD.data.weapons.length + ' / ' + CD.data.weapons.length + ')';
    return f.title + n + " - Ping's MHXX Dex - 版本 1.2 (Build 5)";
  }
  function open(key, opts) {
    if (!S.forms[key]) return;
    if (wins[key]) {
      var w = wins[key]; w.classList.remove('min'); focusWin(key);
      renderTasks(); return;
    }
    var f = S.forms[key];
    w = el('div', 'win');
    w.dataset.key = key;
    w.style.width = px(f.w + 2); w.style.height = px(f.h + 29 + 20 + 2);
    var n = openSeq++;
    var left = Math.max(4, Math.min(18 + (n % 8) * 20, CW - f.w - 8));
    var top = Math.max(4, Math.min(14 + (n % 7) * 17, CH - f.h - 40));
    w.style.left = px(left); w.style.top = px(top);
    var bar = el('div', 'winbar');
    bar.innerHTML = '<span class="winico"></span><span class="wincap">' + CD.esc(formTitle(key, f)) + '</span>' +
      '<span class="winctls"><button class="winctl minb" title="最小化">_</button>' +
      '<button class="winctl maxb" title="最大化">□</button>' +
      '<button class="winctl close" title="关闭">×</button></span>';
    var body = el('div', 'winbody');
    var status = el('div', 'winstatus', '<span>就绪</span><span class="cnt"></span>');
    w.appendChild(bar); w.appendChild(body); w.appendChild(status);

    ST[key] = { title: f.title, dgvs: {}, nodes: {}, filters: {}, mainTable: null, mainIdx: -1, sel: null };
    // 平铺所有控件（坐标已绝对化）
    f.controls.forEach(function (c, i) {
      var node = makeCtl(f, c, i, key);
      if (node) { ST[key].nodes[i] = node; body.appendChild(node); }
    });
    // 武器窗体：按默认武器类型（大剑）隐藏旋律 / 装填弹药组
    if (key === 'wpn') {
      setGroupVisible(key, '_GroupBox_HHSong', false);
      setGroupVisible(key, '_GroupBox_Gun', false);
      // 筛选区多组控件在原 exe 里按武器类型择一显示，位置本来是重叠的
      ['_Panel_Filter1', '_Panel_Filter2', '_Panel_FilterNote'].forEach(function (n) {
        setGroupVisible(key, n, false);
      });
      f.controls.forEach(function (c, i) {
        if (c.n === '_CheckBox_SpFire' && ST[key].nodes[i]) ST[key].nodes[i].style.display = 'none';
      });
    }
    // 怪物窗体：默认显示「道具」页
    if (key === 'mon') f.controls.forEach(function (c, i) {
      if (c.t === 'Panel' && /_Panel_(Weak|Ail)/.test(c.n)) hideTree(key, i, true);
    });

    q('.minb', bar).addEventListener('click', function () { w.classList.add('min'); renderTasks(); });
    q('.maxb', bar).addEventListener('click', function () { toggleMax(key); });
    q('.close', bar).addEventListener('click', function () { close(key); });
    bar.addEventListener('mousedown', function (e) { if (e.target.closest('button')) return; dragStart(e, key); });
    bar.addEventListener('touchstart', function (e) { if (e.target.closest('button')) return; dragStart(e.touches[0], key); }, { passive: true });
    w.addEventListener('mousedown', function () { focusWin(key); });

    world.appendChild(w);
    wins[key] = w;
    focusWin(key); renderTasks();
    var cnt = q('.winstatus .cnt', w);
    if (cnt && ST[key].mainTable) cnt.textContent = (CD.mainRows(ST[key].mainTable) || []).length + ' 行';
    // 原程序打开窗体即选中第一行，底部分组随之填充
    if (ST[key].mainTable) {
      var d0 = ST[key].dgvs[ST[key].mainTable], tr0 = d0 && q('tbody tr[data-r]', d0);
      if (tr0) tr0.click();
    }
    // 地图：默认选中第 1 张地图
    if (key === 'loc') {
      ST.loc.sel = { _id: 1, _kind: 'loc', _raw: [1] };
      Object.keys(ST.loc.dgvs).forEach(function (t) { paintDGV(ST.loc.dgvs[t], t, 'loc'); });
    }
    // 猎虫：TreeView 默认选一只有素材、有虫技能的猎虫，三张联动表都能看到数据
    if (key === 'kinsect') {
      var ks = CD.data.kinsects;
      var k0 = ks.filter(function (k) { return (k[6] || []).length && (k[5] || []).length; })[0]
        || ks.filter(function (k) { return (k[6] || []).length || (k[5] || []).length; })[0]
        || ks[0];
      if (k0) {
        ST.kinsect.sel = { _id: k0[0], _kind: 'kinsect', _raw: k0 };
        Object.keys(ST.kinsect.dgvs).forEach(function (t) { paintDGV(ST.kinsect.dgvs[t], t, 'kinsect'); });
        updatePicture('kinsect', ST.kinsect.sel);
        var tn = q('.tn[data-k="' + k0[0] + '"]', wins[key]);
        if (tn) tn.classList.add('sel');
      }
    }
    if (key === 'awd') buildMedals(f);
    setMsg('已打开：' + f.title);
    if (key === 'asb') {
      var firstAsb = !asbDemoDone;
      if (firstAsb && CD.asbDemo) { CD.asbDemo(); asbDemoDone = true; }
      CD.asbSetActive(0); asbRefresh();
      if (firstAsb) setMsg('已载入示例配装 · 可点「移除装备」清空或粘贴套装码覆盖');
    }
    // 手机上每打开一个窗体，按该窗体尺寸重新适应一次
    if (window.innerWidth < 760 && window.__autoFit !== false) fitWindow(key);
  }
  function close(key) {
    var w = wins[key]; if (!w) return;
    w.remove(); delete wins[key]; delete ST[key]; renderTasks();
  }
  function toggleMax(key) {
    var w = wins[key]; if (!w) return;
    var f = S.forms[key];
    if (w.dataset.max === '1') {
      w.dataset.max = '0';
      w.style.left = px(w.dataset.ox); w.style.top = px(w.dataset.oy);
      w.style.width = px(f.w + 2); w.style.height = px(f.h + 51);
      q('.winbody', w).style.height = '';
    } else {
      w.dataset.ox = parseFloat(w.style.left); w.dataset.oy = parseFloat(w.style.top);
      w.dataset.max = '1';
      w.style.left = '0px'; w.style.top = '0px';
      w.style.width = px(CW - 4); w.style.height = px(CH - 4);
    }
  }
  function focusWin(key) {
    activeKey = key;
    Object.keys(wins).forEach(function (k) { wins[k].classList.toggle('active', k === key); });
    wins[key].style.zIndex = ++zTop;
    renderTasks();
  }
  function dragStart(e, key) {
    var w = wins[key]; if (!w || w.dataset.max === '1') return;
    var sx = e.clientX, sy = e.clientY, ox = parseFloat(w.style.left), oy = parseFloat(w.style.top);
    function mv(ev) {
      var x = (ev.touches ? ev.touches[0].clientX : ev.clientX), y = (ev.touches ? ev.touches[0].clientY : ev.clientY);
      w.style.left = px(Math.max(0, Math.min(CW - 100, ox + (x - sx) / scale)));
      w.style.top = px(Math.max(0, Math.min(CH - 40, oy + (y - sy) / scale)));
    }
    function up() { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up);
      document.removeEventListener('touchmove', mv); document.removeEventListener('touchend', up); }
    document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    document.addEventListener('touchmove', mv, { passive: true }); document.addEventListener('touchend', up);
  }
  function renderTasks() {
    if (!tasklist) return;
    tasklist.innerHTML = '';
    Object.keys(wins).forEach(function (k) {
      var b = el('button', 'task' + (wins[k].classList.contains('active') ? ' on' : ''), CD.esc(S.forms[k].title));
      b.addEventListener('click', function () {
        if (wins[k].classList.contains('min')) { wins[k].classList.remove('min'); focusWin(k); }
        else if (wins[k].classList.contains('active')) wins[k].classList.add('min');
        else focusWin(k);
        renderTasks();
      });
      tasklist.appendChild(b);
    });
  }

  /* 勋章窗体：exe 里是运行时动态生成的图标网格，不是静态控件 */
  function buildMedals(f) {
    var idx = -1;
    f.controls.forEach(function (c, i) { if (c.n === '_Panel' && c.w > 300) idx = i; });
    var p = ST.awd && ST.awd.nodes[idx]; if (!p) return;
    var M = CD.data.medals;
    p.style.pointerEvents = 'auto'; p.style.zIndex = '3';
    p.innerHTML = '<div class="medalgrid">' + M.map(function (m) {
      return '<button class="med" data-m="' + m[0] + '" title="' + CD.esc(m[1]) + '">' + m[0] + '</button>';
    }).join('') + '</div>';
    p.addEventListener('click', function (e) {
      var b = e.target.closest('[data-m]'); if (!b) return;
      qa('.med.on', p).forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      var m = CD.idx.medals.get(+b.dataset.m); if (!m) return;
      updatePicture('awd', { _kind: 'awd', _id: m[0], '勋章': m[1], '说明': m[2] });
      setMsg(m[1]);
    });
  }

  /* ---------------- 缩放 ---------------- */
  function applyScale(s) {
    scale = Math.max(0.28, Math.min(2.4, s));
    world.style.transform = 'scale(' + scale + ')';
    canvas.style.width = px(CW * scale); canvas.style.height = px(CH * scale);
    q('#zoom-val').textContent = Math.round(scale * 100) + '%';
  }
  function fitScale() {
    var w = desktop.clientWidth, h = desktop.clientHeight;
    applyScale(Math.min((w - 8) / CW, (h - 8) / CH));
  }
  /* 手机：按「当前窗口」而非整个 1100px 桌面适应，字体才可读 */
  function fitWindow(key) {
    var f = S.forms[key || activeKey]; if (!f) return fitScale();
    var w = desktop.clientWidth, h = desktop.clientHeight;
    var s = Math.min((w - 8) / (f.w + 16), (h - 8) / (f.h + 70));
    applyScale(Math.max(0.3, Math.min(1.2, s)));
  }
  /* 手机上双指缩放：默认 fit 只求看到全貌，放大后才便于阅读原版字号 */
  function bindPinch() {
    var d0 = 0, s0 = 1;
    function dist(t) {
      var dx = t[0].clientX - t[1].clientX, dy = t[0].clientY - t[1].clientY;
      return Math.sqrt(dx * dx + dy * dy);
    }
    desktop.addEventListener('touchstart', function (e) {
      if (e.touches.length === 2) { d0 = dist(e.touches); s0 = scale; }
    }, { passive: true });
    desktop.addEventListener('touchmove', function (e) {
      if (e.touches.length === 2 && d0 > 0) {
        e.preventDefault();
        window.__autoFit = false;
        applyScale(s0 * dist(e.touches) / d0);
      }
    }, { passive: false });
    desktop.addEventListener('touchend', function (e) {
      if (e.touches.length < 2) d0 = 0;
    }, { passive: true });
  }

  /* ---------------- 启动 ---------------- */
  function boot() {
    canvas = q('#canvas'); desktop = q('#desktop'); tasklist = q('#tasklist'); startmenu = q('#startmenu');
    world = el('div'); world.id = 'world';
    world.style.cssText = 'position:absolute;left:0;top:0;width:' + CW + 'px;height:' + CH + 'px;transform-origin:0 0';
    canvas.appendChild(world);

    CD.load(function (n) { var m = q('#ld-msg'); if (m) m.textContent = '载入 ' + n + '.json'; })
      .then(function (spec) {
        S = spec;
        // 开始菜单
        var box = q('#sm-items');
        [['主窗口', 'main']].concat(S.order.map(function (k) { return [S.btnCn[k] || k, k]; }))
          .forEach(function (it) {
            var b = el('button', '', CD.esc(it[0]));
            b.addEventListener('click', function () { open(it[1]); startmenu.hidden = true; });
            box.appendChild(b);
          });
        q('#start').addEventListener('click', function (e) { e.stopPropagation(); startmenu.hidden = !startmenu.hidden; });
        document.addEventListener('click', function (e) {
          if (!e.target.closest('#startmenu') && !e.target.closest('#start')) startmenu.hidden = true;
        });
        q('#zoom-in').addEventListener('click', function () { window.__autoFit = false; applyScale(scale + 0.1); });
        q('#zoom-out').addEventListener('click', function () { window.__autoFit = false; applyScale(scale - 0.1); });
        q('#zoom-fit').addEventListener('click', function () {
          window.__autoFit = true;
          if (window.innerWidth < 760) fitWindow(activeKey); else fitScale();
        });
        q('#zoom-11').addEventListener('click', function () {
          window.__autoFit = false; applyScale(1);
          desktop.scrollLeft = 0; desktop.scrollTop = 0;
          setMsg('已按原程序 1:1 显示 · 可拖动桌面查看窗口');
        });
        window.addEventListener('resize', function () {
          if (window.__autoFit === false) return;
          if (window.innerWidth < 760) fitWindow(activeKey); else fitScale();
        });
        bindPinch();
        q('#loading').remove();
        open('main');
        // 手机默认按宽度适应；桌面 1:1
        if (window.innerWidth < 760) { window.__autoFit = true; fitWindow('main'); }
        else { window.__autoFit = false; applyScale(1); }
        // 支持 classic.html?open=wpn 直达某个功能窗体
        var direct = new URLSearchParams(location.search).get('open');
        if (direct && S.forms[direct]) open(direct);
        setMsg('就绪 · ' + S.forms.main.controls.length + ' 个主窗体控件 / ' + Object.keys(S.tables).length + ' 张表格定义'
          + (window.innerWidth < 760 ? ' · 点「1:1」或双指放大阅读' : ''));
      }).catch(function (e) {
        var m = q('#ld-msg'); if (m) m.textContent = '载入失败：' + e;
        console.error(e);
      });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
