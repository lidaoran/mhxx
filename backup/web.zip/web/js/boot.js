/* 启动 */
(function () {
  const A = window.A;

  A.$('#btn-back').addEventListener('click', () => A.back());
  A.$$('#tabs button').forEach(b => b.addEventListener('click', () => A.go(b.dataset.nav)));
  A.$('#sheet-close').addEventListener('click', () => A.closeSheet());
  A.$('#mask').addEventListener('click', e => { if (e.target.id === 'mask') A.closeSheet(); });
  A.$('#q-clear').addEventListener('click', () => {
    const q = A.$('#q');
    q.value = '';
    if (A.searchHandler) A.searchHandler('');
    q.focus();
  });

  let timer = null;
  A.$('#q').addEventListener('input', e => {
    const v = e.target.value;
    clearTimeout(timer);
    timer = setTimeout(() => { if (A.searchHandler) A.searchHandler(v); }, 160);
  });

  window.addEventListener('hashchange', () => A.render());
  window.addEventListener('error', e => {
    console.error(e.error || e.message);
  });

  // 安装提示
  let deferred = null;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault(); deferred = e;
    const b = A.$('#btn-install');
    b.hidden = false;
    b.addEventListener('click', () => { deferred.prompt(); deferred = null; b.hidden = true; });
  });

  // 返回键关闭弹层
  document.addEventListener('keydown', e => { if (e.key === 'Escape') A.closeSheet(); });

  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    navigator.serviceWorker.register('sw.js').catch(() => { });
  }

  A.render();
})();
