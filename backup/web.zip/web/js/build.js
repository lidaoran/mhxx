/* 配装：套装模拟器 / 套装配装器 / 我的护石 */
(function () {
  const A = window.A;
  const PARTS = ['头', '胸', '腕', '腰', '脚'];
  const LS_SETS = 'mhxx.sets', LS_CHARM = 'mhxx.charms', LS_CUR = 'mhxx.cur';
  const store = {
    get(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  };
  A.store = store;

  function emptySet() {
    return { name: '', weapon: 0, armor: [0, 0, 0, 0, 0], charm: { s1: null, s2: null, slots: 0 }, deco: {}, torso: false };
  }
  A.emptySet = emptySet;

  function setSkills(s) {
    const W = A.data.weapons ? A.byId('weapons') : null;
    const AR = A.byId('armor');
    const pts = new Map();
    const add = (tid, p) => pts.set(tid, (pts.get(tid) || 0) + p);
    s.armor.forEach((id, i) => {
      if (!id) return;
      const a = AR.get(id);
      if (a) a[12].forEach(([t, p]) => add(t, p * (s.torso && i === 1 ? 2 : 1)));
    });
    if (s.charm) {
      [s.charm.s1, s.charm.s2].forEach(c => {
        if (!c || !c.t) return;
        const t = A.data.skills.trees.find(x => x[0] === c.t);
        if (!t) return;
        const levels = t[2].filter(x => x > 0);
        add(c.t, levels[Math.min(c.lv, levels.length) - 1] || 0);
      });
    }
    // 装饰品
    Object.keys(s.deco || {}).forEach(k => {
      (s.deco[k] || []).forEach(jid => {
        if (!jid) return;
        const j = A.data.jewels.find(x => x[0] === jid);
        if (j) j[4].forEach(([t, p]) => add(t, p));
      });
    });
    return pts;
  }
  A.setSkills = setSkills;

  function setSlots(s) {
    const AR = A.byId('armor'), W = A.byId('weapons');
    const out = [];
    const w = s.weapon ? W.get(s.weapon) : null;
    out.push({ key: 'w', label: '武器', n: w ? w[8] : 0 });
    s.armor.forEach((id, i) => {
      const a = id ? AR.get(id) : null;
      out.push({ key: 'a' + i, label: PARTS[i], n: a ? a[4] : 0 });
    });
    out.push({ key: 'c', label: '护石', n: s.charm ? s.charm.slots : 0 });
    out.forEach(o => { o.used = (s.deco[o.key] || []).slice(0, o.n); });
    return out;
  }
  A.setSlots = setSlots;

  function setStats(s) {
    const AR = A.byId('armor'), W = A.byId('weapons');
    let def = 0, max = 0, res = [0, 0, 0, 0, 0];
    s.armor.forEach(id => {
      const a = id ? AR.get(id) : null;
      if (!a) return;
      def += a[5]; max += a[6];
      a[7].forEach((v, i) => { res[i] += v; });
    });
    if (s.weapon) { const w = W.get(s.weapon); if (w) { def += w[7]; max += w[7]; } }
    return { def, max, res };
  }
  A.setStats = setStats;

  function setMaterials(s) {
    const out = new Map();
    const add = list => list.forEach(([id, q]) => out.set(id, (out.get(id) || 0) + q));
    if (s.weapon) add(A.data.recipes['w' + s.weapon] || []);
    s.armor.forEach(id => { if (id) add(A.data.recipes['a' + id] || []); });
    return Array.from(out.entries());
  }

  /* ---------- 自动配珠 ---------- */
  function autoJewels(s, targets) {
    const slots = setSlots(s);
    const pts = setSkills(s);
    // 目标缺口：优先把技能堆到最高等级，其次补目标技能
    const want = new Map();
    (targets || []).forEach(([tid, lv]) => {
      const t = A.data.skills.trees.find(x => x[0] === tid);
      if (!t) return;
      const levels = t[2].filter(x => x > 0);
      want.set(tid, levels[Math.min(lv, levels.length) - 1] || 0);
    });
    const J = A.data.jewels;
    const deco = {};
    slots.forEach(sl => {
      if (!sl.n) return;
      const arr = [];
      for (let i = 0; i < sl.n; i++) {
        // 找当前缺口最大的技能
        let best = null, bestScore = 0;
        J.forEach(j => {
          if (j[2] > sl.n) return;
          let score = 0;
          j[4].forEach(([t, p]) => {
            const cur = pts.get(t) || 0;
            const goal = want.get(t);
            if (goal != null) {
              const need = goal - cur;
              if (need > 0) score += Math.min(p, need) * 10;
            } else {
              const tr = A.data.skills.trees.find(x => x[0] === t);
              if (tr) {
                const levels = tr[2].filter(x => x > 0);
                const nxt = levels.find(L => L > cur);
                if (nxt != null && cur + p >= nxt) score += 4;   // 能凑出一级
                score += p * 0.3;
              }
            }
          });
          if (score > bestScore) { bestScore = score; best = j; }
        });
        if (!best) break;
        arr.push(best[0]);
        best[4].forEach(([t, p]) => pts.set(t, (pts.get(t) || 0) + p));
      }
      deco[sl.key] = arr;
    });
    s.deco = deco;
    return s;
  }
  A.autoJewels = autoJewels;

  /* ---------- 技能面板 ---------- */
  function skillPanel(s, targets) {
    const pts = setSkills(s);
    const list = [];
    pts.forEach((p, tid) => {
      if (!p) return;
      const lv = A.skillLevel(tid, p);
      list.push({ tid, p, lv });
    });
    list.sort((a, b) => (b.lv.lv - a.lv.lv) || (b.p - a.p));
    if (!list.length) return '<div class="empty">还没有配装</div>';
    return `<table class="grid skl"><tbody>${list.map(x => {
      const goal = (targets || []).find(t => t[0] === x.tid);
      const cls = goal ? 'hl' : '';
      return `<tr class="${cls}" data-skl="${x.tid}"><td class="nm3">${A.esc(x.lv.name)}</td>
        <td class="num ${x.lv.lv > 0 ? 'res-p' : 'res-n'}">${x.lv.lv > 0 ? 'Lv.' + x.lv.lv : (x.p > 0 ? '未发动' : '')}</td>
        <td class="num dim">${x.p > 0 ? '+' + x.p : x.p}</td></tr>`;
    }).join('')}</tbody></table>`;
  }
  A.skillPanel = skillPanel;

  /* ================= 套装模拟器 ================= */
  A.route('sim', {
    title: '套装模拟器', sub: '手动配装 + 技能计算', nav: 'sim',
    load: ['armor', 'weapons', 'jewels', 'skills', 'recipes', 'items', 'item_icons', 'labels'],
    mount(view, params) {
      let s = store.get(LS_CUR, null) || emptySet();
      if (params.load) {
        const sets = store.get(LS_SETS, []);
        const got = sets.find(x => x.id === params.load);
        if (got) s = JSON.parse(JSON.stringify(got.set));
      }
      const AR = A.byId('armor'), W = A.byId('weapons');
      view.innerHTML = `<div id="sim-body"></div>`;
      const body = A.$('#sim-body');
      A.setTitle('套装模拟器', '手动配装 + 技能计算');

      function save() { store.set(LS_CUR, s); }

      /* 对应原程序 _TextBox_Code / _Button_CalcByCode：
         把整套配装编码成一段文本，可跨设备分享 / 导入 */
      function encodeSet(x) {
        const bytes = new TextEncoder().encode(JSON.stringify(x));
        let bin = '';
        for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
        return 'MHXX1' + btoa(bin);
      }
      function decodeSet(txt) {
        const b = String(txt || '').trim().replace(/^MHXX1\s*/, '');
        const bin = atob(b);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const o = JSON.parse(new TextDecoder().decode(bytes));
        if (!o || !Array.isArray(o.armor) || o.armor.length !== 5) throw new Error('bad set');
        return Object.assign(emptySet(), o);
      }
      function codeSheet(mode) {
        if (mode === 'export') {
          const code = encodeSet(s);
          A.sheet('导出套装码', `<div class="pad">
            <div class="dim2 mb8">复制这段码，在另一台设备打开「套装模拟器 → 导入码」即可还原同一套配装。</div>
            <textarea id="setcode" class="codearea" rows="5" readonly>${A.esc(code)}</textarea>
            <button class="btn full mt8" id="copycode">复制套装码</button>
            <div class="dim2 mt8">本网页自定义格式（记录武器 / 5 部位 / 护石 / 各孔装饰品 / 胴系统倍加），与原 exe 的套装码不通用。</div></div>`);
          A.$('#sheet-live').addEventListener('click', e => {
            if (!e.target.closest('#copycode')) return;
            const ta = A.$('#setcode');
            ta.select();
            try { document.execCommand('copy'); A.toast('已复制'); }
            catch (err) { A.toast('请长按选择复制'); }
          });
        } else {
          A.sheet('导入套装码', `<div class="pad">
            <div class="dim2 mb8">粘贴以 MHXX1 开头的套装码：</div>
            <textarea id="setcode" class="codearea" rows="5" placeholder="MHXX1…"></textarea>
            <button class="btn full mt8" id="loadcode">导入并覆盖当前配装</button></div>`);
          A.$('#sheet-live').addEventListener('click', e => {
            if (!e.target.closest('#loadcode')) return;
            try {
              const next = decodeSet(A.$('#setcode').value);
              s = next; save(); A.closeSheet(); paint(); A.toast('配装已导入');
            } catch (err) { A.toast('套装码无效'); }
          });
        }
      }

      function paint() {
        const st = setStats(s);
        const slots = setSlots(s);
        const used = slots.reduce((n, x) => n + (x.used || []).filter(Boolean).length, 0);
        const total = slots.reduce((n, x) => n + x.n, 0);

        let h = `<div class="sim-top six">
          <button class="btn ghost sm" data-act="auto">自动配珠</button>
          <button class="btn ghost sm" data-act="clear">清空</button>
          <button class="btn ghost sm" data-act="save">保存配装</button>
          <button class="btn ghost sm" data-act="load">载入</button>
          <button class="btn ghost sm" data-act="export">导出码</button>
          <button class="btn ghost sm" data-act="import">导入码</button>
        </div>`;

        h += `<div class="card">`;
        // 武器
        const w = s.weapon ? W.get(s.weapon) : null;
        h += slotRow('w', '武器', w ? w[2] : '', slots[0], w ? A.wpnImg(w[10]) : '', 'w');
        s.armor.forEach((id, i) => {
          const a = id ? AR.get(id) : null;
          h += slotRow('a' + i, PARTS[i], a ? a[2] : '', slots[i + 1], a ? A.amrImg(a[10]) : '', 'a');
        });
        h += charmRow(s, slots[5]);
        h += `</div>`;

        h += `<div class="card"><div class="stat-grid four">
          ${A.stat('防御', st.def)}${A.stat('最大防御', st.max)}${A.stat('孔位', used + '/' + total)}
          <div class="stat"><div class="k">耐性</div><div class="v res-mini">${st.res.map((v, i) =>
          `<span class="${v > 0 ? 'res-p' : v < 0 ? 'res-n' : 'dim'}">${RESN[i]}${v > 0 ? '+' : ''}${v}</span>`).join('')}</div></div>
        </div></div>`;

        h += `<label class="togglerow"><input type="checkbox" id="torso" ${s.torso ? 'checked' : ''}> 胴系統倍加（胸部技能点×2）</label>`;

        h += A.card(A.sec('发动技能') + `<div id="sklbox">${skillPanel(s)}</div>`);
        const mats = setMaterials(s);
        if (mats.length) h += A.matTable(mats, '所需素材');

        body.innerHTML = h;

        body.querySelector('#torso').addEventListener('change', e => { s.torso = e.target.checked; save(); paint(); });
      }

      function slotRow(key, label, name, slot, img, kind) {
        const deco = (s.deco[key] || []);
        let dots = '';
        for (let i = 0; i < slot.n; i++) {
          const jid = deco[i];
          const j = jid ? A.data.jewels.find(x => x[0] === jid) : null;
          dots += `<button class="deco ${j ? 'on' : ''}" data-deco="${key}:${i}" title="${j ? A.esc(j[1]) : '空孔'}">${j ? j[1].replace(/【.*】/, '').replace('珠', '') : ''}</button>`;
        }
        return `<div class="slotrow" data-slot="${key}">
          ${img ? `<img class="simg" src="${img}" alt="">` : `<span class="simg ph">${label}</span>`}
          <button class="pick ${name ? '' : 'placeholder'}" data-pick="${key}">${name ? A.esc(name) : '选择' + label}</button>
          <div class="slots">${dots}</div>
          ${name ? `<button class="xbtn" data-clear="${key}">×</button>` : ''}
        </div>`;
      }

      function charmRow(s, slot) {
        const c = s.charm || { s1: null, s2: null, slots: 0 };
        const nm = x => {
          if (!x || !x.t) return '—';
          const t = A.data.skills.trees.find(y => y[0] === x.t);
          return `${t ? t[1] : ''} Lv.${x.lv}`;
        };
        let dots = '';
        for (let i = 0; i < (c.slots || 0); i++) {
          const jid = (s.deco.c || [])[i];
          const j = jid ? A.data.jewels.find(x => x[0] === jid) : null;
          dots += `<button class="deco ${j ? 'on' : ''}" data-deco="c:${i}">${j ? j[1].replace(/【.*】/, '').replace('珠', '') : ''}</button>`;
        }
        return `<div class="slotrow" data-slot="c">
          <span class="simg ch">护</span>
          <button class="pick ${c.s1 ? '' : 'placeholder'}" data-charm="1">${A.esc(nm(c.s1))}${c.s2 ? ' / ' + A.esc(nm(c.s2)) : ''}</button>
          <div class="slots">${dots}</div>
          ${(c.s1 || c.s2 || c.slots) ? `<button class="xbtn" data-clear="c">×</button>` : ''}
        </div>`;
      }

      body.addEventListener('click', e => {
        const t = e.target;
        const act = t.closest('[data-act]');
        if (act) {
          const a = act.dataset.act;
          if (a === 'auto') { autoJewels(s); save(); paint(); A.toast('已自动配珠'); }
          if (a === 'clear') { s = emptySet(); save(); paint(); }
          if (a === 'save') return saveSheet(s, paint);
          if (a === 'load') return loadSheet(paint);
          if (a === 'export') return codeSheet('export');
          if (a === 'import') return codeSheet('import');
          return;
        }
        const pick = t.closest('[data-pick]');
        if (pick) {
          const key = pick.dataset.pick;
          if (key === 'w') return pickWeapon(id => { s.weapon = id; save(); paint(); });
          return pickArmor(+key.slice(1), id => { s.armor[+key.slice(1)] = id; save(); paint(); });
        }
        const ch = t.closest('[data-charm]');
        if (ch) return charmSheet(s, () => { save(); paint(); });
        const dc = t.closest('[data-deco]');
        if (dc) {
          const [key, i] = dc.dataset.deco.split(':');
          return decoSheet(s, key, +i, () => { save(); paint(); });
        }
        const cl = t.closest('[data-clear]');
        if (cl) {
          const k = cl.dataset.clear;
          if (k === 'c') s.charm = { s1: null, s2: null, slots: 0 };
          else if (k === 'w') s.weapon = 0;
          else s.armor[+k.slice(1)] = 0;
          delete s.deco[k];
          save(); paint();
        }
      });
      paint();
    }
  });
  const RESN = ['火', '水', '雷', '冰', '龙'];

  /* ---- 选武器 ---- */
  function pickWeapon(cb) {
    const W = A.data.weapons;
    let type = '0', kw = '';
    const box = document.createElement('div');
    box.innerHTML = `<div id="pw-head"></div><div id="pw-list"></div>`;
    const head = A.$('#pw-head', box), list = A.$('#pw-list', box);
    head.appendChild(A.chips([['0', '全部']].concat(A.TYPES.map((t, i) => [String(i + 1), t])), type, v => { type = v; paint(); }));
    A.sheet('选择武器', box.innerHTML);
    A.setSearch('搜索武器…', v => { kw = v.trim(); paint(); });
    const sb = A.$('#sheet-live');
    sb.innerHTML = '';
    sb.appendChild(head); sb.appendChild(list);
    function paint() {
      const arr = W.filter(w => (!+type || w[1] === +type) && (!kw || w[2].indexOf(kw) >= 0)).slice(0, 400);
      list.innerHTML = arr.map(w => `<div class="prow" data-w="${w[0]}">
        <img src="${A.wpnImg(w[10])}" alt="">
        <div class="grow"><div class="nm3">${A.esc(w[2])}</div><div class="dim2">攻 ${w[4]} · 孔 ${w[8]}</div></div></div>`).join('') ||
        '<div class="empty">没有结果</div>';
    }
    paint();
    sb.addEventListener('click', e => {
      const r = e.target.closest('[data-w]');
      if (r) { A.closeSheet(); A.setSearch(null); cb(+r.dataset.w); }
    });
  }
  A.pickWeapon = pickWeapon;

  /* ---- 选防具 ---- */
  function pickArmor(part, cb) {
    const AR = A.data.armor;
    let borg = '0', morf = '0', kw = '';
    const wrap = document.createElement('div');
    const head = document.createElement('div'), list = document.createElement('div');
    wrap.appendChild(head); wrap.appendChild(list);
    head.appendChild(A.row(A.select([['0', '性别不限'], ['1', '男性'], ['2', '女性']], morf, v => { morf = v; paint(); }),
      A.select([['0', '剑士/枪手'], ['1', '剑士'], ['2', '枪手']], borg, v => { borg = v; paint(); })));
    A.sheet('选择' + PARTS[part] + '部防具', '');
    const sb = A.$('#sheet-live');
    sb.innerHTML = ''; sb.appendChild(wrap);
    A.setSearch('搜索防具…', v => { kw = v.trim(); paint(); });
    function paint() {
      const arr = AR.filter(a => a[1] === part + 1 && (!+borg || a[8] === 0 || a[8] === +borg) && (!+morf || a[9] === 0 || a[9] === +morf)
        && (!kw || a[2].indexOf(kw) >= 0)).slice(0, 300);
      list.innerHTML = arr.map(a => `<div class="prow" data-a="${a[0]}">
        <img src="${A.amrImg(a[10])}" alt="">
        <div class="grow"><div class="nm3">${A.esc(a[2])}</div>
        <div class="dim2">防 ${a[5]} · ${a[12].map(([t, p]) => {
        const tr = A.data.skills.trees.find(x => x[0] === t);
        return (tr ? tr[1] : '') + (p > 0 ? '+' : '') + p;
      }).join(' ')}</div></div>
        <span class="pillslot">${A.slotHtml(a[4])}</span></div>`).join('') || '<div class="empty">没有结果</div>';
    }
    paint();
    sb.addEventListener('click', e => {
      const r = e.target.closest('[data-a]');
      if (r) { A.closeSheet(); A.setSearch(null); cb(+r.dataset.a); }
    });
  }

  /* ---- 护石 ---- */
  function charmSheet(s, done) {
    const trees = A.data.skills.trees;
    const my = store.get(LS_CHARM, []);
    const c = s.charm || { s1: null, s2: null, slots: 0 };
    const opt = [[0, '无']].concat(trees.map(t => [t[0], t[1]]));
    let h = `<div class="pad">
      <div class="frow"><span>技能 1</span>${selHtml('c1', opt, c.s1 ? c.s1.t : 0)}${lvHtml('c1l', c.s1 ? c.s1.lv : 1)}</div>
      <div class="frow"><span>技能 2</span>${selHtml('c2', opt, c.s2 ? c.s2.t : 0)}${lvHtml('c2l', c.s2 ? c.s2.lv : 1)}</div>
      <div class="frow"><span>孔位</span><div class="seg" id="cslot">${[0, 1, 2, 3].map(n => `<button data-n="${n}" class="${c.slots === n ? 'on' : ''}">${n}</button>`).join('')}</div></div>
      <div class="hint">护石可以自己定义：选技能与等级，孔位数 0–3。</div>
      <div class="sim-top mt12"><button class="btn sm" id="c-ok">确定</button><button class="btn ghost sm" id="c-my">从我的护石选择</button></div></div>`;
    if (my.length) h += `<div class="card">${A.sec('我的护石')}${my.map((x, i) =>
      `<div class="prow" data-my="${i}"><div class="grow"><div class="nm3">${x.label}</div><div class="dim2">${x.slots} 孔</div></div></div>`).join('')}</div>`;
    A.sheet('护石', h);
    const sb = A.$('#sheet-live');
    let slots = c.slots || 0;
    sb.querySelector('#cslot').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      slots = +b.dataset.n;
      A.$$('#cslot button', sb).forEach(x => x.classList.toggle('on', x === b));
    });
    sb.addEventListener('click', e => {
      const m = e.target.closest('[data-my]');
      if (m) {
        const x = my[+m.dataset.my];
        s.charm = JSON.parse(JSON.stringify(x.charm));
        A.closeSheet(); done(); return;
      }
      if (e.target.id === 'c-ok') {
        const v1 = +A.$('#c1', sb).value, l1 = +A.$('#c1l', sb).value;
        const v2 = +A.$('#c2', sb).value, l2 = +A.$('#c2l', sb).value;
        s.charm = {
          s1: v1 ? { t: v1, lv: l1 } : null,
          s2: v2 ? { t: v2, lv: l2 } : null,
          slots: slots
        };
        A.closeSheet(); done();
      }
    });
  }
  function selHtml(id, items, val) {
    return `<select id="${id}" class="sel">${items.map(([k, t]) => `<option value="${k}"${k === val ? ' selected' : ''}>${t}</option>`).join('')}</select>`;
  }
  function lvHtml(id, val) {
    return `<select id="${id}" class="sel tiny">${[1, 2, 3, 4, 5, 6, 7].map(n => `<option ${n === val ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
  }

  /* ---- 装饰品分配 ---- */
  function decoSheet(s, key, idx, done) {
    const slots = setSlots(s);
    const sl = slots.find(x => x.key === key);
    const size = sl ? sl.n : 1;
    const J = A.data.jewels.filter(j => j[2] <= size);
    let h = `<div class="pad dim">孔位大小：${size} 孔</div><div class="deco-list">` +
      `<div class="prow" data-j="0"><div class="grow"><div class="nm3">不装</div></div></div>` +
      J.map(j => `<div class="prow" data-j="${j[0]}"><div class="grow"><div class="nm3">${A.esc(j[1])}</div>
        <div class="dim2">${j[4].map(([t, p]) => { const tr = A.data.skills.trees.find(x => x[0] === t); return (tr ? tr[1] : '') + ' +' + p; }).join(' ')}</div></div></div>`).join('') + '</div>';
    A.sheet('选择装饰品', h);
    A.$('#sheet-live').addEventListener('click', e => {
      const r = e.target.closest('[data-j]');
      if (!r) return;
      const jid = +r.dataset.j;
      const arr = (s.deco[key] || []).slice();
      while (arr.length < size) arr.push(0);
      arr[idx] = jid;
      s.deco[key] = arr;
      A.closeSheet(); done();
    });
  }

  /* ---- 保存 / 载入 ---- */
  function saveSheet(s, done) {
    const name = prompt('配装名称', s.name || ('配装 ' + new Date().toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })));
    if (!name) return;
    const sets = store.get(LS_SETS, []);
    sets.unshift({ id: 's' + Date.now(), name, set: JSON.parse(JSON.stringify(s)) });
    store.set(LS_SETS, sets.slice(0, 100));
    s.name = name; store.set(LS_CUR, s);
    A.toast('已保存');
    if (done) done();
  }
  function loadSheet(done) {
    const sets = store.get(LS_SETS, []);
    if (!sets.length) return A.toast('还没有保存的配装');
    A.sheet('载入配装', sets.map(x => `<div class="prow" data-load="${x.id}">
      <div class="grow"><div class="nm3">${A.esc(x.name)}</div></div><button class="xbtn" data-del="${x.id}">×</button></div>`).join(''));
    A.$('#sheet-live').addEventListener('click', e => {
      const del = e.target.closest('[data-del]');
      if (del) {
        const rest = store.get(LS_SETS, []).filter(x => x.id !== del.dataset.del);
        store.set(LS_SETS, rest); A.closeSheet(); A.toast('已删除'); return;
      }
      const l = e.target.closest('[data-load]');
      if (l) { A.closeSheet(); A.go('sim', { load: l.dataset.load }); }
    });
  }

  /* ================= 我的护石 ================= */
  A.route('charms', {
    title: '我的护石', sub: '自己录入的护石', load: ['skills'],
    mount(view) {
      const trees = A.data.skills.trees;
      function label(c) {
        const nm = x => {
          if (!x || !x.t) return '';
          const t = trees.find(y => y[0] === x.t);
          return (t ? t[1] : '') + ' Lv.' + x.lv;
        };
        return [nm(c.s1), nm(c.s2)].filter(Boolean).join(' / ') || '空护石';
      }
      function paint() {
        const my = store.get(LS_CHARM, []);
        view.innerHTML = `<div class="sim-top"><button class="btn sm" id="add">添加护石</button>
          <button class="btn ghost sm" id="imp">从模拟器当前护石导入</button></div>
          ${my.length ? my.map((x, i) => `<div class="card prow"><div class="grow">
            <div class="nm3">${A.esc(x.label)}</div><div class="dim2">${x.slots} 孔</div></div>
            <button class="xbtn" data-del="${i}">×</button></div>`).join('') : '<div class="empty">还没有录入护石<br><span class="dim">配装时可以直接定义护石，也可以存到这里复用</span></div>'}`;
        view.querySelector('#add').addEventListener('click', () => edit(null, paint));
        view.querySelector('#imp').addEventListener('click', () => {
          const cur = store.get(LS_CUR, null);
          if (!cur || !cur.charm || (!cur.charm.s1 && !cur.charm.s2)) return A.toast('模拟器里还没有设置护石');
          const my2 = store.get(LS_CHARM, []);
          my2.unshift({ label: label(cur.charm), charm: JSON.parse(JSON.stringify(cur.charm)), slots: cur.charm.slots || 0 });
          store.set(LS_CHARM, my2); paint(); A.toast('已导入');
        });
      }
      function edit(idx, done) {
        const my = store.get(LS_CHARM, []);
        const cur = idx != null ? my[idx] : { label: '', charm: { s1: null, s2: null, slots: 0 }, slots: 0 };
        const opt = [[0, '无']].concat(trees.map(t => [t[0], t[1]]));
        A.sheet(idx != null ? '编辑护石' : '添加护石', `<div class="pad">
          <div class="frow"><span>技能 1</span>${selHtml('e1', opt, cur.charm.s1 ? cur.charm.s1.t : 0)}${lvHtml('e1l', cur.charm.s1 ? cur.charm.s1.lv : 1)}</div>
          <div class="frow"><span>技能 2</span>${selHtml('e2', opt, cur.charm.s2 ? cur.charm.s2.t : 0)}${lvHtml('e2l', cur.charm.s2 ? cur.charm.s2.lv : 1)}</div>
          <div class="frow"><span>孔位</span><div class="seg" id="eslot">${[0, 1, 2, 3].map(n => `<button data-n="${n}" class="${cur.slots === n ? 'on' : ''}">${n}</button>`).join('')}</div></div>
          <button class="btn full mt12" id="eok">保存</button></div>`);
        const sb = A.$('#sheet-live');
        let slots = cur.slots || 0;
        sb.querySelector('#eslot').addEventListener('click', e => {
          const b = e.target.closest('button'); if (!b) return;
          slots = +b.dataset.n; A.$$('#eslot button', sb).forEach(x => x.classList.toggle('on', x === b));
        });
        sb.addEventListener('click', e => {
          if (e.target.id !== 'eok') return;
          const v1 = +A.$('#e1', sb).value, l1 = +A.$('#e1l', sb).value;
          const v2 = +A.$('#e2', sb).value, l2 = +A.$('#e2l', sb).value;
          const charm = { s1: v1 ? { t: v1, lv: l1 } : null, s2: v2 ? { t: v2, lv: l2 } : null, slots };
          const item = { label: label(charm), charm, slots };
          if (idx != null) my[idx] = item; else my.unshift(item);
          store.set(LS_CHARM, my);
          A.closeSheet();
          A.toast('已保存');
          if (done) done();
        });
      }
      // 只绑定一次；放在 paint 里会随每次重绘叠加监听器
      view.addEventListener('click', e => {
        const d = e.target.closest('[data-del]');
        if (!d) return;
        const my2 = store.get(LS_CHARM, []);
        my2.splice(+d.dataset.del, 1);
        store.set(LS_CHARM, my2);
        paint();
      });
      paint();
    }
  });

  /* ================= 套装配装器 ================= */
  A.route('finder', {
    title: '套装配装器', sub: '按技能自动搜索套装',
    load: ['armor', 'weapons', 'jewels', 'skills', 'recipes', 'items', 'item_icons', 'labels'],
    mount(view) {
      const AR = A.data.armor, J = A.data.jewels;
      const armById = new Map(AR.map(a => [a[0], a]));
      const jewById = new Map(J.map(j => [j[0], j]));
      let gender = '0', borg = '0', wslot = '0';
      let targets = [];   // [treeId, lv]
      let charmSlots = '0', fcharm = null;
      let noNeg = false;   // 原程序 _CheckBox_NoNegativeSkill：排除会产生负面技能的套装
      let results = [], running = false;

      view.innerHTML = `<div class="card" id="f-cond"></div>
        <div class="card" id="f-target"></div>
        <div class="sim-top"><button class="btn" id="f-go">开始搜索</button>
        <button class="btn ghost" id="f-reset">重置</button></div>
        <div id="f-result"></div>`;
      const cond = view.querySelector('#f-cond'), tgt = view.querySelector('#f-target'), res = view.querySelector('#f-result');

      // 用事件委托处理所有 seg
      view.addEventListener('click', e => {
        const b = e.target.closest('.seg button');
        if (!b) return;
        const seg = b.parentElement;
        A.$$('button', seg).forEach(x => x.classList.remove('on'));
        b.classList.add('on');
        const group = seg.dataset.g;
        if (group === 'gender') gender = b.dataset.v;
        if (group === 'borg') borg = b.dataset.v;
        if (group === 'wslot') wslot = b.dataset.v;
        if (group === 'cslot') charmSlots = b.dataset.v;
      });

      function segHtml(g, val, items) {
        return `<div class="seg" data-g="${g}">${items.map(([k, t]) => `<button data-v="${k}" class="${k === val ? 'on' : ''}">${t}</button>`).join('')}</div>`;
      }
      function paintCond2() {
        cond.innerHTML = `<div class="pad">
          <div class="frow"><span>性别</span>${segHtml('gender', gender, [['0', '不限'], ['1', '男'], ['2', '女']])}</div>
          <div class="frow"><span>使用</span>${segHtml('borg', borg, [['0', '不限'], ['1', '剑士'], ['2', '枪手']])}</div>
          <div class="frow"><span>武器孔</span>${segHtml('wslot', wslot, [['0', '0'], ['1', '1'], ['2', '2'], ['3', '3']])}</div>
          <div class="frow"><span>护石孔</span>${segHtml('cslot', charmSlots, [['0', '0'], ['1', '1'], ['2', '2'], ['3', '3']])}</div>
          <div class="frow"><span>护石技能</span><button class="btn ghost sm" id="f-charm">${fcharm ? A.esc(charmLabel(fcharm)) : '不指定'}</button></div>
          <label class="togglerow"><input type="checkbox" id="f-noneg"${noNeg ? ' checked' : ''}> 排除负面技能（不出现负点数技能）</label>
          <div class="hint">护石技能会从目标里扣除；孔位可再装装饰品。</div></div>`;
      }
      paintCond2();

      function charmLabel(c) {
        const nm = x => {
          if (!x || !x.t) return '';
          const t = A.data.skills.trees.find(y => y[0] === x.t);
          return (t ? t[1] : '') + ' Lv.' + x.lv;
        };
        return [nm(c.s1), nm(c.s2)].filter(Boolean).join(' / ') || '无技能';
      }

      function paintTargets() {
        tgt.innerHTML = A.sec('搜索条件（' + targets.length + '）') + (targets.length ?
          `<table class="grid"><tbody>${targets.map(([tid, lv], i) => {
            const t = A.data.skills.trees.find(x => x[0] === tid);
            return `<tr><td>${A.esc(t ? t[1] : tid)}</td><td class="num dim">Lv.${lv}</td>
              <td class="num"><button class="xbtn" data-rm="${i}">×</button></td></tr>`;
          }).join('')}</tbody></table>` : '<div class="pad dim">还没有目标技能</div>')
          + `<div class="sim-top"><button class="btn ghost sm" id="f-add">+ 添加技能</button></div>`;
      }
      paintTargets();

      view.addEventListener('click', e => {
        const rm = e.target.closest('[data-rm]');
        if (rm) { targets.splice(+rm.dataset.rm, 1); paintTargets(); return; }
      });
      view.addEventListener('change', e => {
        if (e.target.id === 'f-noneg') noNeg = e.target.checked;
      });
      view.addEventListener('click', e => {
        if (e.target.id === 'f-charm') pickCharm();
        if (e.target.id === 'f-add') addSkill();
        if (e.target.id === 'f-go') run();
        if (e.target.id === 'f-reset') { targets = []; results = []; paintTargets(); res.innerHTML = ''; }
      });

      function pickCharm() {
        const my = store.get(LS_CHARM, []);
        let h = `<div class="prow" data-ch=""><div class="grow"><div class="nm3">不指定护石</div></div></div>`;
        h += my.map((x, i) => `<div class="prow" data-ch="${i}"><div class="grow"><div class="nm3">${A.esc(x.label)}</div><div class="dim2">${x.slots} 孔</div></div></div>`).join('');
        h += `<div class="pad"><button class="btn ghost full" id="ch-new">临时定义护石</button></div>`;
        A.sheet('选择护石', h);
        A.$('#sheet-live').addEventListener('click', e => {
          if (e.target.id === 'ch-new') {
            A.closeSheet();
            charmSheet({ charm: { s1: null, s2: null, slots: 0 } }, () => { });
            return;
          }
          const r = e.target.closest('[data-ch]');
          if (!r) return;
          fcharm = r.dataset.ch === '' ? null : JSON.parse(JSON.stringify(my[+r.dataset.ch].charm));
          if (fcharm) charmSlots = String(fcharm.slots || 0);
          A.closeSheet(); paintCond2();
        });
      }

      function addSkill() {
        const trees = A.data.skills.trees;
        const opt = trees.map(t => [t[0], t[1]]);
        A.sheet('添加目标技能', `<div class="pad">
          <div class="frow"><span>技能</span>${selHtml('tsel', opt, trees[0][0])}</div>
          <div class="frow"><span>目标等级</span><select id="tlv" class="sel tiny">${[1, 2, 3, 4, 5, 6, 7].map(n => `<option>${n}</option>`).join('')}</select></div>
          <button class="btn full mt12" id="tok">添加</button></div>`);
        A.$('#sheet-live').addEventListener('click', e => {
          if (e.target.id !== 'tok') return;
          const tid = +A.$('#tsel').value, lv = +A.$('#tlv').value;
          if (!targets.some(t => t[0] === tid)) targets.push([tid, lv]);
          else targets = targets.map(t => t[0] === tid ? [tid, lv] : t);
          A.closeSheet(); paintTargets();
        });
      }

      /* ---- 搜索 ---- */
      function candidates(part) {
        const g = +gender, b = +borg;
        return AR.filter(a => a[1] === part && (!g || a[9] === 0 || a[9] === g) && (!b || a[8] === 0 || a[8] === b));
      }

      function run() {
        if (!targets.length) return A.toast('先添加目标技能');
        if (running) return;
        running = true;
        res.innerHTML = '<div class="loading"><span></span>搜索中…</div>';
        setTimeout(() => {
          const t0 = performance.now();
          const need = targets.map(([tid, lv]) => {
            const t = A.data.skills.trees.find(x => x[0] === tid);
            const levels = t[2].filter(x => x > 0);
            return levels[Math.min(lv, levels.length) - 1] || 0;
          });
          const tidx = new Map(targets.map(([tid], i) => [tid, i]));
          // 护石提供的点数先从目标里扣掉
          if (fcharm) {
            [fcharm.s1, fcharm.s2].forEach(c => {
              if (!c || !c.t) return;
              const i = tidx.get(c.t);
              if (i == null) return;
              const t = A.data.skills.trees.find(x => x[0] === c.t);
              const levels = t[2].filter(x => x > 0);
              const p = levels[Math.min(c.lv, levels.length) - 1] || 0;
              need[i] = Math.max(0, need[i] - p);
            });
          }
          const cand = [0, 1, 2, 3, 4].map(p => {
            const list = candidates(p + 1).map(a => {
              const pts = new Array(targets.length).fill(0);
              let sum = 0, any = 0;
              a[12].forEach(([t, v]) => {
                const i = tidx.get(t);
                if (i != null && v > 0) { pts[i] = v; sum += v; any = 1; }
              });
              return { id: a[0], pts, any, def: a[5], max: a[6], slot: a[4], sum };
            }).filter(x => x.any);
            // 不再按技能向量去重（那会把同点数部件压成 1 件，导致结果全是同一套），
            // 改为按「技能点数和 → 孔位 → 防御」排序后取前 150 件，保留混装空间
            list.sort((x, y) => y.sum - x.sum || y.slot - x.slot || y.def - x.def);
            return list.slice(0, 150);
          });

          const wSlots = +wslot, cSlots = +charmSlots;
          const out = [];
          let nodes = 0;
          // 多收集一些解，最后再按「部位组合」去重取前 40，避免结果全是同一系列
          const LIMIT = 200000, COLLECT = 420, SHOW = 40;

          // 每个部位对各目标的最大贡献，用于剪枝
          const bnd = cand.map(list => {
            const m = new Array(targets.length).fill(0);
            list.forEach(x => x.pts.forEach((v, i) => { if (v > m[i]) m[i] = v; }));
            return m;
          });

          // 打散某个部位的候选顺序（步长跳跃 + 起点偏移）
          function makeWalk(part, shift) {
            const list = cand[part], n = list.length, ord = [], seen = new Uint8Array(n);
            if (!n) return ord;
            const step = [37, 41, 43, 47, 53][part] || 37;
            const base = (part * 23 + (shift || 0) * 13) % n;
            for (let k = 0; k < n; k++) {
              const i = (base + k * step) % n;
              if (!seen[i]) { seen[i] = 1; ord.push(i); }
            }
            for (let i = 0; i < n; i++) if (!seen[i]) ord.push(i);
            return ord;
          }
          const walk = cand.map((_, p) => makeWalk(p, 0));
          // 某部位没有任何带目标技能的部件时，用它占位（不能直接跳过，否则部位错位）
          const EMPTY = { id: 0, pts: new Array(targets.length).fill(0), def: 0, max: 0, slot: 0, sum: 0 };

          function tryJewels(pts, slots) {
            // 用装饰品补缺口；贪心
            const deficit = need.map((n, i) => Math.max(0, n - pts[i]));
            if (deficit.every(d => d === 0)) return { ok: true, used: [] };
            let left = slots;
            const used = [];
            const order = deficit.map((d, i) => i).filter(i => deficit[i] > 0).sort((a, b) => deficit[b] - deficit[a]);
            // 每个技能优先用点数大的珠子
            const bySkill = new Map();
            J.forEach(j => j[4].forEach(([t, p]) => {
              const i = tidx.get(t);
              if (i == null) return;
              if (!bySkill.has(i)) bySkill.set(i, []);
              bySkill.get(i).push({ j, p });
            }));
            for (const i of order) {
              let d = deficit[i];
              const list = (bySkill.get(i) || []).filter(x => x.p > 0).sort((a, b) => (b.p / b.j[2]) - (a.p / a.j[2]));
              while (d > 0 && list.length) {
                const pick = list.find(x => x.j[2] <= left);   // 孔位必须真的够
                if (!pick) break;
                used.push(pick.j[0]);
                left -= pick.j[2];
                d -= pick.p;
                if (left <= 0) break;
              }
              if (d > 0) return { ok: false };
            }
            return { ok: true, used };
          }

          let stopAt = 0;
          function dfs(part, pts, slotUsed, picked) {
            if (out.length >= stopAt || nodes > LIMIT) return;
            nodes++;
            if (part === 5) {
              const total = wSlots + cSlots + slotUsed;
              const r = tryJewels(pts, total);
              if (r.ok) {
                let def = 0, mx = 0;
                picked.forEach(p => { def += p.def; mx += p.max || 0; });
                out.push({ picked: picked.slice(), jewels: r.used, def, mx });
              }
              return;
            }
            // 剪枝：剩余部位最多能补多少
            for (let i = 0; i < targets.length; i++) {
              let can = pts[i];
              for (let k = part; k < 5; k++) can += bnd[k][i];
              if (can + 8 < need[i]) return;   // 8 点留给装饰品余量
            }
            const list = cand[part];
            if (!list.length) {          // 该部位没有相关部件
              picked.push(EMPTY);
              dfs(part + 1, pts, slotUsed, picked);
              picked.pop();
              return;
            }
            const ord = walk[part];
            for (let oi = 0; oi < ord.length; oi++) {
              const c = list[ord[oi]];
              picked.push(c);
              for (let k = 0; k < targets.length; k++) pts[k] += c.pts[k];
              dfs(part + 1, pts, slotUsed + c.slot, picked);
              for (let k = 0; k < targets.length; k++) pts[k] -= c.pts[k];
              picked.pop();
              if (out.length >= stopAt || nodes > LIMIT) return;
            }
          }

          // 纯深度优先会一头扎进第一个头部分支，400 个解全长一个样。
          // 这里按「头部」分批：每个头只取前 5 个解，再换下一个头，保证结果覆盖多种头部与混装。
          const PER_HEAD = 5;
          const heads = cand[0].length ? walk[0].map(i => cand[0][i]) : [EMPTY];
          for (let hi = 0; hi < heads.length; hi++) {
            if (out.length >= COLLECT || nodes > LIMIT) break;
            const head = heads[hi];
            // 每个头换一次其余部位的起点，避免 40 套的胴/腕/腰/脚完全一样
            for (let p = 1; p < 5; p++) walk[p] = makeWalk(p, hi);
            stopAt = Math.min(COLLECT, out.length + PER_HEAD);
            dfs(1, head.pts.slice(), head.slot, [head]);
          }

          // 原程序「无负技能」：把会产生任意负点数技能树的解剔掉
          if (noNeg) {
            const hasNeg = r => {
              const acc = new Map();
              const add = (t, p) => { if (t != null) acc.set(t, (acc.get(t) || 0) + p); };
              r.picked.forEach(p => {
                const a = p.id ? armById.get(p.id) : null;
                if (a) (a[12] || []).forEach(([t, v]) => add(t, v));
              });
              (r.jewels || []).forEach(jid => {
                const j = jewById.get(jid);
                if (j) (j[4] || []).forEach(([t, v]) => add(t, v));
              });
              for (const v of acc.values()) if (v < 0) return true;
              return false;
            };
            for (let i = out.length - 1; i >= 0; i--) if (hasNeg(out[i])) out.splice(i, 1);
          }

          // 收尾：按防御降序，但「同系列整身套」每系列最多 8 套、同一件头最多 12 套，
          // 把剩余位置让给混装和其他系列
          out.sort((a, b) => b.def - a.def);
          const nameOf = id => (armById.get(id) || [0, 0, '??'])[2] || '';
          const ser = id => nameOf(id).slice(0, 2);
          const cntSet = new Map(), cntHead = new Map();
          const final = [];
          for (const r of out) {
            const s0 = ser(r.picked[0].id);
            const full = r.picked.every(p => ser(p.id) === s0);
            if (full) {
              const c = cntSet.get(s0) || 0;
              if (c >= 8) continue;
              cntSet.set(s0, c + 1);
            }
            const h = r.picked[0].id, ch = cntHead.get(h) || 0;
            if (ch >= 12) continue;
            cntHead.set(h, ch + 1);
            final.push(r);
            if (final.length >= SHOW) break;
          }
          const dt = Math.round(performance.now() - t0);
          results = final.length ? final : out.slice(0, SHOW);
          paintResults(dt, nodes);
          running = false;
        }, 30);
      }

      const PART_NM = ['头', '胴', '腕', '腰', '脚'];

      function paintResults(dt, nodes) {
        if (!results.length) {
          res.innerHTML = `<div class="empty">没有找到满足条件的套装<br><span class="dim">试试降低等级、放宽性别/剑枪限制，或者减少目标技能</span></div>`;
          return;
        }
        const tset = new Set(targets.map(x => x[0]));
        res.innerHTML = `<div class="section-title">找到 ${results.length} 套（${dt}ms / ${nodes} 节点）</div>` +
          results.map((r, i) => {
            const skills = new Map();
            r.picked.forEach(p => {
              const a = armById.get(p.id);
              if (a) a[12].forEach(([t, v]) => skills.set(t, (skills.get(t) || 0) + v));
            });
            r.jewels.forEach(jid => {
              const j = jewById.get(jid);
              if (j) j[4].forEach(([t, v]) => skills.set(t, (skills.get(t) || 0) + v));
            });
            const lines = [];
            skills.forEach((v, t) => {
              const lv = A.skillLevel(t, v);
              if (lv.lv > 0) lines.push([lv.name, lv.lv, tset.has(t)]);
            });
            // 目标技能排在最前，其余按等级降序
            lines.sort((a, b) => (b[2] - a[2]) || (b[1] - a[1]));
            const slots = r.picked.reduce((n, p) => n + p.slot, 0) + +wslot + +charmSlots;
            const used = r.jewels.reduce((n, jid) => n + ((jewById.get(jid) || [0, 0, 0])[2] || 0), 0);
            return `<div class="card bres" data-r="${i}">
              <div class="bres-h"><b>防御 ${r.def}</b><span class="dim">满 ${r.mx || r.def} · 孔 ${used}/${slots}</span></div>
              <div class="bres-parts">${r.picked.map((p, k) => {
                const a = armById.get(p.id);
                return `<span class="pt"><em>${PART_NM[k] || ''}</em>${a ? A.esc(a[2]) : '—'}</span>`;
              }).join('')}</div>
              <div class="bres-skl">${lines.slice(0, 10).map(([n, l, hit]) => `<span class="tag ${hit ? 'on' : ''}">${A.esc(n)} Lv.${l}</span>`).join('')}</div>
              ${r.jewels.length ? `<div class="bres-jew">珠：${r.jewels.map(jid => A.esc((jewById.get(jid) || [0, '', '', 0, []])[1])).join('、')}</div>` : ''}
              ${fcharm ? `<div class="dim2">护石：${A.esc(charmLabel(fcharm))}</div>` : ''}
            </div>`;
          }).join('');
      }

      view.addEventListener('click', e => {
        const c = e.target.closest('[data-r]');
        if (!c) return;
        const r = results[+c.dataset.r];
        // 载入模拟器
        const s = emptySet();
        s.weapon = 0;
        r.picked.forEach((p, i) => { s.armor[i] = p.id; });
        s.charm = fcharm ? JSON.parse(JSON.stringify(fcharm)) : { s1: null, s2: null, slots: +charmSlots };
        store.set(LS_CUR, s);
        // 分配珠子到具体孔位
        setTimeout(() => {
          const cur = store.get(LS_CUR, emptySet());
          const slots = setSlots(cur);
          let k = 0;
          const jewelIds = r.jewels.slice();
          slots.forEach(sl => {
            if (!sl.n) return;
            const arr = [];
            for (let i = 0; i < sl.n && k < jewelIds.length; i++) {
              arr.push(jewelIds[k++]);
            }
            if (arr.length) cur.deco[sl.key] = arr;
          });
          store.set(LS_CUR, cur);
          A.go('sim');
        }, 20);
      });
    }
  });
})();
